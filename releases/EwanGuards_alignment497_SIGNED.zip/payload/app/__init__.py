import hashlib, json, os, secrets, sys
from datetime import timedelta
from flask import Flask, g, jsonify, request, session, render_template
from werkzeug.security import check_password_hash, generate_password_hash
from . import db as dbm
from .dates import now_utc

PW_METHOD = "pbkdf2:sha256:600000"
MIN_PW = 10
SESSION_HOURS = 8
LOCK_WINDOW_MIN, MAX_FAILS_USER, MAX_FAILS_IP = 15, 5, 25
_DUMMY = generate_password_hash("x" * 12, method=PW_METHOD)


def default_data_dir():
    if os.environ.get("GUARDS_DATA_DIR"):
        return os.environ["GUARDS_DATA_DIR"]
    if sys.platform.startswith("win"):
        return os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "EwanGuardsSystem")
    return os.path.join(os.path.expanduser("~"), ".local", "share", "EwanGuardsSystem")


def _read(p):
    with open(p) as f:
        return f.read().strip()


def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()


def create_app(data_dir=None):
    data_dir = data_dir or default_data_dir()
    for sub in ("", "attachments", "backups", "tmp"):
        os.makedirs(os.path.join(data_dir, sub), exist_ok=True)
    keyf = os.path.join(data_dir, "secret.key")
    try:
        fd=os.open(keyf,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    except FileExistsError:pass
    else:
        with os.fdopen(fd,'w') as f:f.write(secrets.token_hex(32))
    app = Flask(__name__)
    app.config.update(DATA_DIR=data_dir, DB_PATH=os.path.join(data_dir, "guards.sqlite"),
                      SECRET_KEY=_read(keyf), SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                      MAX_CONTENT_LENGTH=25 * 1024 * 1024, MAX_FORM_MEMORY_SIZE=256 * 1024, MAX_FORM_PARTS=80, JSON_AS_ASCII=False,
                      BUNDLED_EXCEL=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "import", "guards_source.xlsx"))
    if os.name!='nt':
        for path in [data_dir,*[os.path.join(data_dir,x) for x in ('attachments','backups','tmp')]]:os.chmod(path,0o700)
        os.chmod(keyf,0o600)
    app.json.ensure_ascii = False
    dbm.init(app.config["DB_PATH"])
    from .importer import ensure_checks
    from .customize import init as customize_init
    _c = dbm.connect(app.config["DB_PATH"])
    if not _c.execute("SELECT 1 FROM sqlite_master WHERE name='user_permissions'").fetchone() and _c.execute('SELECT count(*) FROM users').fetchone()[0]:
        from .backup import create_backup
        create_backup(data_dir, tag='-before-v3')
    customize_init(_c)
    ensure_checks(_c)
    from .attendance import init as attendance_init
    attendance_init(_c)
    from .record_photos import init as photos_init
    photos_init(_c)
    from .vehicle_monthly import init as monthly_init
    monthly_init(_c)
    _c.close()

    @app.before_request
    def _load():
        g.db = dbm.connect(app.config["DB_PATH"])
        g.user = None
        from .security import host_allowed,valid_origin
        if not host_allowed(request.host,app.config.get('SHARING_URL')):
            return jsonify(error='عنوان خادم غير مسموح'),400
        if request.path.startswith('/api/') and request.method not in ('GET','HEAD','OPTIONS'):
            if not valid_origin(request.headers.get('Origin'),request.host,request.scheme,app.config.get('SHARING_URL')):
                return jsonify(error='مصدر الطلب غير مسموح'),403
            if request.is_json:
                if request.content_length and request.content_length>1024*1024:return jsonify(error='طلب JSON كبير جدًا'),413
                if not isinstance(request.get_json(silent=True),dict):return jsonify(error='محتوى الطلب يجب أن يكون كائن JSON صالحًا'),400
        sid = session.get("sid")
        if sid:
            r = g.db.execute("""SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
                                WHERE s.token_hash=? AND s.expires_at>? AND u.active=1""", (sha(sid), now_utc().isoformat())).fetchone()
            g.user = dict(r) if r else None
        if "csrf" not in session:
            session["csrf"] = secrets.token_hex(16)
        if request.path.startswith("/api/") and request.method not in ("GET", "HEAD", "OPTIONS"):
            if not secrets.compare_digest(request.headers.get("X-CSRF-Token", ""), session["csrf"]):
                return jsonify(error="رمز الحماية غير صالح؛ أعد تحميل الصفحة"), 403

    @app.teardown_request
    def _close(exc):
        d = g.pop("db", None)
        if d:
            d.close()

    @app.after_request
    def _hdr(resp):
        resp.headers["Content-Security-Policy"] = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
                                                   "img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'; form-action 'self'")
        resp.headers['X-Frame-Options']='DENY'
        resp.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
        if app.config.get('SESSION_COOKIE_SECURE'):resp.headers['Strict-Transport-Security']='max-age=86400'
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "no-referrer"
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    from .api import bp
    app.register_blueprint(bp)
    from .record_photos import bp as photos_bp
    app.register_blueprint(photos_bp)
    from .vehicle_monthly import bp as monthly_bp
    app.register_blueprint(monthly_bp)
    from .customize import register as register_custom
    register_custom(app)
    from .attendance import bp as attendance_bp
    from .enhancements import bp as enhancements_bp
    app.register_blueprint(attendance_bp)
    app.register_blueprint(enhancements_bp)
    from .analytics import bp as analytics_bp
    app.register_blueprint(analytics_bp)
    from .desktop_notifications import register_api
    register_api(app)
    from .webpush import register as register_push
    register_push(app)

    @app.route("/")
    def index():
        return render_template("app.html")

    @app.errorhandler(413)
    def _big(e):
        return jsonify(error="الملف أكبر من الحد المسموح (25 ميجا)"), 413

    @app.errorhandler(500)
    def _internal_error(e):
        if request.path.startswith('/api/'):return jsonify(error='تعذر إتمام الطلب؛ لم تُعرض تفاصيل النظام'),500
        return 'تعذر إتمام الطلب',500
    from .updater_api import install as install_updater
    install_updater(app)
    return app


# ---- مساعدات المصادقة (تُستخدم من api.py) ----
def hash_pw(pw):
    return generate_password_hash(pw, method=PW_METHOD)


def verify_pw(h, pw):
    return check_password_hash(h, pw)


def start_session(conn, user_id):
    tok = secrets.token_urlsafe(32)
    now = now_utc()
    conn.execute("INSERT INTO sessions VALUES(?,?,?,?)", (sha(tok), user_id, now.isoformat(), (now + timedelta(hours=SESSION_HOURS)).isoformat()))
    conn.execute("DELETE FROM sessions WHERE expires_at<?", (now.isoformat(),))
    conn.commit()
    session.clear()
    session["sid"] = tok
    session["csrf"] = secrets.token_hex(16)
