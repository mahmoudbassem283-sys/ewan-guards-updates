"""Stable table identities and non-destructive migrations for column settings."""
import copy,json,re
TABLES={
 'equipment:main':dict(label='الأجهزة والأدوات — البنود',columns=[('photo','الصورة'),('seq','م'),('item','البند'),('required','المطلوب'),('available','المتوفر'),('short','الناقص'),('op_status','الحالة التشغيلية'),('result','المطابقة'),('attachment','مرفق')],hide=[]),
 'licenses:main':dict(label='السجلات والتراخيص — البنود',columns=[('photo','الصورة'),('seq','م'),('item','البند'),('expiry','الانتهاء'),('remaining','المدة المتبقية'),('status','حالة الوثيقة'),('result','المطابقة'),('attachment','مرفق')],hide=[]),
 'vehicles:followup':dict(label='السيارات والاستمارات — بنود المتابعة',columns=[('seq','م'),('item','البند'),('required','المطلوب'),('available','المتوفر'),('expiry','الانتهاء'),('status','حالة الوثيقة'),('result','المطابقة'),('attachment','مرفق')],hide=['expiry','status']),
 'vehicles:cars':dict(label='السيارات والاستمارات — السيارات',columns=[('photo','الصورة'),('status','حالة الاستمارة'),('plate','اللوحة'),('model','الموديل'),('year','السنة'),('driver','السائق'),('attachments','المرفقات'),('expiry','تاريخ الانتهاء'),('remaining','المدة المتبقية'),('actions','الإجراءات'),('monthly','التحديث الشهري')],hide=['driver']),
 'vehicles:drivers':dict(label='السيارات والاستمارات — رخص السائقين',columns=[('photo','الصورة'),('status','حالة الرخصة'),('name','الاسم'),('license','الرخصة'),('attachments','المرفقات'),('expiry','تاريخ الانتهاء'),('remaining','المدة المتبقية'),('actions','الإجراءات')],hide=[]),
 'vehicles:handovers':dict(label='السيارات والاستمارات — استلام وتسليم',columns=[('vehicle','السيارة'),('kind','الحركة'),('date','التاريخ'),('person','الشخص'),('odometer','العداد'),('attachments','المرفقات'),('actions','الإجراءات')],hide=[])
}
FIELD_KEYS={'الصورة':'photo','التحديث الشهري':'monthly','الناقص':'short','الحالة التشغيلية':'op_status','المدة المتبقية':'remaining','م':'seq','البند':'item','المطلوب':'required','المتوفر':'available','الانتهاء':'expiry','تاريخ الانتهاء':'expiry','انتهاء الاستمارة':'expiry','انتهاء الرخصة':'expiry','الوثائق':'expiry','حالة الوثيقة':'status','حالة الاستمارة':'status','حالة الرخصة':'status','المطابقة':'result','مرفق':'attachment','اللوحة':'plate','الموديل':'model','السنة':'year','السائق':'driver','المرفقات':'attachments','الاسم':'name','الرخصة':'license','السيارة':'vehicle','الحركة':'kind','التاريخ':'date','الشخص':'person','العداد':'odometer','':'actions','الإجراءات':'actions'}

def catalog():
    return {key:dict(label=v['label'],columns=[dict(key=k,label=label) for k,label in v['columns']]) for key,v in TABLES.items()}

def legacy_kind(key):
    if not key.startswith('vehicles:') or key in TABLES:return None
    headers=key.split(':',1)[1].split('|')
    kind='followup' if 'البند' in headers else 'cars' if 'اللوحة' in headers else 'drivers' if 'الرخصة' in headers else 'handovers' if 'الحركة' in headers else None
    return 'vehicles:'+kind if kind else None

def _migrate_vehicle38(c,default):
    if c.execute("SELECT 1 FROM settings WHERE key='vehicle_columns_v38'").fetchone():return
    row=c.execute("SELECT value FROM settings WHERE key='appearance_v3'").fetchone()
    appearance=json.loads(row[0]) if row else copy.deepcopy(default)
    tables=appearance.setdefault('tables',{})
    for key,schema in TABLES.items():
        if not key.startswith('vehicles:'):continue
        columns=[];seen=set()
        candidates=[k for k in tables if legacy_kind(k)==key]
        # The latest full header signature contains the current fields and is preferred.
        candidates.sort(key=lambda k:len(k.split('|')),reverse=True)
        source_key=key if key in tables else candidates[0] if candidates else None
        if source_key:
            headers=source_key.split(':',1)[1].split('|')
            valid=dict(schema['columns'])
            for old in tables[source_key]:
                raw=old.get('key','');field=raw if raw in valid else FIELD_KEYS.get(headers[int(raw)],'') if raw.isdigit() and int(raw)<len(headers) else ''
                if field not in valid or field in seen:continue
                label=old.get('label',valid[field]);label=valid[field] if field=='actions' and re.fullmatch(r'إجراءات\s*\d+',label) else label
                columns.append(dict(key=field,label=label,visible=old.get('visible',True) is not False));seen.add(field)
        columns.extend(dict(key=k,label=label,visible=True) for k,label in schema['columns'] if k not in seen)
        for col in columns:
            if col['key'] in schema['hide']:col['visible']=False
        tables[key]=columns
    c.execute("INSERT OR REPLACE INTO settings VALUES('appearance_v3',?)",(json.dumps(appearance,ensure_ascii=False),))
    c.execute("INSERT INTO settings VALUES('vehicle_columns_v38','1')")


def _migrate_remaining494(c,default):
    _migrate_vehicle38(c,default)
    if c.execute("SELECT 1 FROM settings WHERE key='remaining_columns_v494'").fetchone():return
    row=c.execute("SELECT value FROM settings WHERE key='appearance_v3'").fetchone()
    appearance=json.loads(row[0]) if row else copy.deepcopy(default)
    tables=appearance.setdefault('tables',{})
    for key in ('licenses:main','vehicles:cars','vehicles:drivers'):
        schema=TABLES[key];valid=dict(schema['columns']);seen=set();cols=[]
        source=key if key in tables else None
        if source is None and key=='licenses:main':
            candidates=[k for k in tables if k.startswith('licenses:')]
            candidates.sort(key=lambda k:len(k.split('|')),reverse=True)
            source=candidates[0] if candidates else None
        headers=source.split(':',1)[1].split('|') if source else []
        for old in tables.get(source,[]):
            raw=old.get('key','')
            field=raw if raw in valid else FIELD_KEYS.get(headers[int(raw)],'') if raw.isdigit() and int(raw)<len(headers) else ''
            if field not in valid or field in seen:continue
            cols.append(dict(key=field,label=old.get('label',valid[field]),visible=old.get('visible',True) is not False));seen.add(field)
        for field,label in schema['columns']:
            if field in seen:continue
            col=dict(key=field,label=label,visible=True)
            if field=='remaining':
                index=next((i+1 for i,x in enumerate(cols) if x['key']=='expiry'),len(cols));cols.insert(index,col)
            else:cols.append(col)
            seen.add(field)
        tables[key]=cols
    c.execute("INSERT OR REPLACE INTO settings VALUES('appearance_v3',?)",(json.dumps(appearance,ensure_ascii=False),))
    c.execute("INSERT INTO settings VALUES('remaining_columns_v494','1')")


def migrate(c,default):
    _migrate_remaining494(c,default)
    if c.execute("SELECT 1 FROM settings WHERE key='photo_columns_v496'").fetchone():return
    row=c.execute("SELECT value FROM settings WHERE key='appearance_v3'").fetchone()
    appearance=json.loads(row[0]) if row else copy.deepcopy(default);tables=appearance.setdefault('tables',{})
    for key in ('vehicles:cars','vehicles:drivers','licenses:main','equipment:main'):
        schema=TABLES[key];valid=dict(schema['columns']);seen=set();cols=[]
        source=key if key in tables else None
        if source is None and key=='equipment:main':
            candidates=[k for k in tables if k.startswith('equipment:')];candidates.sort(key=lambda k:len(k.split('|')),reverse=True);source=candidates[0] if candidates else None
        headers=source.split(':',1)[1].split('|') if source else []
        for old in tables.get(source,[]):
            raw=old.get('key','');field=raw if raw in valid else FIELD_KEYS.get(headers[int(raw)],'') if raw.isdigit() and int(raw)<len(headers) else ''
            if field not in valid or field in seen:continue
            cols.append(dict(key=field,label=old.get('label',valid[field]),visible=old.get('visible',True) is not False));seen.add(field)
        for field,label in schema['columns']:
            if field not in seen:cols.append(dict(key=field,label=label,visible=True));seen.add(field)
        photo=next(x for x in cols if x['key']=='photo');middle=[x for x in cols if x['key'] not in ('photo','monthly')]
        tables[key]=[photo,*middle]+([next(x for x in cols if x['key']=='monthly')] if key=='vehicles:cars' else [])
    c.execute("INSERT OR REPLACE INTO settings VALUES('appearance_v3',?)",(json.dumps(appearance,ensure_ascii=False),))
    c.execute("INSERT INTO settings VALUES('photo_columns_v496','1')")
