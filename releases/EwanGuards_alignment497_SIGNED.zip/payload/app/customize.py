"""إعدادات المظهر وصلاحيات الموارد؛ تُحفظ إضافيًا دون استبدال البيانات القائمة."""
import copy, io, json, os, re, secrets
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse
from flask import Blueprint, current_app, g, jsonify, request, send_file
from PIL import Image, UnidentifiedImageError

SECTIONS = {'dashboard':'لوحة التحكم','contract':'العقد','employees':'اعتماد الكادر','vehicles':'السيارات والاستمارات',
 'equipment':'الأجهزة والأدوات','licenses':'السجلات والتراخيص','expiries':'الصلاحيات والتنبيهات',
 'reports':'تقارير الجاهزية','daily_reports':'التقارير اليومية','weekly_reports':'التقارير الأسبوعية','attendance':'الحضور والانصراف','monthly_reports':'التقارير الشهرية','claims':'المستخلصات الشهرية'}
SECTIONS.update(dashboard_design='تخصيص اللوحة والداشبورد',risk_settings='قواعد حساب المخاطر',appearance='المظهر والمسميات والشعارات')
ACTIONS = ('view','add','edit','delete','export','print')
ADMIN = {'users','audit','import','backup','settings'}
DEFAULT = dict(title='نظام إدارة عقد الحراسات الأمنية', colors=dict(bg='#f3f7fa',card='#ffffff',blue='#26789c',teal='#0a8579',orange='#c8481f',amber='#ffc22d',gray='#8597a5',navy='#062947'),
 logos=dict(login='/static/img/ewan.png',sidebar='/static/img/ewan.png',header='/static/img/authority.png',consultant=''),
 sizes=dict(login=120,sidebar=150,header=76,consultant=90), logo_visible=dict(login=True,sidebar=True,header=True,consultant=True),
 watermark=dict(src='/static/img/authority.png',size=520,opacity=5,visible=True), labels={}, tables={}, widgets={}, date_display='gregorian', metric_cards=None, section_cards={}, vehicle_followup_visible=True)

def init(c):
    c.executescript('''CREATE TABLE IF NOT EXISTS user_permissions(user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS registers(id INTEGER PRIMARY KEY, section TEXT NOT NULL CHECK(section IN ('daily_reports','weekly_reports','monthly_reports','claims')), name TEXT NOT NULL, event_date TEXT, url TEXT, notes TEXT, created_at TEXT, updated_at TEXT);''')
    # Expand the old register constraint without changing ids or existing records.
    sql=c.execute("SELECT sql FROM sqlite_master WHERE name='registers'").fetchone()[0]
    if "'weekly_reports'" not in sql:
        c.execute('BEGIN IMMEDIATE')
        c.execute("ALTER TABLE registers RENAME TO registers_v34")
        c.execute("CREATE TABLE registers(id INTEGER PRIMARY KEY, section TEXT NOT NULL CHECK(section IN ('daily_reports','weekly_reports','monthly_reports','claims')), name TEXT NOT NULL,event_date TEXT,url TEXT,notes TEXT,created_at TEXT,updated_at TEXT)")
        c.execute("INSERT INTO registers SELECT * FROM registers_v34")
        c.execute("DROP TABLE registers_v34")
    from .column_layout import migrate
    migrate(c,DEFAULT)
    c.commit()

def appearance():
    r = g.db.execute("SELECT value FROM settings WHERE key='appearance_v3'").fetchone()
    value=json.loads(r[0]) if r else copy.deepcopy(DEFAULT)
    rev=g.db.execute("SELECT value FROM settings WHERE key='appearance_revision'").fetchone()
    value['_revision']=int(rev[0]) if rev else 0
    return value

def perms(u=None):
    u = u or g.user
    if not u: return {}
    if u['role']=='owner': return {s:{a:True for a in ACTIONS} for s in SECTIONS}
    r = g.db.execute('SELECT value FROM user_permissions WHERE user_id=?',(u['id'],)).fetchone()
    if r:
        stored=json.loads(r[0]);return {s:{a:bool(stored.get(s,{}).get(a,False)) for a in ACTIONS} for s in SECTIONS}
    return {s:{a:(s not in ('dashboard_design','risk_settings','appearance') and a=='view' and (s!='reports' or bool(u['can_use_reports']))) or (s=='reports' and a in ('export','print') and bool(u['can_use_reports'])) for a in ACTIONS} for s in SECTIONS}

def can(section, action='view', u=None):
    u = u or g.user
    if not u: return False
    if u['role']=='owner': return True
    if section in ADMIN: return False
    p=perms(u).get(section,{})
    return bool(p.get('view') and p.get(action))

def owner_section(t,i):
    if t=='item':
        r=g.db.execute('SELECT section FROM items WHERE id=?',(i,)).fetchone()
        return r[0] if r else None
    return {'employee':'employees','vehicle':'vehicles','driver':'vehicles','contract':'contract','contract_fact':'contract','handover':'vehicles'}.get(t)

def resource_row(table, rid):
    return g.db.execute(f'SELECT * FROM {table} WHERE id=?',(rid,)).fetchone()

def request_section():
    path=request.path.removeprefix('/api/').split('/')
    k=path[0]; b=request.get_json(silent=True) or request.form or request.args
    if k in ADMIN: return k
    if k in ('employees','dashboard','contract','reports','attendance'): return k
    if k=='contract_facts': return 'contract'
    if k in ('vehicles','drivers','handovers'): return 'vehicles'
    if k=='export': return 'reports'
    if k=='registers':
        row=resource_row('registers',path[1]) if len(path)>1 and path[1].isdigit() else None
        return row['section'] if row else b.get('section')
    if k=='items':
        row=resource_row('items',path[1]) if len(path)>1 and path[1].isdigit() else None
        return row['section'] if row else b.get('section')
    if k in ('documents','tracked_docs'):
        if len(path)>1 and path[1].isdigit():
            row=resource_row(k,path[1])
            if not row: return None
            return owner_section(row['owner_type'],row['owner_id'])
        if b.get('owner_type') and b.get('owner_id'): return owner_section(b.get('owner_type'),b.get('owner_id'))
        return 'expiries' if k=='tracked_docs' else None
    if k=='suggestions' and len(path)>1:
        row=g.db.execute('SELECT d.* FROM date_suggestions s JOIN documents d ON d.id=s.document_id WHERE s.id=?',(path[1],)).fetchone()
        return owner_section(row['owner_type'],row['owner_id']) if row else None
    return None

def request_allowed(owner=False):
    s=request_section()
    if s=='settings' and request.path.startswith(('/api/settings/appearance','/api/settings/logo')):
        return can('appearance','view' if request.method=='GET' else 'edit')
    if s in ADMIN: return g.user['role']=='owner'
    if g.user['role']=='owner': return True
    act={'GET':'view','HEAD':'view','POST':'add','PUT':'edit','DELETE':'delete'}.get(request.method,'view')
    if request.path.endswith(('/renew','/suggest','/confirm','/reject')): act='edit'
    if request.path.startswith('/api/export/'): act='export'
    if request.path.endswith('/confirm') and request.path.startswith('/api/suggestions/'):
        b=request.get_json(silent=True) or {}
        if not can(owner_section(b.get('owner_type'),b.get('owner_id')),'add'): return False
    if s is None:
        return request.method=='GET' and request.path in ('/api/documents','/api/items') and any(can(x) for x in ('employees','vehicles','equipment','licenses','contract'))
    if not can(s,act): return False
    # التقارير الشاملة تحتاج مشاهدة المحاور التي تتضمنها، فلا يتسرب قسم مخفي.
    if s=='reports' and request.path not in ('/api/reports',):
        name=request.path.split('/')[-1].removesuffix('.xlsx')
        required=['employees'] if name in ('consultant','authority') else ['employees','vehicles','equipment','licenses','expiries']
        if not all(can(x) for x in required): return False
    return True

def valid_url(url):
    if not isinstance(url,str) or len(url)>3000: raise ValueError('رابط غير صالح')
    if not url: return ''
    p=urlparse(url)
    if p.scheme!='https' or not p.hostname or p.username or p.password or any(ord(c)<32 for c in url): raise ValueError('استخدم رابط https صالحًا')
    return url

def validated_appearance(b):
    if not isinstance(b,dict): raise ValueError('إعدادات غير صالحة')
    out=copy.deepcopy(DEFAULT)
    out['title']=str(b.get('title',out['title'])).strip()[:120]
    if not out['title']: raise ValueError('اسم البرنامج مطلوب')
    for k in out['colors']:
        v=b.get('colors',{}).get(k,out['colors'][k])
        if not isinstance(v,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',v): raise ValueError('لون غير صالح')
        out['colors'][k]=v
    for k in out['logos']:
        v=b.get('logos',{}).get(k,out['logos'][k]); check_image_url(v)
        out['logos'][k]=v
        n=b.get('sizes',{}).get(k,out['sizes'][k])
        if type(n) not in (int,float) or not 30<=n<=300: raise ValueError('حجم الشعار بين 30 و300')
        out['sizes'][k]=n
        out['logo_visible'][k]=bool(b.get('logo_visible',{}).get(k,True))
    w=b.get('watermark',out['watermark']); check_image_url(w.get('src',''))
    if type(w.get('size')) not in (int,float) or not 100<=w['size']<=1200: raise ValueError('حجم العلامة بين 100 و1200')
    if type(w.get('opacity')) not in (int,float) or not 0<=w['opacity']<=30: raise ValueError('شفافية العلامة بين 0 و30')
    out['watermark']={k:w.get(k) for k in ('src','size','opacity','visible')}
    for group in ('labels','tables','widgets'):
        v=b.get(group,{})
        if not isinstance(v,dict) or len(json.dumps(v))>100000: raise ValueError('إعدادات العرض غير صالحة')
        out[group]=v
    followup=b.get('vehicle_followup_visible',True)
    if type(followup) is not bool:raise ValueError('اختر إظهار أو إخفاء بنود المتابعة')
    out['vehicle_followup_visible']=followup
    mode=b.get('date_display','gregorian')
    if mode not in ('gregorian','hijri','both'):raise ValueError('عرض التاريخ غير صالح')
    out['date_display']=mode
    cards=b.get('metric_cards')
    if cards is not None and (not isinstance(cards,list) or len(cards)>80):raise ValueError('عدد البطاقات غير صالح')
    from .enhancements import validate_card
    out['metric_cards']=[validate_card(x) for x in cards] if cards is not None else None
    from .enhancements import section_layout
    out['section_cards']=section_layout(b.get('section_cards',{}))
    for k,v in out['labels'].items():
        if not isinstance(v,str) or len(v)>160: raise ValueError('مسمى طويل أو غير صالح')
    for cfg in out['tables'].values():
        if not isinstance(cfg,list): raise ValueError('أعمدة غير صالحة')
        for col in cfg:
            if not isinstance(col,dict) or not isinstance(col.get('key'),str) or not isinstance(col.get('label'),str) or len(col['label'])>120: raise ValueError('مسمى عمود غير صالح')
    for cfg in out['widgets'].values():
        if not isinstance(cfg,dict) or not isinstance(cfg.get('label',''),str) or len(cfg.get('label',''))>120: raise ValueError('مؤشر غير صالح')
        if 'color' in cfg and not re.fullmatch(r'#[0-9a-fA-F]{6}',str(cfg['color'])): raise ValueError('لون المؤشر غير صالح')
        if type(cfg.get('order',0)) not in (int,float): raise ValueError('ترتيب غير صالح')
    return out

def check_image_url(v):
    if not isinstance(v,str) or (v and not (v in ('/static/img/ewan.png','/static/img/authority.png') or re.fullmatch(r'/api/branding/[a-f0-9]{32}\.png',v))): raise ValueError('مصدر شعار غير صالح؛ ارفع الصورة من الإعدادات')

bp=Blueprint('custom',__name__,url_prefix='/api')

def register(app):
    app.register_blueprint(bp)
    @app.after_request
    def enrich(resp):
        if not resp.is_json: return resp
        j=resp.get_json()
        if request.path=='/api/status':
            j['appearance']=appearance()
            if g.user and g.user['role']=='owner':
                from .column_layout import catalog
                j['table_catalog']=catalog()
            j['permissions']=perms() if g.user else {}
            j['now']=datetime.now(timezone.utc).isoformat()
            j['revision']=g.db.execute('SELECT COALESCE(MAX(id),0) FROM audit_log').fetchone()[0] if g.user else None
            if j.get('user'): j['user']['can_use_reports']=can('reports')
        if g.user and request.path=='/api/users' and request.method=='GET':
            for u in j.get('rows',[]): u['permissions']=perms(u)
        # تجميعات غير محددة القسم تُرشّح على الخادم، وليس فقط في القائمة.
        if g.user and request.method=='GET' and request.path in ('/api/documents','/api/tracked_docs','/api/items'):
            def visible(r):
                s=r.get('section') or owner_section(r.get('owner_type'),r.get('owner_id'))
                return can(s)
            if 'rows' in j:
                j['rows']=[r for r in j['rows'] if visible(r)]; j['total']=len(j['rows'])
        resp.set_data(current_app.json.dumps(j)); return resp

@bp.get('/branding/<name>')
def branding(name):
    if not re.fullmatch(r'[a-f0-9]{32}\.png',name): return jsonify(error='غير موجود'),404
    p=os.path.join(current_app.config['DATA_DIR'],'attachments','brand-'+name)
    if not os.path.isfile(p): return jsonify(error='غير موجود'),404
    return send_file(p,mimetype='image/png',max_age=86400)

@bp.route('/settings/appearance',methods=['GET','PUT','DELETE'])
def settings():
    from .api import audit
    if not can('appearance','view' if request.method=='GET' else 'edit'): return jsonify(error='تخصيص المظهر غير مصرح'),403
    if request.method=='GET':
        from .column_layout import catalog
        return jsonify(appearance=appearance(), defaults=DEFAULT,sections=SECTIONS,table_catalog=catalog())
    if request.method=='DELETE':return jsonify(error='تم إلغاء الاسترجاع الشامل؛ عدّل الإعداد المطلوب فقط'),405
    b=request.get_json(silent=True)
    try: v=validated_appearance(b)
    except (ValueError,TypeError,AttributeError) as e:return jsonify(error=str(e)),400
    g.db.execute('BEGIN IMMEDIATE')
    old=appearance()
    if isinstance(b,dict) and '_revision' in b and (type(b['_revision'])!=int or b['_revision']!=old['_revision']):
        g.db.rollback();return jsonify(error='الإعدادات تغيرت في نافذة أو حساب آخر؛ أعد فتحها قبل حفظ تعديلك حتى لا تُفقد تغييرات سابقة'),409
    revision=old['_revision']+1
    g.db.execute("INSERT OR REPLACE INTO settings VALUES('appearance_v3',?)",(json.dumps(v,ensure_ascii=False),))
    g.db.execute("INSERT OR REPLACE INTO settings VALUES('appearance_revision',?)",(str(revision),));g.db.commit()
    saved=appearance()
    audit('update','settings','appearance','تعديل إعدادات المظهر',old,v)
    return jsonify(ok=True,appearance=saved,revision=revision)

@bp.post('/settings/logo')
def logo_upload():
    from .api import audit
    if not can('appearance','edit'): return jsonify(error='تعديل الشعارات غير مصرح'),403
    f=request.files.get('file')
    if not f: return jsonify(error='اختر صورة'),400
    raw=f.read(5*1024*1024+1)
    if len(raw)>5*1024*1024:return jsonify(error='الحد الأقصى للصورة 5 ميجا'),400
    try:
        with Image.open(io.BytesIO(raw)) as im:
            if im.width*im.height>16000000: raise ValueError('أبعاد الصورة كبيرة')
            im.load(); im=im.convert('RGBA'); im.thumbnail((1600,1600)); name=secrets.token_hex(16)+'.png'
            im.save(os.path.join(current_app.config['DATA_DIR'],'attachments','brand-'+name))
    except (UnidentifiedImageError,OSError,ValueError,Image.DecompressionBombError) as e:return jsonify(error='صورة غير صالحة أو كبيرة جدًا'),400
    audit('create','settings','logo','رفع شعار للبرنامج')
    return jsonify(url='/api/branding/'+name)

@bp.route('/users/<int:uid>/permissions',methods=['GET','PUT'])
def permissions_endpoint(uid):
    from .api import audit
    if not g.user or g.user['role']!='owner': return jsonify(error='للمالك فقط'),403
    u=resource_row('users',uid)
    if not u:return jsonify(error='غير موجود'),404
    if request.method=='GET':return jsonify(permissions=perms(dict(u)),sections=SECTIONS,actions=ACTIONS)
    if u['role']=='owner':return jsonify(error='صلاحيات المالك ثابتة كاملة'),400
    b=request.get_json(silent=True) or {}; p=b.get('permissions')
    if not isinstance(p,dict) or set(p)-set(SECTIONS):return jsonify(error='أقسام غير صالحة'),400
    out={}
    for s in SECTIONS:
        v=p.get(s,{})
        if not isinstance(v,dict) or set(v)-set(ACTIONS) or any(type(x)!=bool for x in v.values()):return jsonify(error='صلاحيات غير صالحة'),400
        out[s]={a:bool(v.get('view') and v.get(a)) for a in ACTIONS}
    old=perms(dict(u));g.db.execute('INSERT OR REPLACE INTO user_permissions VALUES(?,?)',(uid,json.dumps(out)));g.db.commit()
    audit('update','users',uid,'تعديل صلاحيات المستخدم '+u['username'],old,out)
    return jsonify(ok=True)

@bp.route('/registers',methods=['GET','POST'])
@bp.route('/registers/<int:rid>',methods=['PUT','DELETE'])
def registers(rid=None):
    from .api import audit,ts
    if not g.user: return jsonify(error='يلزم الدخول'),401
    if not request_allowed():return jsonify(error='لا تملك صلاحية العملية'),403
    s=request_section()
    if s not in ('daily_reports','weekly_reports','monthly_reports','claims'):return jsonify(error='حدد القسم'),400
    if request.method=='GET':
        rows=[dict(r) for r in g.db.execute('SELECT * FROM registers WHERE section=? ORDER BY event_date DESC,id DESC',(s,))]
        attachment=request.args.get('attachment')
        if attachment in ('attached','missing'):rows=[r for r in rows if bool(r['url'])==(attachment=='attached')]
        return jsonify(rows=rows)
    old=dict(resource_row('registers',rid)) if rid and resource_row('registers',rid) else None
    if rid and not old:return jsonify(error='غير موجود'),404
    if request.method=='DELETE':
        g.db.execute('DELETE FROM registers WHERE id=?',(rid,));g.db.commit();audit('delete','registers',rid,'حذف سجل '+old['name'],old)
        return jsonify(ok=True)
    from .util import vdate
    try:
        b=request.get_json(silent=True) or {};name=str(b.get('name','')).strip();dt=vdate(b.get('event_date'));url=valid_url(b.get('url','').strip())
        if not name or len(name)>250:raise ValueError('اسم البند مطلوب (حتى 250 حرفًا)')
        if not dt:raise ValueError('تاريخ السجل مطلوب')
        notes=str(b.get('notes',''))[:5000]
    except (ValueError,AttributeError) as e:return jsonify(error=str(e)),400
    if rid:g.db.execute('UPDATE registers SET name=?,event_date=?,url=?,notes=?,updated_at=? WHERE id=?',(name,dt,url,notes,ts(),rid))
    else:rid=g.db.execute('INSERT INTO registers(section,name,event_date,url,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(s,name,dt,url,notes,ts(),ts())).lastrowid
    g.db.commit();audit('update' if old else 'create','registers',rid,('تعديل ' if old else 'إضافة ')+SECTIONS[s]+': '+name,old,dict(name=name,event_date=dt,url=url))
    return jsonify(ok=True,id=rid)
