'use strict';
const VEHICLE_MONTH_NAMES=['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const VEHICLE_MONTH_SIDES=[['front','أمامي'],['back','خلفي'],['right','يمين'],['left','يسار']];
function vehicleMonthTitle(value){return /^20\d{2}-(0[1-9]|1[0-2])$/.test(value||'')?VEHICLE_MONTH_NAMES[Number(value.slice(5))-1]+' '+value.slice(0,4):value;}
function recordImage(url){return el('div',{class:'record-photo-cell'},url?recordLabel('',url):el('span',{class:'muted'},'لا توجد صورة'));}
function trackedDatesOnly(rows){return rows?.length?rows.map(t=>el('div',{},rows.length>1?el('span',{},(t.title||'وثيقة')+' — '):null,ltr(t.expiry_date||'—'))):el('span',{class:'muted'},'غير مسجل');}
function recordDatesEditor(kind,id){
  const root=el('section',{class:'card record-document-dates'},el('h3',{},kind==='driver'?'تاريخ رخصة السائق':'تواريخ وثائق السيارة'),el('p',{class:'muted'},'تعديل وتجديد التواريخ من هنا؛ تُحفظ تغييرات التاريخ مباشرة.'),el('div',{}));
  const list=root.lastElementChild;
  const draw=async()=>{
    const r=await api('GET','/api/tracked_docs?'+qs({owner_type:kind,owner_id:id}));
    if(!root.isConnected)return;
    const rows=r.rows.map(t=>el('div',{class:'record-date-row'},el('b',{},t.title||'وثيقة'),ltr(t.expiry_date||'غير مسجل'),validityBadge(t.status),remaining(expiryDays(t.expiry_date)),can('vehicles','edit')&&el('button',{class:'btn sm',type:'button',onclick:()=>expiryModal(kind,id,t,draw)},'تعديل تاريخ الانتهاء'),can('vehicles','edit')&&el('button',{class:'btn sm',type:'button',onclick:()=>expiryModal(kind,id,{...t,expiry_date:''},draw,null,true)},'تجديد تاريخ الانتهاء'),can('vehicles','delete')&&el('button',{class:'btn sm danger',type:'button',onclick:()=>confirmBox('حذف هذه الوثيقة وتاريخها وسجل تجديدها؟',async()=>{await api('DELETE','/api/tracked_docs/'+t.id);await draw();})},'حذف الوثيقة')));
    list.replaceChildren(...rows,can('vehicles','edit')&&el('button',{class:'btn sm',type:'button',onclick:()=>expiryModal(kind,id,{title:kind==='driver'?'رخصة قيادة':'استمارة السيارة',doc_type:kind==='driver'?'driver_license':'vehicle_registration'},draw)},'إضافة تاريخ وثيقة'));
  };
  // The panel is attached synchronously by the record editor before this resolves.
  draw().catch(e=>{if(root.isConnected)list.replaceChildren(el('p',{class:'note'},e.message));});return root;
}
function monthlyVehicleCell(vehicle,record){
  const button=el('button',{class:'monthly-sheet-button',type:'button',title:'فتح التحديث الشهري والأرشيف','aria-label':'التحديث الشهري للسيارة '+vehicle.plate,onclick:()=>guarded(()=>vehicleMonthlyWindow(vehicle))()},
    record?el('img',{class:'monthly-sheet-image',src:record.image_url,alt:'التحديث الشهري '+vehicleMonthTitle(record.month),loading:'lazy'}):el('div',{class:'monthly-empty-sheet'},el('b',{},vehicleMonthTitle(today.slice(0,7))),el('div',{class:'monthly-empty-grid'},VEHICLE_MONTH_SIDES.map(([,label])=>el('span',{},label))),el('span',{},can('vehicles','edit')?'إضافة التحديث الشهري':'لا يوجد تحديث محفوظ')));
  return el('div',{class:'monthly-sheet-cell'},button,record&&record.filled<4&&badge('غير مكتمل '+record.filled+'/4','warn'));
}
async function vehicleMonthlyWindow(vehicle){
  let records=(await api('GET','/api/vehicle-monthly/'+vehicle.id)).rows;
  const canEdit=can('vehicles','edit'),urls=new Set();
  const archiveSelect=el('select',{'aria-label':'أرشيف التحديثات الشهرية'}),historyBox=el('div',{}),month=el('input',{type:'month',value:today.slice(0,7),min:'2000-01',max:'2099-12','aria-label':'شهر التحديث'}),grid=el('div',{class:'monthly-edit-grid'}),status=el('p',{class:'muted','aria-live':'polite'});
  const selections={},removed=new Set();let base=null,busy=false;
  const revoke=()=>{for(const url of urls)URL.revokeObjectURL(url);urls.clear();};
  const current=()=>records.find(r=>r.month===month.value)||null;
  const showArchive=()=>{
    const record=records.find(r=>String(r.id)===archiveSelect.value);if(!record){historyBox.replaceChildren(el('p',{class:'muted'},'لا توجد تحديثات شهرية محفوظة بعد.'));return;}
    historyBox.replaceChildren(el('p',{},vehicleMonthTitle(record.month)+' — النسخة '+record.revision+' — '+record.filled+'/4 صور'),el('button',{class:'monthly-full-button',type:'button',onclick:()=>modal('التحديث الشهري — '+vehicleMonthTitle(record.month),el('img',{class:'record-photo-large',src:record.image_url,alt:vehicleMonthTitle(record.month)}))},el('img',{class:'monthly-archive-image',src:record.image_url,alt:vehicleMonthTitle(record.month)})),can('vehicles','export')&&el('div',{class:'row noprint'},el('a',{class:'btn',href:record.image_url+'?download=1'},'تنزيل الصورة المجمّعة'),el('a',{class:'btn',href:'/api/vehicle-monthly/records/'+record.id+'/archive.zip'},'تنزيل ملف صور الشهر')));
  };
  const drawArchive=(selected)=>{
    archiveSelect.replaceChildren(...records.map(r=>el('option',{value:r.id},vehicleMonthTitle(r.month)+' — نسخة '+r.revision+' — '+r.created_at.slice(0,10))));
    if(selected&&records.some(r=>r.id===selected))archiveSelect.value=String(selected);showArchive();
  };
  const drawEditor=()=>{
    revoke();for(const side of Object.keys(selections))delete selections[side];removed.clear();base=current();status.textContent='';
    grid.replaceChildren(...VEHICLE_MONTH_SIDES.map(([side,label])=>{
      const preview=el('div',{class:'monthly-angle-preview'},base?.sides[side]?el('img',{src:base.sides[side],alt:label}):el('span',{class:'muted'},'لم تُرفع الصورة'));
      const file=el('input',{type:'file',accept:'image/png,image/jpeg,image/webp','aria-label':'صورة '+label});
      file.onchange=()=>{
        const chosen=file.files[0];if(!chosen)return;
        if(chosen.size>8*1024*1024){file.value='';toast('الصورة لا تتجاوز 8 ميجابايت',true);return;}
        selections[side]=chosen;removed.delete(side);const url=URL.createObjectURL(chosen);urls.add(url);preview.replaceChildren(el('img',{src:url,alt:label}));
      };
      return el('div',{class:'monthly-angle-card'},el('h4',{},label),preview,file,can('vehicles','delete')&&base?.sides[side]&&el('button',{class:'btn sm danger',type:'button',onclick:()=>{delete selections[side];removed.add(side);file.value='';preview.replaceChildren(el('span',{class:'muted'},'ستُزال من النسخة الجديدة؛ القديمة محفوظة'));}},'إزالة هذه الجهة من النسخة الجديدة'));
    }));
  };
  archiveSelect.onchange=showArchive;
  let editingMonth=month.value;
  month.onchange=()=>{
    const selectedMonth=month.value;
    if(Object.keys(selections).length||removed.size){month.value=editingMonth;confirmBox('تغيير الشهر سيلغي اختيارات الصور غير المحفوظة فقط. المتابعة؟',()=>{month.value=selectedMonth;editingMonth=selectedMonth;drawEditor();});}
    else{editingMonth=selectedMonth;drawEditor();}
  };
  const save=el('button',{class:'btn primary',type:'button',onclick:guarded(async()=>{
    if(busy)return;
    if(!/^20\d{2}-(0[1-9]|1[0-2])$/.test(month.value))throw new Error('اختر شهرًا وسنة صالحين.');
    const bytes=Object.values(selections).reduce((sum,file)=>sum+file.size,0);if(bytes>24*1024*1024)throw new Error('مجموع صور الشهر لا يتجاوز 24 ميجابايت.');
    const data=new FormData();data.append('month',month.value);data.append('expected_revision',String(base?.revision||0));data.append('remove',JSON.stringify([...removed]));for(const [side,file] of Object.entries(selections))data.append(side,file);
    busy=true;save.disabled=true;month.disabled=true;grid.querySelectorAll('input,button').forEach(x=>x.disabled=true);status.textContent='جارٍ حفظ صور الشهر وتكوين الصورة المجمّعة…';
    try{const result=await api('POST','/api/vehicle-monthly/'+vehicle.id,undefined,data);records=(await api('GET','/api/vehicle-monthly/'+vehicle.id)).rows;drawArchive(result.record.id);drawEditor();status.textContent='تم حفظ الصورة المجمّعة وإضافتها إلى الأرشيف؛ النسخ السابقة محفوظة.';await reload();}
    finally{busy=false;save.disabled=false;month.disabled=false;grid.querySelectorAll('input,button').forEach(x=>x.disabled=false);}
  })},'حفظ التحديث الشهري');
  const root=el('div',{class:'vehicle-monthly-window'},el('p',{},'كل شهر له صورة واحدة مقسمة لأربع جهات، واسم الشهر والسنة داخل الصورة. المعروض في الجدول أحدث شهر محفوظ، وليس أحدث شهر قديم تم تعديله.'),el('section',{class:'card'},el('h3',{},'أرشيف السيارة'),archiveSelect,historyBox),canEdit&&el('section',{class:'card monthly-editor'},el('h3',{},'إضافة أو تعديل تحديث شهري'),el('label',{},'الشهر والسنة',month),el('p',{class:'muted'},'تُحفظ الجهات الأربع معًا عند الضغط على حفظ. الصور الناقصة تظهر بخانة «لم تُرفع الصورة». كل تعديل يُحفظ كنسخة جديدة؛ لا تُستبدل النسخ السابقة. PNG/JPEG/WebP حتى 8 ميجابايت للصورة و24 ميجابايت للمجموعة.'),grid,save,status));
  const m=modal('التحديث الشهري للسيارة — '+vehicle.plate,root);m.el.classList.add('monthly-modal');drawArchive();if(canEdit)drawEditor();
  const observer=new MutationObserver(()=>{if(!m.el.isConnected){revoke();observer.disconnect();}});observer.observe(document.body,{childList:true,subtree:true});return m;
}
