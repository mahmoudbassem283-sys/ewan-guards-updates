"""Immutable, per-vehicle/month photo sheets. Original angles + composed PNG live
in the flat attachment store, so existing consistent backups include all versions.
"""
import io,json,os,re,secrets,unicodedata,warnings,zipfile
from pathlib import Path
from datetime import datetime,timezone
from flask import Blueprint,current_app,g,jsonify,request,send_file
from PIL import Image,ImageOps,ImageDraw,ImageFont,UnidentifiedImageError,features
from .customize import can
from .security import attachment_path
from .dates import now_utc

bp=Blueprint('vehicle_monthly',__name__,url_prefix='/api/vehicle-monthly')
SIDES=('front','back','right','left')
LABELS={'front':'أمامي','back':'خلفي','right':'يمين','left':'يسار'}
MONTHS=('يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر')


def init(c):
    c.execute('''CREATE TABLE IF NOT EXISTS vehicle_monthly_photos(
     id INTEGER PRIMARY KEY AUTOINCREMENT,vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
     month TEXT NOT NULL,revision INTEGER NOT NULL,front TEXT,back TEXT,right TEXT,left TEXT,
     composite TEXT NOT NULL,created_at TEXT NOT NULL,created_by INTEGER,
     UNIQUE(vehicle_id,month,revision))''')
    c.commit()


def authorize(vid,action='view'):
    if not g.user:return jsonify(error='يلزم تسجيل الدخول'),401
    if not can('vehicles',action) or not g.db.execute('SELECT 1 FROM vehicles WHERE id=?',(vid,)).fetchone():return jsonify(error='السيارة غير متاحة أو لا تملك صلاحية العملية'),403


def file_path(name):
    if not isinstance(name,str) or not re.fullmatch(r'monthly-[a-f0-9]{32}\.png',name):raise ValueError('صورة شهرية غير متاحة')
    return attachment_path(current_app.config['DATA_DIR'],name)


def description(row):
    return dict(id=row['id'],vehicle_id=row['vehicle_id'],month=row['month'],revision=row['revision'],
     filled=sum(bool(row[x]) for x in SIDES),created_at=row['created_at'],
     image_url=f"/api/vehicle-monthly/records/{row['id']}/composite",
     sides={x:f"/api/vehicle-monthly/records/{row['id']}/{x}" if row[x] else None for x in SIDES})


def clean_image(raw):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error',Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(raw)) as image:
                if image.format not in ('PNG','JPEG','WEBP') or image.width*image.height>16000000:raise ValueError()
                image.verify()
            with Image.open(io.BytesIO(raw)) as image:
                image=ImageOps.exif_transpose(image).convert('RGB');image.thumbnail((1600,1200))
                out=io.BytesIO();image.save(out,'PNG');return out.getvalue()
    except (OSError,ValueError,UnidentifiedImageError,Image.DecompressionBombError,Image.DecompressionBombWarning):raise ValueError('استخدم صورة PNG أو JPEG أو WebP حتى 16 ميجابكسل') from None


def font(size):
    candidates=[Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts/tahoma.ttf',Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts/arial.ttf',Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')]
    for path in candidates:
        if path.is_file():return ImageFont.truetype(str(path),size)
    try:return ImageFont.truetype('Arial.ttf',size)
    except OSError:raise ValueError('يلزم وجود خط عربي على الجهاز لتكوين الصورة الشهرية') from None


def basic_arabic(text):
    # Fixed sheet captions only: fallback for Pillow builds without libraqm.
    # Presentation forms preserve joins; numeric tokens retain their digit order.
    def shape(word):
        forms=[]
        for char in word:
            options={}
            for kind in ('ISOLATED','FINAL','INITIAL','MEDIAL'):
                try:options[kind]=unicodedata.lookup(unicodedata.name(char)+' '+kind+' FORM')
                except (ValueError,KeyError):pass
            forms.append(options)
        result=[]
        for i,char in enumerate(word):
            previous=i>0 and 'INITIAL' in forms[i-1] and 'FINAL' in forms[i]
            following=i+1<len(word) and 'INITIAL' in forms[i] and 'FINAL' in forms[i+1]
            choice='MEDIAL' if previous and following else 'FINAL' if previous else 'INITIAL' if following else 'ISOLATED'
            result.append(forms[i].get(choice,char))
        return ''.join(result)[::-1]
    return ' '.join(shape(w) if re.search(r'[\u0621-\u064a]',w) else w for w in reversed(text.split()))


def sheet(month,angles):
    width,height=1400,1120;image=Image.new('RGB',(width,height),'#f0f6fb');d=ImageDraw.Draw(image)
    raqm=features.check('raqm')
    def text(x,y,value,size,fill):
        if raqm:d.text((x,y),value,font=font(size),fill=fill,anchor='mm',direction='rtl',language='ar')
        else:d.text((x,y),basic_arabic(value),font=font(size),fill=fill,anchor='mm')
    d.rectangle((0,0,width,130),fill='#082f49')
    text(width//2,65,'شهر '+MONTHS[int(month[5:])-1]+' '+month[:4],60,'white')
    for side,box in zip(SIDES,[(713,150,1375,605),(25,150,687,605),(713,630,1375,1085),(25,630,687,1085)]):
        x1,y1,x2,y2=box;d.rounded_rectangle(box,radius=14,fill='white',outline='#9bb6cc',width=3)
        text((x1+x2)//2,y1+32,LABELS[side],38,'#082f49')
        rect=(x1+12,y1+66,x2-12,y2-12);raw=angles.get(side)
        if raw:
            with Image.open(io.BytesIO(raw)) as original:
                fitted=ImageOps.contain(original.convert('RGB'),(rect[2]-rect[0],rect[3]-rect[1]))
                image.paste(fitted,(rect[0]+(rect[2]-rect[0]-fitted.width)//2,rect[1]+(rect[3]-rect[1]-fitted.height)//2))
        else:text((x1+x2)//2,(rect[1]+rect[3])//2,'لم تُرفع الصورة',32,'#657a8a')
    out=io.BytesIO();image.save(out,'PNG');return out.getvalue()


def archive_files(c,vid):
    rows=c.execute('SELECT front,back,right,left,composite FROM vehicle_monthly_photos WHERE vehicle_id=?',(vid,)).fetchall()
    names={name for row in rows for name in row if name}
    c.execute('DELETE FROM vehicle_monthly_photos WHERE vehicle_id=?',(vid,))
    return names


@bp.get('/latest')
def latest():
    if not g.user:return jsonify(error='يلزم تسجيل الدخول'),401
    if not can('vehicles'):return jsonify(error='لا تملك صلاحية المشاهدة'),403
    rows=g.db.execute('''SELECT p.* FROM vehicle_monthly_photos p JOIN vehicles v ON v.id=p.vehicle_id
      WHERE NOT EXISTS(SELECT 1 FROM vehicle_monthly_photos n WHERE n.vehicle_id=p.vehicle_id AND
      (n.month>p.month OR (n.month=p.month AND n.revision>p.revision))) ORDER BY p.vehicle_id''')
    return jsonify(rows=[description(r) for r in rows])


@bp.get('/<int:vid>')
def history(vid):
    denied=authorize(vid)
    if denied:return denied
    rows=g.db.execute('SELECT * FROM vehicle_monthly_photos WHERE vehicle_id=? ORDER BY month DESC,revision DESC',(vid,))
    return jsonify(rows=[description(r) for r in rows])


@bp.post('/<int:vid>')
def save(vid):
    denied=authorize(vid,'edit')
    if denied:return denied
    month=request.form.get('month','')
    if not re.fullmatch(r'20\d{2}-(?:0[1-9]|1[0-2])',month):return jsonify(error='اختر الشهر والسنة بصيغة YYYY-MM'),400
    try:
        expected=int(request.form.get('expected_revision','0'))
        remove=json.loads(request.form.get('remove','[]'))
        if not isinstance(remove,list) or any(x not in SIDES for x in remove):raise ValueError()
        if remove and not can('vehicles','delete'):return jsonify(error='إزالة صورة من التحديث تتطلب صلاحية الحذف'),403
        uploads={};total=0
        for side in SIDES:
            upload=request.files.get(side)
            if upload and upload.filename:
                raw=upload.stream.read(8*1024*1024+1);total+=len(raw)
                if len(raw)>8*1024*1024 or total>24*1024*1024:raise ValueError('الحد 8 ميجابايت للصورة و24 ميجابايت لمجموع الصور')
                uploads[side]=clean_image(raw)
        if not uploads and not remove:raise ValueError('اختر صورة واحدة على الأقل أو غيّر صورة محفوظة')
    except (ValueError,TypeError) as error:return jsonify(error=str(error) or 'بيانات تحديث غير صالحة'),400
    made=[]
    g.db.execute('BEGIN IMMEDIATE')
    try:
        denied=authorize(vid,'edit')
        if denied:g.db.rollback();return denied
        previous=g.db.execute('SELECT * FROM vehicle_monthly_photos WHERE vehicle_id=? AND month=? ORDER BY revision DESC LIMIT 1',(vid,month)).fetchone()
        revision=previous['revision'] if previous else 0
        if expected!=revision:g.db.rollback();return jsonify(error='تحديث هذا الشهر تغيّر في نافذة أخرى؛ أعد فتحه قبل الحفظ'),409
        names={side:previous[side] if previous and side not in remove else None for side in SIDES}
        content={}
        for side in SIDES:
            if side in uploads:content[side]=uploads[side]
            elif names[side]:content[side]=file_path(names[side]).read_bytes()
        if not content:raise ValueError('يلزم الاحتفاظ بصورة واحدة على الأقل؛ النسخ السابقة تبقى في الأرشيف')
        def write(raw):
            name='monthly-'+secrets.token_hex(16)+'.png';path=file_path(name)
            with path.open('xb') as target:target.write(raw)
            made.append(path);return name
        for side,raw in uploads.items():names[side]=write(raw)
        composite=write(sheet(month,content))
        cur=g.db.execute('''INSERT INTO vehicle_monthly_photos(vehicle_id,month,revision,front,back,right,left,composite,created_at,created_by)
          VALUES(?,?,?,?,?,?,?,?,?,?)''',(vid,month,revision+1,*[names[s] for s in SIDES],composite,now_utc().isoformat(),g.user['id']))
        from .api import audit
        audit('create','vehicle_monthly_photos',cur.lastrowid,'حفظ صورة التحديث الشهري للسيارة',None,dict(vehicle_id=vid,month=month,revision=revision+1))
        row=g.db.execute('SELECT * FROM vehicle_monthly_photos WHERE id=?',(cur.lastrowid,)).fetchone()
        return jsonify(ok=True,record=description(row))
    except (ValueError,OSError) as error:
        g.db.rollback()
        for path in made:path.unlink(missing_ok=True)
        return jsonify(error='تعذر حفظ الصورة الشهرية: '+(str(error) if isinstance(error,ValueError) else 'الصورة السابقة غير متاحة أو تعذرت الكتابة؛ راجع الملفات والمساحة المتاحة')),400
    except Exception:
        g.db.rollback()
        for path in made:path.unlink(missing_ok=True)
        raise


@bp.get('/records/<int:rid>/<slot>')
def image(rid,slot):
    if not g.user:return jsonify(error='يلزم تسجيل الدخول'),401
    if slot not in (*SIDES,'composite'):return jsonify(error='صورة غير موجودة'),404
    row=g.db.execute('SELECT * FROM vehicle_monthly_photos WHERE id=?',(rid,)).fetchone()
    if not row:return jsonify(error='تحديث غير موجود'),404
    denied=authorize(row['vehicle_id'])
    if denied:return denied
    if request.args.get('download')=='1' and not can('vehicles','export'):return jsonify(error='لا تملك صلاحية التنزيل'),403
    try:path=file_path(row[slot])
    except ValueError:return jsonify(error='صورة غير متاحة'),404
    if not path.is_file():return jsonify(error='الصورة غير موجودة'),404
    return send_file(path,mimetype='image/png',as_attachment=request.args.get('download')=='1',download_name=f"vehicle-{row['vehicle_id']}-{row['month']}-r{row['revision']}-{slot}.png",conditional=False)


@bp.get('/records/<int:rid>/archive.zip')
def download(rid):
    if not g.user:return jsonify(error='يلزم تسجيل الدخول'),401
    row=g.db.execute('SELECT * FROM vehicle_monthly_photos WHERE id=?',(rid,)).fetchone()
    if not row:return jsonify(error='تحديث غير موجود'),404
    denied=authorize(row['vehicle_id'],'export')
    if denied:return denied
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as archive:
        for side in (*SIDES,'composite'):
            if row[side]:archive.write(file_path(row[side]),side+'.png')
        archive.writestr('update.json',json.dumps(dict(month=row['month'],vehicle_id=row['vehicle_id'],revision=row['revision'],created_at=row['created_at'],labels=LABELS),ensure_ascii=False))
    out.seek(0);return send_file(out,mimetype='application/zip',as_attachment=True,download_name=f"vehicle-{row['vehicle_id']}-{row['month']}-r{row['revision']}.zip")
