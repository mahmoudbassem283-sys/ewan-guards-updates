"""Opt-in host Windows notifications, administered by the authenticated owner."""
import base64
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from xml.etree import ElementTree as ET

APP_ID = 'EwanGuardsSystem.Desktop'
NAME = 'نظام إدارة عقد الحراسات الأمنية'
PROTOCOL = 'ewan-guards-alerts'


def supported():
    return sys.platform == 'win32'


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {} if default is None else default


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.new')
    tmp.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
    os.replace(tmp, path)


def root_dir():
    return Path(__file__).resolve().parent.parent


def pythonw():
    path = Path(sys.executable).with_name('pythonw.exe')
    if not path.is_file():
        raise RuntimeError('pythonw.exe غير موجود؛ شغّل setup أولًا.')
    return path


def launch(*args):
    return subprocess.Popen([str(pythonw()), str(root_dir() / 'desktop_notify.py'), *map(str, args)],
                            cwd=root_dir(), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, creationflags=0x08000000)


def startup_path():
    return Path(os.environ['APPDATA']) / 'Microsoft/Windows/Start Menu/Programs/Startup/EwanGuardsNotifications.vbs'


def register_windows(data):
    import winreg
    # No URI or user data is interpolated into this command. It only opens our fixed local page.
    command = subprocess.list2cmdline([str(pythonw()), str(root_dir() / 'desktop_notify.py'), '--open', '--data-dir', str(data)])
    values = [
        (f'Software\\Classes\\{PROTOCOL}', '', 'URL:Ewan Guards alerts'),
        (f'Software\\Classes\\{PROTOCOL}', 'URL Protocol', ''),
        (f'Software\\Classes\\{PROTOCOL}\\shell\\open\\command', '', command),
        (f'Software\\Classes\\AppUserModelId\\{APP_ID}', 'DisplayName', NAME),
        (f'Software\\Classes\\AppUserModelId\\{APP_ID}', 'IconUri', str(root_dir() / 'app/static/img/ewan.png')),
    ]
    for key, name, value in values:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key) as k:
            winreg.SetValueEx(k, name, 0, winreg.REG_SZ, value)
    from .windows_shortcut import create_shortcut
    shortcut = Path(os.environ['APPDATA']) / 'Microsoft/Windows/Start Menu/Programs/Ewan Guards.lnk'
    args = subprocess.list2cmdline([str(root_dir() / 'desktop_notify.py'), '--open', '--data-dir', str(data)])
    create_shortcut(shortcut, pythonw(), args, root_dir(), APP_ID, root_dir() / 'EwanGuards.ico')


def enable(data, enabled):
    if not supported():
        raise RuntimeError('هذه الميزة متاحة على ويندوز فقط.')
    data = Path(data)
    if enabled:
        register_windows(data)
        command = subprocess.list2cmdline([str(pythonw()), str(root_dir() / 'desktop_notify.py'), '--worker', '--data-dir', str(data)])
        script = 'CreateObject("WScript.Shell").Run "' + command.replace('"', '""') + '", 0, False\r\n'
        startup_path().parent.mkdir(parents=True, exist_ok=True)
        startup_path().write_text(script, encoding='utf-16')
        write_json(data / 'desktop_notifications.json', {'enabled': True})
        try:
            launch('--worker', '--data-dir', data)
        except Exception:
            write_json(data / 'desktop_notifications.json', {'enabled': False})
            startup_path().unlink(missing_ok=True)
            raise
    else:
        write_json(data / 'desktop_notifications.json', {'enabled': False})
        startup_path().unlink(missing_ok=True)


def get_status(data):
    cfg = read_json(Path(data) / 'desktop_notifications.json')
    state = read_json(Path(data) / 'desktop_notifications_state.json')
    return {'supported': supported(), 'enabled': cfg.get('enabled') is True,
            'last_check': state.get('last_check'), 'last_sent': state.get('last_sent'),
            'error': state.get('error', '')}


def toast_xml(title, message):
    root = ET.Element('toast', {'activationType': 'protocol', 'launch': PROTOCOL + '://expiries'})
    binding = ET.SubElement(ET.SubElement(root, 'visual'), 'binding', {'template': 'ToastGeneric'})
    ET.SubElement(binding, 'image', {'placement':'appLogoOverride', 'src':(root_dir() / 'app/static/img/ewan.png').as_uri(), 'alt':'شعار إيوان'})
    ET.SubElement(binding, 'text').text = NAME
    ET.SubElement(binding, 'text').text = message
    ET.SubElement(root, 'audio', {'src': 'ms-winsoundevent:Notification.Default'})
    return ET.tostring(root, encoding='unicode')


def show_toast(title, message):
    xml = base64.b64encode(toast_xml(title, message).encode('utf-8')).decode('ascii')
    script = f"""$ErrorActionPreference='Stop'
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime] > $null
[Windows.UI.Notifications.ToastNotification, Windows.UI.Notifications, ContentType=WindowsRuntime] > $null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType=WindowsRuntime] > $null
$xml = New-Object Windows.Data.Xml.Dom.XmlDocument
$xml.LoadXml([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{xml}')))
$notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('{APP_ID}')
if ($notifier.Setting.ToString() -ne 'Enabled') {{ throw 'Windows notifications are disabled for this app.' }}
$toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
$toast.Tag='expiry'; $toast.Group='guards'
$toast.ExpirationTime=[DateTimeOffset]::Now.AddDays(1)
$notifier.Show($toast)
"""
    encoded = base64.b64encode(script.encode('utf-16le')).decode('ascii')
    result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
                            capture_output=True, timeout=25, creationflags=0x08000000)
    if result.returncode:
        raise RuntimeError('تعذر إرسال الإشعار. فعّل إشعارات ويندوز وأوقف وضع عدم الإزعاج، ثم جرّب الاختبار.')


def plan(rows, state, day, now):
    """One daily digest; changed dates/stages prompt a new digest after a 15m cooldown."""
    alerts = sorted((r for r in rows if r['status'] in ('expired', 'today', 'soon', 'incomplete')),
                    key=lambda r: (r['expiry_date'] or '9999', str(r['id'])))
    signature = hashlib.sha256(json.dumps([(r['id'], r['expiry_date'], r['status'], r['title'], r['owner_label']) for r in alerts],
                                          ensure_ascii=False).encode()).hexdigest()
    if not alerts:
        return None, signature
    if state.get('day') == day and state.get('signature') == signature:
        return None, signature
    if now - state.get('sent_epoch', 0) < 900:
        return None, signature
    overdue = sum(r['status'] in ('expired', 'today') for r in alerts)
    incomplete = sum(r['status'] == 'incomplete' for r in alerts)
    lines = [f'{overdue} منتهية/اليوم · {len(alerts)-overdue-incomplete} تنتهي قريبًا · {incomplete} غير مكتمل.', 'اضغط لعرض تفاصيل التنبيهات.']
    return '\n'.join(lines), signature


def server_port(data):
    return int(read_json(Path(data) / 'config.json').get('port', 8765))


def ensure_server(data):
    from update_engine import active
    if active(data):return  # Do not race a signed update/restart or recovery.
    with socket.socket() as probe:
        probe.settimeout(1)
        if probe.connect_ex(('127.0.0.1', server_port(data))) == 0:
            return
    subprocess.Popen([str(pythonw()), str(root_dir() / 'run.py'), '--no-browser', '--data-dir', str(data)],
                     cwd=root_dir(), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, creationflags=0x08000000)


def worker(data):
    import msvcrt
    from . import db
    from .dates import today_riyadh, now_utc
    from .reports import tracked_rows, incomplete_rows
    data = Path(data)
    # Kernel file lock is released automatically on exit or crash; one worker per Windows profile.
    with (data / 'desktop_notifications.lock').open('a+b') as lock:
        lock.seek(0)
        if not lock.read(1):
            lock.write(b'0'); lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            return
        state_path = data / 'desktop_notifications_state.json'
        while read_json(data / 'desktop_notifications.json').get('enabled') is True:
            from update_engine import active
            if active(data):
                time.sleep(2);continue
            state = read_json(state_path)
            try:
                ensure_server(data)
                conn = db.connect(data / 'guards.sqlite')
                try:
                    rows = tracked_rows(conn) + incomplete_rows(conn)
                finally:
                    conn.close()
                now = time.time()
                day = today_riyadh().isoformat()
                message, signature = plan(rows, state, day, now)
                # Recheck after database read so disabling suppresses the next notification.
                if read_json(data / 'desktop_notifications.json').get('enabled') is not True:
                    break
                if message:
                    show_toast('تنبيهات الحراسات: الصلاحيات والاستكمال', message)
                    state.update(day=day, signature=signature, sent_epoch=now, last_sent=now_utc().isoformat())
                elif not any(r['status'] in ('expired', 'today', 'soon', 'incomplete') for r in rows):
                    state.update(day=day, signature=signature)
                state.update(error='', last_check=now_utc().isoformat())
            except Exception as exc:
                state.update(error=str(exc)[:250], last_check=now_utc().isoformat())
            write_json(state_path, state)
            for _ in range(60):
                if read_json(data / 'desktop_notifications.json').get('enabled') is not True:
                    return
                time.sleep(1)


def register_api(app):
    from flask import g, jsonify, request

    @app.route('/api/settings/desktop-notifications', methods=['GET', 'PUT', 'POST'])
    def desktop_notifications():
        if not g.user:
            return jsonify(error='يلزم تسجيل الدخول'), 401
        if g.user['role'] != 'owner':
            return jsonify(error='إدارة إشعارات هذا الكمبيوتر للمالك فقط'), 403
        # Owner role above; application-wide Origin and CSRF checks protect mutations.
        # The worker and Windows registration always run on the program host.
        data = app.config['DATA_DIR']
        if request.method == 'GET':
            return jsonify(get_status(data))
        if not supported():
            return jsonify(error='هذه الميزة متاحة على ويندوز فقط'), 400
        try:
            if request.method == 'PUT':
                value = (request.get_json(silent=True) or {}).get('enabled')
                if type(value) is not bool:
                    return jsonify(error='اختر تفعيل أو إيقاف الإشعارات'), 400
                enable(data, value)
            else:
                if not get_status(data)['enabled']:
                    return jsonify(error='فعّل الإشعارات أولًا'), 400
                register_windows(data)
                show_toast('اختبار إشعارات الحراسات', 'الإشعارات جاهزة. اضغط لفتح صفحة تنبيهات انتهاء الوثائق.')
            return jsonify(get_status(data))
        except Exception as exc:
            return jsonify(error=str(exc)), 400
