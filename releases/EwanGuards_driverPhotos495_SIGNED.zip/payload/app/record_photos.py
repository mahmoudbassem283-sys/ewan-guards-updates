"""Optional record photographs, separate from documents, dates and appearance."""
import io, re, secrets, warnings
from flask import Blueprint, current_app, g, jsonify, request, send_file
from PIL import Image, ImageOps, UnidentifiedImageError
from .customize import can
from .security import attachment_path

bp = Blueprint('record_photos', __name__, url_prefix='/api/record-photos')


def init(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS record_photos(
        owner_type TEXT NOT NULL CHECK(owner_type IN ('vehicle','item','driver')),
        owner_id INTEGER NOT NULL, stored_name TEXT NOT NULL,
        PRIMARY KEY(owner_type,owner_id))''')
    conn.commit()
    schema=conn.execute("SELECT sql FROM sqlite_master WHERE name='record_photos'").fetchone()[0]
    if "'driver'" not in schema:
        conn.execute('BEGIN IMMEDIATE')
        try:
            # Recheck under the write lock so concurrent startups migrate only once.
            schema=conn.execute("SELECT sql FROM sqlite_master WHERE name='record_photos'").fetchone()[0]
            if "'driver'" not in schema:
                conn.execute('ALTER TABLE record_photos RENAME TO record_photos_before_driver495')
                conn.execute("CREATE TABLE record_photos(owner_type TEXT NOT NULL CHECK(owner_type IN ('vehicle','item','driver')),owner_id INTEGER NOT NULL,stored_name TEXT NOT NULL,PRIMARY KEY(owner_type,owner_id))")
                conn.execute('INSERT INTO record_photos SELECT owner_type,owner_id,stored_name FROM record_photos_before_driver495')
                conn.execute('DROP TABLE record_photos_before_driver495')
            conn.commit()
        except Exception:
            conn.rollback();raise


def section(kind, oid):
    if kind == 'vehicle':
        return 'vehicles' if g.db.execute('SELECT 1 FROM vehicles WHERE id=?', (oid,)).fetchone() else None
    if kind == 'driver':
        return 'vehicles' if g.db.execute('SELECT 1 FROM drivers WHERE id=?', (oid,)).fetchone() else None
    if kind == 'item':
        row = g.db.execute('SELECT section FROM items WHERE id=?', (oid,)).fetchone()
        return row[0] if row and row[0] in ('equipment', 'vehicles', 'licenses') else None
    return None


def authorize(kind, oid, action='view'):
    if not g.user:
        return jsonify(error='يلزم تسجيل الدخول'), 401
    sec = section(kind, oid)
    if not sec or not can(sec, action):
        return jsonify(error='السجل غير متاح أو لا تملك صلاحية العملية'), 403


def photo_url(kind, oid, name):
    return f'/api/record-photos/{kind}/{oid}/image?v={name}'


@bp.get('')
def listing():
    if not g.user:
        return jsonify(error='يلزم تسجيل الدخول'), 401
    kind, sec = request.args.get('owner_type'), request.args.get('section')
    if kind == 'vehicle':
        sec = 'vehicles'
        sql = "SELECT p.* FROM record_photos p JOIN vehicles v ON v.id=p.owner_id WHERE p.owner_type='vehicle'"
        args = ()
    elif kind == 'driver':
        sec = 'vehicles'
        sql = "SELECT p.* FROM record_photos p JOIN drivers d ON d.id=p.owner_id WHERE p.owner_type='driver'"
        args = ()
    elif kind == 'item' and sec in ('equipment', 'vehicles', 'licenses'):
        sql = "SELECT p.* FROM record_photos p JOIN items i ON i.id=p.owner_id WHERE p.owner_type='item' AND i.section=?"
        args = (sec,)
    else:
        return jsonify(error='نوع السجل غير صالح'), 400
    if not can(sec):
        return jsonify(error='لا تملك صلاحية المشاهدة'), 403
    return jsonify(rows=[dict(owner_id=r['owner_id'], url=photo_url(kind, r['owner_id'], r['stored_name']))
                         for r in g.db.execute(sql, args)])


@bp.get('/<kind>/<int:oid>/image')
def image(kind, oid):
    denied = authorize(kind, oid)
    if denied:
        return denied
    row = g.db.execute('SELECT stored_name FROM record_photos WHERE owner_type=? AND owner_id=?', (kind, oid)).fetchone()
    if not row or not re.fullmatch(r'photo-[a-f0-9]{32}\.png', row[0]):
        return jsonify(error='لا توجد صورة'), 404
    try:
        path = attachment_path(current_app.config['DATA_DIR'], row[0])
    except ValueError:
        return jsonify(error='الصورة غير متاحة'), 404
    if not path.is_file():
        return jsonify(error='الصورة غير متاحة'), 404
    return send_file(path, mimetype='image/png', as_attachment=False, conditional=False)


@bp.post('/<kind>/<int:oid>')
def upload(kind, oid):
    denied = authorize(kind, oid, 'edit')
    if denied:
        return denied
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify(error='اختر صورة PNG أو JPEG أو WebP'), 400
    raw = f.stream.read(8 * 1024 * 1024 + 1)
    if len(raw) > 8 * 1024 * 1024:
        return jsonify(error='حجم الصورة لا يتجاوز 8 ميجابايت'), 400
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(raw)) as im:
                if im.format not in ('PNG', 'JPEG', 'WEBP') or im.width * im.height > 16000000:
                    raise ValueError('نوع الصورة أو أبعادها غير مسموح')
                im.verify()
            with Image.open(io.BytesIO(raw)) as im:
                clean = ImageOps.exif_transpose(im).convert('RGBA')
                clean.thumbnail((1600, 1200))
                encoded = io.BytesIO()
                clean.save(encoded, format='PNG')
    except (OSError, ValueError, UnidentifiedImageError, Image.DecompressionBombError, Image.DecompressionBombWarning):
        return jsonify(error='صورة غير صالحة؛ استخدم PNG أو JPEG أو WebP حتى 16 ميجابكسل'), 400
    name = 'photo-' + secrets.token_hex(16) + '.png'
    path = attachment_path(current_app.config['DATA_DIR'], name)
    g.db.execute('BEGIN IMMEDIATE')
    denied = authorize(kind, oid, 'edit')
    if denied:
        g.db.rollback()
        return denied
    old = g.db.execute('SELECT stored_name FROM record_photos WHERE owner_type=? AND owner_id=?', (kind, oid)).fetchone()
    try:
        with path.open('xb') as target:
            target.write(encoded.getvalue())
        g.db.execute('INSERT OR REPLACE INTO record_photos VALUES(?,?,?)', (kind, oid, name))
        from .api import audit
        audit('update', 'record_photos', f'{kind}:{oid}', 'تغيير صورة السجل',
              dict(stored_name=old[0]) if old else None, dict(stored_name=name))
    except Exception:
        g.db.rollback()
        path.unlink(missing_ok=True)
        raise
    if old:
        remove_file(old[0])
    return jsonify(ok=True, url=photo_url(kind, oid, name))


def remove_file(name):
    if not isinstance(name,str) or not re.fullmatch(r'photo-[a-f0-9]{32}\.png',name):
        return
    try:
        attachment_path(current_app.config['DATA_DIR'], name).unlink(missing_ok=True)
    except (OSError, ValueError):
        pass


@bp.delete('/<kind>/<int:oid>')
def remove(kind, oid):
    denied = authorize(kind, oid, 'delete')
    if denied:
        return denied
    g.db.execute('BEGIN IMMEDIATE')
    row = g.db.execute('SELECT stored_name FROM record_photos WHERE owner_type=? AND owner_id=?', (kind, oid)).fetchone()
    g.db.execute('DELETE FROM record_photos WHERE owner_type=? AND owner_id=?', (kind, oid))
    from .api import audit
    audit('delete', 'record_photos', f'{kind}:{oid}', 'حذف صورة السجل')
    if row:
        remove_file(row[0])
    return jsonify(ok=True)
