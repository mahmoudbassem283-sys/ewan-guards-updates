'use strict';
/* واجهة نظام إدارة الحراسات الأمنية — بلا مكتبات خارجية، وكل النصوص تُدرج كنص (لا innerHTML). */
const SVGNS = 'http://www.w3.org/2000/svg';
let settingsDirty=false, settingsSaveHook=null;
let csrf = '', me = null, today = '', appearance = {}, permissions = {};
const columnCatalog = {}, tableCatalogLabels = {}, widgetCatalog = {}, labelCatalog = new Set();
let catalogPathOverride = null;
const $root = document.getElementById('root');

function el(tag, props, ...kids) {
  const e = document.createElement(tag), late = {};
  if (['label','h1','h2','h3','th','b','button','span','small','p','div','a','option','footer','summary','li'].includes(tag)) kids = kids.map(x => typeof x === 'string' ? displayLabel(x) : x);
  if (tag === 'button' || (tag === 'label' && props && String(props.class).includes('btn'))) {
    const text = kids.filter(x=>typeof x==='string').join('');
    const action = /حذف/.test(text) ? 'delete' : /تعديل|تجديد|تعبئة|اقتراح تواريخ/.test(text) ? 'edit' : /إضافة|جديدة|رفع نسخة/.test(text) ? 'add' : null;
    if (action && me && !isOwner() && !canCurrent(action)) e.hidden = true;
    if (/^تاريخ الانتهاء$/.test(text) && me && !isOwner() && !canCurrent('add') && !canCurrent('edit')) e.hidden=true;
  }
  for (const [k, v] of Object.entries(props || {})) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'value' || k === 'checked') late[k] = v;
    else if (v === true) e.setAttribute(k, '');
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  kids.flat(Infinity).forEach(x => { if (x != null && x !== false) e.append(x.nodeType ? x : document.createTextNode(formatDates(String(x)))); });
  for (const [k, v] of Object.entries(late)) if (v != null) e[k] = v;
  return e;
}
function svg(tag, props, text) {
  const e = document.createElementNS(SVGNS, tag);
  for (const [k, v] of Object.entries(props || {})) e.setAttribute(k, v);
  if (text) e.textContent = text;
  return e;
}
async function api(method, url, body, form) {
  const o = { method, headers: { 'X-CSRF-Token': csrf } };
  if (form) o.body = form; else if (body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
  const r = await fetch(url, o);
  let j = {}; try { j = await r.json(); } catch (e) {}
  if (!r.ok) { if (r.status === 401 && me) { me = null; boot(); } throw new Error(j.error || ('خطأ ' + r.status)); }
  if (!['GET','HEAD'].includes(method) && !/^\/api\/(login|logout|setup|settings|updater)(\/|$)/.test(url)) dataRevision++;
  return j;
}
function toast(msg, bad) {
  const t = el('div', { class: 'toast' + (bad ? ' err' : ''), role: 'status' }, msg);
  document.body.append(t); setTimeout(() => t.remove(), 4500);
}
let dataRevision = 0, refreshedRevision = 0;
const dataModals = new Map();
function watchDataModal(m, draw) { dataModals.set(m.el, draw); return m; }
async function refreshSavedData() {
  if (!me || refreshedRevision === dataRevision) return;
  refreshedRevision = dataRevision;
  // Repaint data, keeping the current route, filters and any open edit form.
  if (!['settings', 'import'].includes(parseHash().path)) await route({background:true});
  for (const [node, draw] of dataModals) {
    if (!node.isConnected) { dataModals.delete(node); continue; }
    await draw();
  }
}
const guarded = fn => async (...a) => {
  const before = dataRevision;
  try { return await fn(...a); } catch (e) { toast(e.message, true); }
  finally { if (dataRevision !== before) { try { await refreshSavedData(); } catch (e) { toast('تم الحفظ؛ تعذر تحديث العرض: '+e.message, true); } } }
};
const isOwner = () => me && me.role === 'owner';
const can = (section, action='view') => !!me && (isOwner() || !!(permissions[section]?.view && permissions[section]?.[action]));
const canCurrent = (action='view') => {const h=parseHash(); return can(h.path==='registers'?(h.params.kind || (can('daily_reports')?'daily_reports':can('weekly_reports')?'weekly_reports':'monthly_reports')):h.path,action);};
const canWrite = () => ['add','edit','delete'].some(a=>canCurrent(a));
function displayLabel(t) { labelCatalog.add(t); return Object.hasOwn(appearance.labels||{},t)?appearance.labels[t]:t; }
function dualDate(iso) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
  const mode=appearance.date_display||'gregorian';
  if(mode==='gregorian')return iso+' '+displayLabel('م');
  try {
    const parts=new Intl.DateTimeFormat('en-u-ca-islamic-umalqura',{year:'numeric',month:'2-digit',day:'2-digit',timeZone:'Asia/Riyadh'}).formatToParts(new Date(iso+'T12:00:00+03:00'));
    const p=Object.fromEntries(parts.map(x=>[x.type,x.value]));
    const h=p.year+'/'+p.month+'/'+p.day+' '+displayLabel('هـ');
    return mode==='both'?iso+' '+displayLabel('م')+' | '+h:h;
  }catch{return iso;}
}
function localTime(t) {
  const d = new Date(/[zZ]|[+-]\d\d:\d\d$/.test(t)?t:t+'Z');
  if(Number.isNaN(d.getTime()))return t;
  const iso = new Intl.DateTimeFormat('en-CA',{year:'numeric',month:'2-digit',day:'2-digit',timeZone:'Asia/Riyadh'}).format(d);
  const time = new Intl.DateTimeFormat('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false,timeZone:'Asia/Riyadh'}).format(d);
  return dualDate(iso)+' — '+time+' (مكة)';
}
function formatDates(t) {
  if (t.includes(' هـ') || /\d{4}-\d{2}-\d{2}\s+م(?:\s|$)/.test(t) || t.includes('(مكة)') || t.includes('\"') || /https?:|\/static\/|\/api\//.test(t)) return t;
  return t.replace(/\b(\d{4}-\d{2}-\d{2})(?:T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)?\b/g, m=>m.includes('T')?localTime(m):dualDate(m));
}
function remaining(days) { return days==null ? badge('غير مسجل','mute') : badge(days<0?'منتهية منذ '+Math.abs(days)+' يوم':days===0?'تنتهي اليوم':'متبقي '+days+' يوم',days<0?'bad':days<=30?'warn':'ok'); }

const L = {
  res: { conforming: 'مطابق', nonconforming: 'غير مطابق', incomplete: 'غير مكتمل', unrecorded: 'لم تسجل', null: 'لم تسجل', undefined: 'لم تسجل' },
  auth: { approved: 'معتمد', rejected: 'مرفوض', unrecorded: 'لم يسجل' },
  st: { valid: 'ساري', soon: 'ينتهي قريبًا', today: 'ينتهي اليوم', expired: 'منتهي', unrecorded: 'تاريخ غير مسجل' },
  link: { saved: 'رابط محفوظ', opened: 'تم فتح الملف', verified: 'محتوى تم التحقق منه' },
  op: { working: 'يعمل', faulty: 'معطل', missing: 'مفقود', maintenance: 'صيانة' },
  sec: { vehicles: 'السيارات والاستمارات', equipment: 'الأجهزة والأدوات', licenses: 'السجلات والتراخيص' },
  roles: { owner: 'المالك', manager: 'المدير', supervisor: 'مشرف المجمع' },
  grp: { core: 'أساسي', relief: 'بديل راحات' },
};
const COL = { conforming: '#0a8579', nonconforming: '#c8481f', incomplete: '#eaa119', unrecorded: '#ffc22d', valid: '#0a8579', soon: '#ffc22d', today: '#f08c00', expired: '#c8481f', approved: '#0a8579', rejected: '#c8481f' };
const badge = (txt, kind) => el('span', { class: 'badge b-' + kind }, txt);
const kindRes = v => v === 'conforming' ? 'ok' : v === 'nonconforming' ? 'bad' : 'warn';
const kindSt = v => ({ valid: 'ok', soon: 'warn', today: 'warn', expired: 'bad', unrecorded: 'mute' })[v] || 'mute';
const resBadge = v => badge(L.res[v || 'unrecorded'], kindRes(v));
const stBadge = v => badge(L.st[v], kindSt(v));
const ltr = t => el('span', { class: 'ltr' }, t == null ? '' : t);
const val = v => (v === null || v === undefined || v === '') ? el('span', { class: 'muted' }, 'غير مسجل') : v;
const qs = o => Object.entries(o).filter(([, v]) => v !== '' && v != null).map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(v)).join('&');

/* ---------- نوافذ ونماذج ---------- */
function modal(title, ...body) {
  const ov = el('div', { class: 'overlay', role: 'dialog', 'aria-modal': 'true' });
  const close = () => { ov.remove(); document.removeEventListener('keydown', esc); };
  const esc = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', esc);
  ov.addEventListener('mousedown', e => { if (e.target === ov) close(); });
  const m = el('div', { class: 'modal' }, el('div', { class: 'row' }, el('h3', { style: 'flex:1' }, title), el('button', { class: 'btn sm', onclick: close, 'aria-label': 'إغلاق' }, 'إغلاق')), body);
  ov.append(m); document.body.append(ov);
  const f = m.querySelector('input,select,textarea'); if (f) f.focus();
  return { close, el: m };
}
function field(f, v) {
  const id = 'f_' + f.k;
  let inp;
  if (f.type === 'select') inp = el('select', { id }, f.options.map(([k, t]) => el('option', { value: k, selected: String(v ?? '') === String(k) }, t)));
  else if (f.type === 'textarea') inp = el('textarea', { id, value: v ?? '' });
  else inp = el('input', { id, type: f.type || 'text', value: v ?? '', step: f.type === 'number' ? 'any' : null, dir: f.ltr ? 'ltr' : null });
  inp.dataset.k = f.k;
  const wrap=el('div', {}, el('label', { for: id }, f.label), inp);
  if(f.type==='date') enhanceDateField(inp,wrap,f.label);
  return wrap;
}
function formModal(title, fields, values, onSave) {
  if (/^(إضافة|حركة جديدة)/.test(title) && !fields.some(f=>f.k==='url' || f.k==='initial_url')) fields=[...fields,{k:'initial_label',label:'اسم المرفق (اختياري)'},{k:'initial_url',label:'رابط المرفق على Drive (اختياري)',ltr:true}];
  const box = el('div', { class: 'kv record-fields' }, fields.map(f => field(f, values[f.k])));
  const m = modal(title, box, el('div', { class: 'row', style: 'margin-top:1rem' },
    el('button', { class: 'btn primary', onclick: guarded(async () => {
      if(box.querySelector('[data-date-invalid="1"]'))throw new Error('صحّح التاريخ الهجري قبل الحفظ');
      const out = {}; box.querySelectorAll('[data-k]').forEach(i => { out[i.dataset.k] = i.value; });
      await onSave(out); m.close();
    }) }, 'حفظ')));
  m.el.classList.add('record-form');
  return m;
}
const confirmBox = (msg, ok) => { const m = modal('تأكيد', el('p', {}, msg), el('div', { class: 'row' }, el('button', { class: 'btn danger', onclick: guarded(async () => { await ok(); m.close(); }) }, 'نعم، نفّذ'), el('button', { class: 'btn', onclick: () => m.close() }, 'إلغاء'))); };

/* ---------- جدول وفلاتر ---------- */
const VEHICLE_COLUMN_KEYS={'المدة المتبقية':'remaining','م':'seq','البند':'item','المطلوب':'required','المتوفر':'available','الانتهاء':'expiry','تاريخ الانتهاء':'expiry','حالة الوثيقة':'status','حالة الاستمارة':'status','حالة الرخصة':'status','المطابقة':'result','مرفق':'attachment','اللوحة':'plate','الموديل':'model','السنة':'year','السائق':'driver','المرفقات':'attachments','الاسم':'name','الرخصة':'license','السيارة':'vehicle','الحركة':'kind','التاريخ':'date','الشخص':'person','العداد':'odometer','':'actions'};
function registerTableCatalog(catalog){for(const [key,schema] of Object.entries(catalog||{})){columnCatalog[key]=schema.columns;tableCatalogLabels[key]=schema.label;}}
function normalizedTableColumns(key,columns,tables){
  const cfg=tables?.[key], source=new Map(columns.map(c=>[c.key,c])),seen=new Set(),out=[];
  for(const c of cfg||[]){if(!source.has(c.key)||seen.has(c.key))continue;out.push({...source.get(c.key),...c});seen.add(c.key);}
  for(const c of columns)if(!seen.has(c.key))out.push({...c,visible:true});
  return out;
}
function table(cols, rows, onRow, options={}) {
  const legacyKey=(catalogPathOverride||parseHash().path)+':'+cols.map(c=>c.h).join('|'),tableKey=options.id||legacyKey;
  const source=cols.map((c,i)=>({...c,key:options.id?(c.key||VEHICLE_COLUMN_KEYS[c.h]||String(i)):String(i)}));
  columnCatalog[tableKey]=source.map((c,i)=>({key:c.key,label:c.h||'الإجراءات'}));
  if(options.label)tableCatalogLabels[tableKey]=options.label;
  const config=appearance.tables?.[tableKey];
  if(options.id){const cfg=normalizedTableColumns(tableKey,columnCatalog[tableKey],appearance.tables);cols=cfg.filter(c=>c.visible!==false).map(c=>({...source.find(x=>x.key===c.key),h:c.label}));}
  else if(config){const used=new Set();cols=config.filter(c=>c.visible!==false&&source[Number(c.key)]&&!used.has(c.key)&&used.add(c.key)).map(c=>({...source[Number(c.key)],h:c.label}));}
  const host=el('div',{'data-table-id':tableKey});
  if(options.id&&isOwner())host.append(el('div',{class:'row table-column-tools noprint'},el('button',{class:'btn sm',onclick:()=>editTableColumns(tableKey)},'تخصيص الأعمدة')));
  if(!cols.length){host.append(el('p',{class:'muted'},'أعمدة هذا الجدول مخفية من إعدادات المظهر.'));return host;}
  if(!rows.length){host.append(el('p',{class:'muted'},'لا توجد سجلات مطابقة.'));return host;}
  host.append(el('div',{class:'tw'},el('table',{},el('thead',{},el('tr',{},cols.map(c=>el('th',{},c.h)))),el('tbody',{},rows.map(r=>el('tr',onRow?{class:'click',tabindex:0,onclick:()=>onRow(r),onkeydown:e=>{if(e.key==='Enter')onRow(r);}}:{},cols.map(c=>el('td',{},c.f(r)))))))));
  return host;
}
function filterBar(defs, params, apply) {
  const inputs = {};
  const bar = el('div', { class: 'filters' }, defs.map(d => {
    const v = params[d.k] ?? '';
    const i = d.type === 'select' ? el('select', { id: 'q_' + d.k }, d.options.map(([k, t]) => el('option', { value: k, selected: v === k }, t)))
      : d.type === 'check' ? el('input', { id: 'q_' + d.k, type: 'checkbox', checked: v === '1' })
      : el('input', { id: 'q_' + d.k, type: d.type || 'text', value: v });
    inputs[d.k] = i;
    return el('div', {}, el('label', { for: 'q_' + d.k }, d.label), i);
  }), el('button', { class: 'btn primary', onclick: () => apply(Object.fromEntries(Object.entries(inputs).map(([k, i]) => [k, i.type === 'checkbox' ? (i.checked ? '1' : '') : i.value]))) }, 'تطبيق'),
    el('button', { class: 'btn', onclick: () => apply({}) }, 'مسح'));
  return bar;
}

/* ---------- الدخول والإعداد ---------- */
async function boot() {
  const s = await (await fetch('/api/status')).json();
  sharedRevision=s.revision;sharedAppearance=JSON.stringify(s.appearance);sharedPermissions=JSON.stringify(s.permissions);sharedUser=JSON.stringify(s.user);
  csrf = s.csrf; me = s.user; today = s.today; appearance=s.appearance||{}; permissions=s.permissions||{};registerTableCatalog(s.table_catalog); applyAppearance();
  if(window.EwanPush) await window.EwanPush.sync();
  if (s.setup_needed) return renderSetup();
  if (!me) return renderLogin();
  renderShell();
}
function authForm(title, intro, fields, btn, onSubmit) {
  const msg = el('p', { class: 'note', hidden: true, role: 'alert' });
  const inputs = fields.map(f => el('input', { id: 'a_' + f.k, type: f.type || 'text', autocomplete: f.ac, dir: 'ltr', style: 'text-align:right' }));
  const go = async () => {
    msg.hidden = true;
    try { await onSubmit(Object.fromEntries(fields.map((f, i) => [f.k, inputs[i].value]))); }
    catch (e) { msg.textContent = e.message; msg.hidden = false; }
  };
  $root.replaceChildren(el('div', { class: 'login' }, el('img', { src: '/static/img/ewan.png', alt: 'شعار إيوان للحراسات الأمنية' }), el('h2', { style: 'text-align:center' }, title),
    intro && el('p', { class: 'muted' }, intro),
    fields.map((f, i) => [el('label', { for: 'a_' + f.k }, f.label), inputs[i]]), msg,
    el('button', { class: 'btn primary', style: 'width:100%;margin-top:1rem', onclick: go }, btn)));
  inputs.forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') go(); }));
  inputs[0].focus();
}
function renderLogin() {
  document.querySelector('.update-banner')?.remove();
  authForm('تسجيل الدخول', null, [{ k: 'username', label: 'اسم المستخدم', ac: 'username' }, { k: 'password', label: 'كلمة المرور', type: 'password', ac: 'current-password' }], 'دخول',
    async v => { const r = await api('POST', '/api/login', v); csrf = r.csrf; if (parseHash().path !== 'expiries') location.hash = '#/dashboard'; boot(); });
}
function renderSetup() {
  authForm('الإعداد الأول', 'أنشئ حساب المالك. اختر كلمة مرور قوية (10 أحرف على الأقل)؛ لا توجد كلمة مرور افتراضية.',
    [{ k: 'username', label: 'اسم مستخدم المالك' }, { k: 'password', label: 'كلمة المرور', type: 'password', ac: 'new-password' }], 'إنشاء الحساب',
    async v => { const r = await api('POST', '/api/setup', v); csrf = r.csrf; location.hash = '#/import'; boot(); });
}

/* ---------- الهيكل والتوجيه ---------- */
const NAV = [['dashboard', 'لوحة التحكم'], ['contract', 'العقد'], ['employees', 'اعتماد الكادر'], ['vehicles', 'السيارات والاستمارات'], ['equipment', 'الأجهزة والأدوات'],
  ['licenses', 'السجلات والتراخيص'], ['registers', 'التقارير اليومية والشهرية'], ['claims', 'المستخلصات الشهرية'], ['expiries', 'الصلاحيات والتنبيهات'], ['reports', 'التقارير', 'reports'], ['import', 'الاستيراد', 'owner'], ['audit', 'سجل التعديلات', 'owner'],
  ['settings', 'إعدادات البرنامج', 'owner'], ['users', 'الحسابات', 'owner'], ['backup', 'النسخ الاحتياطي', 'owner'], ['updates', 'تحديث البرنامج', 'owner']];
const allowed = n => n[0]==='settings' ? can('appearance') : n[2]==='owner' ? isOwner() : n[0]==='registers' ? (can('daily_reports')||can('weekly_reports')||can('monthly_reports')) : can(n[0]);
function renderShell() {
  const side = el('aside', { class: 'side', id: 'side' }, el('img', { class: 'ewan', src: '/static/img/ewan.png', alt: 'شعار إيوان' }),
    el('nav', { 'aria-label': 'القائمة الرئيسية' }, NAV.filter(allowed).map(n => el('a', { href: '#/' + n[0], 'data-r': n[0], onclick: () => { if (window.matchMedia('(max-width:860px)').matches) side.classList.remove('open'); } }, displayLabel(n[1])))));
  const screenMode = window.matchMedia('(max-width:860px)');
  const preferenceKey = () => 'ewan.sidebar.' + me.username + (screenMode.matches ? '.mobile' : '.desktop');
  const shell = el('div', { class: 'shell' });
  const menuButton = el('button', { type: 'button', class: 'btn sm menu-btn sidebar-toggle', 'aria-controls': 'side', onclick: () => {
    setSidebar(!side.classList.contains('open'));
    try { localStorage.setItem(preferenceKey(), side.classList.contains('open') ? 'open' : 'closed'); } catch (_) {}
  } });
  const menuIcon = svg('svg', {viewBox:'0 0 24 24', width:24, height:24, 'aria-hidden':'true'});
  menuIcon.append(svg('rect',{x:3,y:4,width:18,height:16,rx:2,fill:'none',stroke:'currentColor','stroke-width':1.8}),
    svg('path',{d:'M15 4v16',fill:'none',stroke:'currentColor','stroke-width':1.8}));
  menuButton.append(menuIcon);
  function setSidebar(open) {
    side.classList.toggle('open', open);
    shell.classList.toggle('sidebar-collapsed', !open);
    menuButton.setAttribute('aria-expanded', String(open));
    const label = open ? 'إخفاء القائمة الجانبية' : 'إظهار القائمة الجانبية';
    menuButton.setAttribute('aria-label', label); menuButton.title = label;
  }
  function restoreSidebar() {
    let saved; try { saved = localStorage.getItem(preferenceKey()); } catch (_) {}
    setSidebar(saved ? saved === 'open' : !screenMode.matches);
  }
  if (window.cleanupSidebarToggle) window.cleanupSidebarToggle();
  const escapeSidebar = e => { if (e.key === 'Escape' && screenMode.matches && side.classList.contains('open')) {setSidebar(false); menuButton.focus();} };
  screenMode.addEventListener('change', restoreSidebar);
  document.addEventListener('keydown', escapeSidebar);
  window.cleanupSidebarToggle = () => {screenMode.removeEventListener('change', restoreSidebar); document.removeEventListener('keydown', escapeSidebar);};
  side.querySelectorAll('nav a').forEach(a => a.addEventListener('click', () => { if (screenMode.matches) setSidebar(false); }));
  $root.replaceChildren(shell);
  shell.append(
    el('header', { class: 'topbar' }, menuButton,
      el('img', { class: 'authority', src: '/static/img/authority.png', alt: 'شعار الهيئة العامة لعقارات الدولة' }),
      el('div',{class:'brand-title'},el('h1', {}, appearance.title || 'نظام إدارة عقد الحراسات الأمنية'),el('div',{id:'siteSubtitle'},'')),
      el('a',{class:'btn sm',href:'#/notifications'},'الإشعارات'),
      isOwner()&&el('a',{class:'btn sm',href:'#/updates'},'تحديث البرنامج'),
      el('span', { class: 'who' }, (me.display_name || me.username) + ' — ' + L.roles[me.role]),
      el('button', { class: 'btn sm', onclick: guarded(async () => { if(settingsDirty)throw new Error('احفظ إعداداتك أو انتقل بدون حفظ قبل تسجيل الخروج');if(window.EwanPush){try{await window.EwanPush.disable();}catch{}}await api('POST', '/api/logout',{push_device:window.EwanPush?.deviceId()||''}); me = null; boot(); }) }, 'خروج')),
    side, el('main', { id: 'main' }), el('footer', {}, displayLabel('نظام مستقل لإدارة العمليات — ليس منتجًا رسميًا أو معتمدًا من الهيئة العامة لعقارات الدولة.')+' '+displayLabel('التاريخ المرجعي:')+' '+today, el('span',{id:'makkahClock',class:'makkah-clock'})));
  restoreSidebar();
  window.removeEventListener('hashchange', route); window.addEventListener('hashchange', route);
  route();
}
function parseHash() {
  const h = location.hash.replace(/^#\//, '') || 'dashboard', [path, q] = h.split('?');
  return { path, params: Object.fromEntries(new URLSearchParams(q || '')) };
}
const VIEWS = {};
let routeVersion=0;
async function route(options = {}) {
  const background = options.background === true;
  if(settingsDirty&&parseHash().path!=='settings'&&document.querySelector('[data-settings-page]')){warnUnsavedSettings(location.hash);return;}
  const version=++routeVersion;
  const { path, params } = parseHash(), main = document.getElementById('main');
  if (!main) return;
  const nav = NAV.find(n => n[0] === path);
  document.querySelectorAll('.side nav a').forEach(a => a.classList.toggle('on', a.dataset.r === path));
  if (!me || (path !== 'notifications' && (!nav || !allowed(nav)))) { main.replaceChildren(el('div', { class: 'card' }, 'الصفحة غير متاحة لحسابك.')); return; }
  if (!background) main.replaceChildren(el('p', { class: 'muted' }, 'جارٍ التحميل…'));
  try { const content=await VIEWS[path](params); if(version!==routeVersion || parseHash().path!==path)return; content.classList.toggle('ops-page',path!=='dashboard'); content.dataset.operationalPage=path; main.replaceChildren(content); addSectionPrintButton(path); } catch (e) { if(version===routeVersion)main.replaceChildren(el('div', { class: 'card note' }, e.message)); }
  if (!background) window.scrollTo(0, 0);
}
const go = (path, params) => { location.hash = '#/' + path + (params && Object.keys(params).length ? '?' + qs(params) : ''); };
const reload = () => route();

/* ---------- لوحة التحكم ---------- */
function donut(title, segs, hrefBase) {
  const R = 50, C = 2 * Math.PI * R, total = segs.reduce((a, s) => a + s.value, 0);
  const s = svg('svg', { viewBox: '0 0 140 140', width: 150, height: 150, role: 'img', 'aria-label': title });
  s.append(svg('circle', { cx: 70, cy: 70, r: R, fill: 'none', stroke: '#e3ebf1', 'stroke-width': 22 }));
  let off = 0;
  segs.filter(x => x.value > 0).forEach(x => {
    const len = C * x.value / total, a = svg('a', { href: x.href, 'aria-label': x.label + ': ' + x.value }), c = svg('circle', { cx: 70, cy: 70, r: R, fill: 'none', stroke: x.color, 'stroke-width': 22, 'stroke-dasharray': len + ' ' + (C - len), 'stroke-dashoffset': -off, transform: 'rotate(-90 70 70)', style: 'cursor:pointer' });
    c.append(svg('title', {}, x.label + ': ' + x.value)); a.append(c); s.append(a); off += len;
  });
  s.append(svg('text', { x: 70, y: 76, 'text-anchor': 'middle', 'font-size': 22, 'font-weight': 700, fill: '#17303d' }, String(total)));
  return el('div', { class: 'card' }, el('h3', {}, title), el('div', { class: 'donut', 'data-donut': title }, s,
    el('ul', { class: 'legend' }, segs.map(x => el('li', {}, el('a', { href: x.href }, el('span', { class: 'sw', style: 'background:' + x.color }), x.label + ': ', el('b', {}, x.value)))))));
}
VIEWS.dashboard = async () => {
  const d = await api('GET', '/api/dashboard'), e = d.employees, h = '#/';
  const kpi = (cls, t, n, s, href) => el('a', { class: 'kpi k-' + cls, href }, el('div', { class: 't' }, t), el('div', { class: 'n' }, n), el('div', { class: 's' }, s));
  const ex = d.expiry.all;
  const kpis = el('div', { class: 'grid kpis' },
    kpi('blue', 'إجمالي الكادر', e.total, `${e.core} وظيفة أساسية + ${e.relief} بدلاء راحات`, h + 'employees'),
    kpi('teal', 'مطابق وفق مراجعة الاستشاري', e.consultant.conforming, 'من إجمالي الكادر', h + 'employees?consultant=conforming'),
    kpi('orange', 'غير مطابق وفق الاستشاري', e.consultant.nonconforming, `${e.with_nc} موظفًا لديهم اشتراط غير مطابق`, h + 'employees?consultant=nonconforming'),
    kpi('amber', 'لم تسجل له نتيجة', e.consultant.unrecorded, 'لم تُراجع بعد', h + 'employees?consultant=unrecorded'),
    kpi('blue', 'اعتماد الجهة النهائي', e.authority.approved, `معتمد · ${e.authority.rejected} مرفوض · ${e.authority.unrecorded} لم يسجل`, h + 'employees?authority=approved'),
    kpi('teal', 'سيارات مسجلة فرديًا', d.vehicles.registered, `منفصلة عن ${d.vehicles.followup_items} بنود متابعة · ${d.vehicles.drivers} سائقين`, h + 'vehicles'),
    kpi('orange', 'أجهزة وأدوات غير مطابقة', d.equipment.result.nonconforming, `من ${d.equipment.items} بنود · ${d.equipment.short_items} بنود بها نقص كمية`, h + 'equipment?result=nonconforming'),
    kpi('orange', 'وثائق منتهية', ex.expired + ex.today, `${ex.soon} تنتهي خلال 30 يومًا · ${ex.unrecorded} بلا تاريخ مسجل`, h + 'expiries?status=expired,today'),
    kpi('gray', 'روابط ومرفقات محفوظة', d.documents.total, `${d.documents.states.verified} تم التحقق من محتواها (الرابط وحده ليس دليل صلاحية)`, h + 'expiries'));
  const E = d.employees, S = d.expiry.all, Q = d.equipment.result;
  const donuts = el('div', { class: 'grid donuts' },
    donut('مراجعة الاستشاري للكادر', ['conforming', 'nonconforming', 'incomplete', 'unrecorded'].map(k => ({ label: L.res[k], value: E.consultant[k], color: COL[k], href: h + 'employees?consultant=' + k })), ''),
    donut('صلاحية الوثائق وتواريخها', ['valid', 'soon', 'today', 'expired', 'unrecorded'].map(k => ({ label: L.st[k], value: S[k], color: k === 'unrecorded' ? '#8597a5' : COL[k], href: h + 'expiries?status=' + k })), ''),
    donut('مطابقة الأجهزة والأدوات', ['conforming', 'nonconforming', 'incomplete', 'unrecorded'].map(k => ({ label: L.res[k], value: Q[k], color: COL[k], href: h + 'equipment?result=' + k })), ''));
  const att = d.documents.attachments;
  const attCard = el('div', { class: 'card' }, el('h3', {}, 'المستندات المرفقة والناقصة'), el('div', { class: 'tw' }, el('table', {}, el('thead', {}, el('tr', {}, ['القسم', 'له مرفق', 'بلا مرفق'].map(x => el('th', {}, x)))),
    el('tbody', {}, [['employees', 'الكادر', h + 'employees?no_doc=1'], ['vehicles', L.sec.vehicles, h + 'vehicles?no_doc=1'], ['equipment', L.sec.equipment, h + 'equipment?no_doc=1'], ['licenses', L.sec.licenses, h + 'licenses?no_doc=1']].map(([k, t, href]) =>
      el('tr', {}, el('td', {}, t), el('td', {}, att[k].with), el('td', {}, el('a', { href }, att[k].without))))))),
    el('p', { class: 'muted' }, 'وحدات العد مختلفة (موظفون / بنود) فلا تُجمع.'));
  const attn = el('div', { class: 'card' }, el('h3', {}, `تنبيهات ونواقص تحتاج متابعة (${d.attention_total})`),
    d.attention.length ? el('ul', { style: 'padding-inline-start:1.1rem;margin:0' }, d.attention.map(a => el('li', {}, badge(a.kind, a.kind === 'غير مطابق' || a.kind === 'منتهي' ? 'bad' : 'warn'), ' ', el('a', { href: a.href }, a.text)))) : el('p', { class: 'muted' }, 'لا توجد تنبيهات.'));
  const rec = d.recent && el('div', { class: 'card' }, el('h3', {}, 'أحدث التعديلات'), table([{ h: 'الوقت', f: r => ltr(localTime(r.ts)) }, { h: 'المستخدم', f: r => r.username }, { h: 'العملية', f: r => r.summary }], d.recent, () => go('audit')));
  const exl = el('div', { class: 'card' }, el('h3', {}, 'وثائق منتهية أو قريبة الانتهاء'), table([{ h: 'السجل', f: r => r.owner_label }, { h: 'الوثيقة', f: r => r.title }, { h: 'الانتهاء', f: r => ltr(r.expiry_date) }, { h: 'الحالة', f: r => stBadge(r.status) }], d.expiry.list, () => go('expiries', { status: 'expired,today,soon' })));
  return el('div', {}, el('h2', {}, 'لوحة التحكم'), kpis, el('div', { style: 'height:1rem' }), donuts, el('div', { class: 'grid two' }, attn, exl), el('div', { class: 'grid two' }, attCard, rec));
};

/* ---------- المستندات والروابط ---------- */
function docsBlock(ownerType, ownerId, docs, onChange) {
  const rows = docs.map(d => el('tr', {}, el('td', {}, d.label), el('td', {}, d.role === 'contract_ref' ? 'مرجع تعاقدي' : 'مرفق', d.inherited ? ' (خلية مدمجة)' : ''),
    el('td', {}, d.hidden ? badge('مخفي — يتطلب صلاحية الهوية', 'mute') : d.kind === 'local' ? [badge('نسخة محلية', 'info'), ' ', el('a', { href: `/api/documents/${d.id}/file` }, d.local_name)] : el('a', { href: d.url, target: '_blank', rel: 'noopener noreferrer' }, 'فتح على Drive')),
    el('td', {}, canWrite() && !d.inherited ? el('select', { 'aria-label': 'حالة المستند', onchange: guarded(async ev => { await api('PUT', '/api/documents/' + d.id, { link_state: ev.target.value }); toast('تم الحفظ'); }) },
      Object.entries(L.link).map(([k, t]) => el('option', { value: k, selected: d.link_state === k }, t))) : badge(L.link[d.link_state], d.link_state === 'verified' ? 'ok' : 'mute')),
    el('td', {}, canWrite() && !d.inherited && el('span', { class: 'row' },
      d.kind === 'local' && d.local_name.endsWith('.pdf') && el('button', { class: 'btn sm', onclick: guarded(() => suggestDates(d, ownerType, ownerId, onChange)) }, 'اقتراح تواريخ'),
      d.kind==='drive' && el('button',{class:'btn sm',onclick:()=>formModal('تعديل رابط',[{k:'label',label:'اسم المرفق'},{k:'url',label:'الرابط',ltr:true}],d,async v=>{await api('PUT','/api/documents/'+d.id,v);onChange();})},'تعديل الرابط'),
      el('button', { class: 'btn sm danger', onclick: () => confirmBox('حذف هذا المستند/الرابط من البرنامج؟ (لا يُحذف من Drive)', async () => { await api('DELETE', '/api/documents/' + d.id); onChange(); }) }, 'حذف')))));
  const add = canWrite() && el('div', { class: 'row noprint', style: 'margin-top:.5rem' },
    el('button', { class: 'btn sm', onclick: () => formModal('إضافة رابط', [{ k: 'label', label: 'الوصف' }, { k: 'url', label: 'الرابط (https)', ltr: true }], { label: 'مرفق' }, async v => { await api('POST', '/api/documents', { ...v, owner_type: ownerType, owner_id: ownerId }); onChange(); }) }, 'إضافة رابط'),
    el('label', { class: 'btn sm', style: 'margin:0;display:inline-flex;align-items:center' }, 'رفع نسخة محلية', el('input', { type: 'file', hidden: true, accept: '.pdf,.png,.jpg,.jpeg,.docx,.xlsx', onchange: guarded(async ev => {
      const f = new FormData(); f.append('file', ev.target.files[0]); f.append('owner_type', ownerType); f.append('owner_id', ownerId); await api('POST', '/api/documents/upload', undefined, f); onChange(); }) })));
  return el('div', {}, docs.length ? el('div', { class: 'tw' }, el('table', {}, el('thead', {}, el('tr', {}, ['الوصف', 'النوع', 'الملف', 'حالة التحقق', ''].map(x => el('th', {}, x)))), el('tbody', {}, rows))) : el('p', { class: 'muted' }, 'لا توجد مستندات مسجلة.'),
    el('p', { class: 'muted', style: 'font-size:.82rem' }, 'وجود رابط لا يعني صلاحية المستند ولا اعتماد الجهة؛ «تم التحقق» تسجّله أنت بعد فحص المحتوى فعليًا.'), add);
}
async function suggestDates(d, ot, oid, onChange) {
  const r = await api('POST', `/api/documents/${d.id}/suggest`);
  const m = modal('تواريخ مقترحة من ' + d.local_name, r.note && el('p', { class: 'note' }, r.note), el('p', { class: 'muted' }, 'اقتراحات تحتاج تأكيدك؛ حدّد نوع التقويم بنفسك. لا يُعتمد شيء تلقائيًا.'),
    table([{ h: 'النص', f: x => ltr(x.text) }, { h: 'الصفحة', f: x => x.page }, { h: '', f: x => el('span', { class: 'row' }, el('button', { class: 'btn sm primary', onclick: () => { m.close(); expiryModal(ot, oid, { title: '', expiry_raw: x.text }, onChange, x.id); } }, 'تأكيد…'), el('button', { class: 'btn sm', onclick: guarded(async () => { await api('POST', `/api/suggestions/${x.id}/reject`); toast('رُفض'); }) }, 'رفض')) }], r.rows));
}

/* ---------- نافذة تاريخ الانتهاء (ميلادي/هجري) ---------- */
function expiryModal(ot, oid, cur, onDone, sugId, renew) {
  const g = el('input', { type: 'date', id: 'x_g', value: cur.expiry_date || '' });
  const hi = el('input', { id: 'x_h', placeholder: 'يوم/شهر/سنة مثل 19/05/1448', value: cur.calendar === 'hijri' || sugId ? (cur.expiry_raw || '') : '', dir: 'ltr' });
  const cal = el('select', { id: 'x_c' }, [['', '— غير محدد —'], ['gregorian', 'ميلادي'], ['hijri', 'هجري (أم القرى)']].map(([k, t]) => el('option', { value: k, selected: (cur.calendar || '') === k }, t)));
  const title = el('input', { id: 'x_t', value: cur.title || '' }), msg = el('p', { class: 'note', hidden: true });
  const conv = el('button', { class: 'btn sm', type: 'button', onclick: () => {
    const p = Hijri.parseHijriText(hi.value); const iso = p && Hijri.hijriToGregorian(...p);
    if (!iso) { msg.textContent = Hijri.supported() ? 'تعذر التحويل: تأكد من الصيغة ومن صحة اليوم والشهر' : 'المتصفح لا يدعم تقويم أم القرى؛ أدخل التاريخ الميلادي يدويًا'; msg.hidden = false; return; }
    g.value = iso; msg.textContent = 'التاريخ الميلادي المقابل ' + iso + ' — راجعه ثم احفظ'; msg.hidden = false; cal.value = 'hijri'; } }, 'تحويل إلى ميلادي');
  const linkName=el('input',{value:'مرفق الوثيقة',id:'x_link_label'}),linkURL=el('input',{id:'x_link_url',dir:'ltr',placeholder:'https://drive.google.com/...'});
  const m = modal(renew ? 'تجديد وثيقة' : 'تاريخ انتهاء وثيقة', el('div', { class: 'kv' },
    el('div', {}, el('label', { for: 'x_t' }, 'اسم الوثيقة'), title), el('div', {}, el('label', { for: 'x_c' }, 'نوع التقويم الأصلي'), cal),
    el('div', {}, el('label', { for: 'x_h' }, 'التاريخ كما في المستند (للهجري)'), hi, conv), el('div', {}, el('label', { for: 'x_g' }, 'التاريخ الميلادي (المعتمد للتنبيهات)'), g)), msg, (!cur.id && !sugId && !['vehicle','driver'].includes(ot)) && el('div',{class:'kv'},el('div',{},el('label',{},'اسم المرفق (اختياري)'),linkName),el('div',{},el('label',{},'رابط المرفق على Drive (اختياري)'),linkURL)),
    el('p', { class: 'muted' }, 'اترك التاريخ فارغًا ليبقى «غير مسجل». لا يُخمَّن نوع التقويم.'),
    el('div', { class: 'row' }, el('button', { class: 'btn primary', onclick: guarded(async () => {
      if (!title.value.trim()) throw new Error('اسم الوثيقة مطلوب؛ استخدم حذف لإزالة الوثيقة');
      const body = { title: title.value, expiry_date: g.value || '', calendar: cal.value, expiry_raw: hi.value || (cal.value === 'gregorian' ? g.value : ''), doc_type: cur.doc_type, initial_label:linkName.value, initial_url:(!cur.id&&!sugId)?linkURL.value:'' };
      if (sugId) await api('POST', `/api/suggestions/${sugId}/confirm`, { ...body, owner_type: ot, owner_id: oid });
      else if (cur.id) await (renew ? api('POST', `/api/tracked_docs/${cur.id}/renew`, body) : api('PUT', '/api/tracked_docs/' + cur.id, body));
      else await api('POST', '/api/tracked_docs', { ...body, owner_type: ot, owner_id: oid });
      toast('تم الحفظ'); m.close(); onDone(); }) }, 'حفظ')));
}

function trackedActions(ot, oid, t, refresh) {
  return canWrite() && el('span', {class:'row noprint'},
    el('button', {class:'btn sm', onclick:()=>expiryModal(ot, oid, t, refresh)}, 'تعديل تاريخ الانتهاء'),
    el('button', {class:'btn sm', onclick:()=>expiryModal(ot, oid, {...t, expiry_date:''}, refresh, null, true)}, 'تجديد تاريخ الانتهاء'),
    el('button', {class:'btn sm danger', onclick:()=>confirmBox('حذف الوثيقة «'+(t.title||'بدون اسم')+'» وتاريخ انتهائها وسجل تجديدها؟ لن تُحذف السيارة أو السائق.', async()=>{
      await api('DELETE', '/api/tracked_docs/'+t.id); await refresh();
    })}, 'حذف الوثيقة'));
}
function trackedLines(ot, oid, rows, refresh) {
  return rows.map(t=>el('div', {style:'padding:.35rem 0;border-bottom:1px solid #e4edf3'},
    el('div', {}, t.title||'وثيقة بدون اسم', ' ', ltr(t.expiry_date||''), ' ', stBadge(t.status)),
    trackedActions(ot, oid, t, refresh)));
}

/* ---------- العقد ---------- */
VIEWS.contract = async (p={}) => {
  const r = await api('GET', '/api/contract'), c = r.contract || {};
  if(p.review==='1')r.facts=r.facts.filter(x=>x.needs_review);
  if(p.id)r.facts=r.facts.filter(x=>String(x.id)===p.id);
  const edit = canWrite() && el('button', { class: 'btn', onclick: () => formModal('تعديل بيانات العقد', [{ k: 'project_name', label: 'اسم المشروع' }, { k: 'contract_no', label: 'رقم العقد', ltr: true }, { k: 'company', label: 'الشركة' },
    { k: 'sign_date', label: 'تاريخ توقيع العقد (ميلادي)', type: 'date' }, { k: 'handover_date', label: 'تاريخ محضر تسلم الموقع (ميلادي)', type: 'date' }, { k: 'notes', label: 'ملاحظات', type: 'textarea' }], c, async v => { await api('PUT', '/api/contract', v); reload(); }) }, 'تعديل');
  const FACT_FIELDS = [{ k: 'label', label: 'البند' }, { k: 'value_text', label: 'القيمة النصية' }, { k: 'amount', label: 'المبلغ (ريال، اتركه فارغًا إن لم يكن مبلغًا)', type: 'number' }, { k: 'source', label: 'المصدر' },
    { k: 'note', label: 'ملاحظة', type: 'textarea' }, { k: 'needs_review', label: 'يحتاج مراجعة؟', type: 'select', options: [['1', 'نعم'], ['0', 'لا']] }];
  const addFact = canWrite() && el('button', { class: 'btn primary', onclick: () => formModal('إضافة بند للعقد', FACT_FIELDS, { needs_review: '0' }, async v => { await api('POST', '/api/contract_facts', { ...v, needs_review: v.needs_review === '1' }); reload(); }) }, 'إضافة بند');
  const facts = el('div', { class: 'card' }, el('div', { class: 'row' }, el('h3', { style: 'flex:1' }, 'بنود وقيم من نص العقد'), addFact), r.facts.length ? table([{ h: 'البند', f: f => f.label }, { h: 'القيمة', f: f => f.amount != null ? ltr(f.amount.toLocaleString('en-US', { minimumFractionDigits: 2 }) + ' ريال') : f.value_text }, { h: 'المصدر', f: f => f.source + (f.page ? ' — ص' + f.page : '') },
    { h: 'الحالة', f: f => f.needs_review ? badge('يحتاج مراجعة', 'warn') : badge('مسجل', 'ok') }, { h: 'ملاحظة', f: f => f.note || '' }, {h:'المرفقات',f:f=>el('button',{class:'btn sm',onclick:()=>recordDocs('contract_fact',f.id)},'عرض المرفقات')}, { h: '', f: f => canWrite() && el('button', { class: 'btn sm', onclick: () => formModal('تعديل بند', FACT_FIELDS, { ...f, needs_review: f.needs_review ? '1' : '0' }, async v => { await api('PUT', '/api/contract_facts/' + f.id, { ...v, needs_review: v.needs_review === '1' }); reload(); }) }, 'تعديل') }], r.facts) : el('p', { class: 'muted' }, 'لا توجد بنود.'),
    el('p', { class: 'note' }, 'القيمتان الماليتان تختلفان في نص العقد؛ لم يختر البرنامج بينهما وتبقيان للمراجعة.'));
  return el('div', {}, el('h2', {}, 'العقد'), el('div', { class: 'card' }, el('div', { class: 'row' }, el('h3', { style: 'flex:1' }, 'بيانات العقد'), edit),
    el('div', { class: 'kv' }, [['اسم المشروع', c.project_name], ['رقم العقد', c.contract_no && ltr(c.contract_no)], ['الشركة', c.company], ['تاريخ توقيع العقد', c.sign_date && ltr(c.sign_date)], ['تاريخ محضر تسلم الموقع', c.handover_date && ltr(c.handover_date)], ['ملاحظات', c.notes]].map(([k, v]) => el('div', {}, el('b', {}, k), val(v))))),
    facts, el('div', { class: 'card' }, el('h3', {}, 'نسخة العقد ومرفقاته'), docsBlock('contract', 1, r.documents, reload)));
};

/* ---------- الكادر ---------- */
VIEWS.employees = async p => {
  const r = await api('GET', '/api/employees?' + qs(p));
  const bar = filterBar([{ k: 'q', label: me.can_see_full_id ? 'بحث بالاسم أو الهوية' : 'بحث بالاسم' }, { k: 'job_group', label: 'الفئة', type: 'select', options: [['', 'الكل'], ['core', 'أساسي'], ['relief', 'بديل راحات']] },
    { k: 'consultant', label: 'مراجعة الاستشاري', type: 'select', options: [['', 'الكل'], ['conforming', 'مطابق'], ['nonconforming', 'غير مطابق'], ['incomplete', 'غير مكتمل'], ['unrecorded', 'لم تسجل']] },
    { k: 'authority', label: 'اعتماد الجهة', type: 'select', options: [['', 'الكل'], ['approved', 'معتمد'], ['rejected', 'مرفوض'], ['unrecorded', 'لم يسجل']] },
    { k: 'id_status', label: 'صلاحية الهوية', type: 'select', options: [['', 'الكل'], ['expired', 'منتهية'], ['today', 'تنتهي اليوم'], ['soon', 'تنتهي قريبًا'], ['valid', 'سارية']] },
    { k: 'has_nc', label: 'لديه اشتراط غير مطابق', type: 'check' }, { k: 'no_doc', label: 'بلا مرفق', type: 'check' }], p, v => go('employees', v));
  const cols = [{ h: 'م', f: e => e.seq }, { h: 'الاسم', f: e => e.name }, ...(me.can_see_full_id ? [{ h: 'الهوية', f: e => ltr(e.national_id || '') }] : []), { h: 'الوظيفة', f: e => e.job_title }, { h: 'الفئة', f: e => badge(L.grp[e.job_group], e.job_group === 'relief' ? 'info' : 'mute') },
    { h: 'انتهاء الهوية', f: e => ltr(e.id_expiry || '') }, { h: 'حالة الهوية', f: e => validityBadge(e.id_status) }, { h: 'المدة المتبقية', f: e => remaining(e.days_left) }, { h: 'الاستشاري', f: e => resBadge(e.consultant_result) }, { h: 'اعتماد الجهة', f: e => badge(L.auth[e.authority_status || 'unrecorded'], e.authority_status === 'approved' ? 'ok' : e.authority_status === 'rejected' ? 'bad' : 'mute') },
    { h: 'اشتراطات غير مطابقة', f: e => e.nc }, { h: 'مرفقات', f: e => e.doc_count }];
  const add = canWrite() && el('button', { class: 'btn primary', onclick: () => empForm({}, null) }, 'إضافة موظف');
  return el('div', {}, el('div', { class: 'row' }, el('h2', { style: 'flex:1' }, 'اعتماد الكادر'), add), bar, el('div', { class: 'card' }, el('p', { class: 'muted' }, `النتائج: ${r.total}. «مطابق» هنا مراجعة الاستشاري وليست اعتماد الجهة.`), table(cols, r.rows, e => empDetail(e.id))));
};
const EMP_FIELDS = [{ k: 'name', label: 'الاسم' }, { k: 'national_id', label: 'رقم الهوية', ltr: true }, { k: 'job_title', label: 'الوظيفة' }, { k: 'job_group', label: 'الفئة', type: 'select', options: [['core', 'أساسي'], ['relief', 'بديل راحات']] },
  { k: 'phone', label: 'الجوال', ltr: true }, { k: 'site', label: 'الموقع' }, { k: 'shift', label: 'الوردية' }, { k: 'start_date', label: 'تاريخ المباشرة', type: 'date' },
  { k: 'consultant_result', label: 'مراجعة الاستشاري', type: 'select', options: [['', 'لم تسجل'], ['conforming', 'مطابق'], ['nonconforming', 'غير مطابق'], ['incomplete', 'غير مكتمل']] }, { k: 'consultant_note', label: 'ملاحظة الاستشاري', type: 'textarea' },
  { k: 'authority_status', label: 'اعتماد الجهة النهائي', type: 'select', options: [['', 'لم يسجل'], ['approved', 'معتمد'], ['rejected', 'مرفوض']] }, { k: 'authority_date', label: 'تاريخ قرار الجهة', type: 'date' }, { k: 'authority_note', label: 'ملاحظة الجهة', type: 'textarea' }, { k: 'notes', label: 'ملاحظات', type: 'textarea' }];
function empForm(cur, id) { return formModal(id ? 'تعديل موظف' : 'إضافة موظف', EMP_FIELDS, cur, async v => {
    if (id) { await api('PUT', '/api/employees/' + id, v); return; }
    const r = await api('POST', '/api/employees', v); toast('تمت الإضافة؛ عبّئ الاشتراطات من النافذة التالية'); reload(); empDetail(r.id); }); }
async function empDetail(id) {
  const r = await api('GET', '/api/employees/' + id), e = r.employee;
  const body = el('div', {});
  const draw = async () => {
    const r = await api('GET', '/api/employees/' + id), e = r.employee;
    body.replaceChildren(
      el('div', { class: 'kv' }, [['الاسم', e.name], ['الهوية', e.id_hidden ? badge('محجوبة', 'mute') : ltr(e.national_id)], ['الوظيفة', e.job_title], ['الفئة', L.grp[e.job_group]], ['مراجعة الاستشاري', resBadge(e.consultant_result)], ['قيمتها الأصلية في Excel', e.consultant_result_raw],
        ['اعتماد الجهة', L.auth[e.authority_status || 'unrecorded']], ['الجوال', e.phone], ['الموقع', e.site], ['الوردية', e.shift], ['تاريخ المباشرة', e.start_date], ['ملاحظات', e.notes]].map(([k, v]) => el('div', {}, el('b', {}, k), val(v)))),
      canWrite() && el('div', { class: 'row noprint', style: 'margin:.6rem 0' }, el('button', { class: 'btn', onclick: () => empForm(e, id) }, 'تعديل البيانات'),
        el('button', { class: 'btn danger', onclick: () => confirmBox('حذف الموظف وسجلاته؟', async () => { await api('DELETE', '/api/employees/' + id); m.close(); reload(); }) }, 'حذف')),
      el('h3', {}, 'الاشتراطات'), table([{ h: 'الاشتراط', f: c => displayLabel(c.label) }, { h: 'القيمة الأصلية', f: c => c.raw ? ltr(c.raw) : el('span', { class: 'muted' }, 'فارغة') }, { h: 'التفسير', f: c => badge(c.norm_ar, c.norm === 'conforming' ? 'ok' : c.norm === 'nonconforming' ? 'bad' : ['ambiguous','incomplete'].includes(c.norm) ? 'warn' : 'mute') }, { h: 'السبب', f: c => c.reason || '' },
        { h: '', f: c => canWrite() && el('button', { class: 'btn sm', onclick: () => formModal((c.norm === 'empty' ? 'تعبئة اشتراط: ' : 'تعديل اشتراط: ') + c.label, [{ k: 'norm', label: 'التفسير', type: 'select', options: [['conforming', 'مطابق'], ['nonconforming', 'غير مطابق'], ['incomplete', 'غير مكتمل'], ['placeholder', 'لا ينطبق'], ['empty', 'لم يرد']] }, { k: 'reason', label: 'سبب النقص (إن عُرف)', type: 'textarea' }], c, async v => { await api('PUT', '/api/employees/' + id, { checks: [{ key: c.key, ...v }] }); draw(); }) }, c.norm === 'empty' ? 'تعبئة' : 'تعديل') }], r.checks),
      el('p', { class: 'muted', style: 'font-size:.82rem' }, 'العلامتان "-" و"_" علامتا «لا ينطبق» ولا تُحسبان نقصًا؛ والفارغ يعني لم يرد؛ استخدم «تعبئة/تعديل» لتسجيل الحالة والسبب.'),
      el('h3', {}, 'الوثائق وتواريخ الانتهاء'), table([{ h: 'الوثيقة', f: t => t.title }, { h: 'الانتهاء', f: t => ltr(t.expiry_date || '') }, { h: 'الحالة', f: t => stBadge(t.status) },
        { h: '', f: t => canWrite() && el('span', { class: 'row' }, el('button', { class: 'btn sm', onclick: () => expiryModal('employee', id, t, draw) }, 'تعديل'), el('button', { class: 'btn sm', onclick: () => expiryModal('employee', id, { ...t, expiry_date: '' }, draw, null, true) }, 'تجديد')) }], r.tracked),
      canWrite() && el('button', { class: 'btn sm noprint', onclick: () => expiryModal('employee', id, { title: 'صحيفة خلو السوابق' }, draw) }, 'إضافة وثيقة بتاريخ انتهاء'),
      el('h3', {}, 'المرفقات'), docsBlock('employee', id, r.documents, draw));
  };
  const m = watchDataModal(modal(e.name, body), draw); await draw();
}

/* ---------- البنود: سيارات/أجهزة/تراخيص ---------- */
const ITEM_FIELDS = (sec) => [{ k: 'name', label: 'اسم البند' }, { k: 'spec', label: 'المواصفات', type: 'textarea' },
  { k: 'consultant_result', label: 'المطابقة التعاقدية (الاستشاري)', type: 'select', options: [['', 'لم تسجل'], ['conforming', 'مطابق'], ['nonconforming', 'غير مطابق'], ['incomplete', 'غير مكتمل']] },
  ...([{ k: 'required_qty', label: 'المطلوب (حفظه يؤكّده)', type: 'number' }, { k: 'available_qty', label: 'المتوفر', type: 'number' }]),
  ...([{ k: 'unit', label: 'وحدة العد' }, { k: 'op_status', label: 'الحالة التشغيلية', type: 'select', options: [['', 'لم تسجل'], ...Object.entries(L.op)] }, { k: 'location', label: 'الموقع' }, { k: 'responsible', label: 'المسؤول' }]),
  { k: 'note', label: 'ملاحظات', type: 'textarea' }];
const ITEM_ADD_FIELDS = (sec) => [{ k: 'seq', label: 'الرقم (اختياري، يُرقَّم تلقائيًا إن تُرك فارغًا)', type: 'number' }, ...ITEM_FIELDS(sec),
  ...(sec === 'equipment' ? [] : [{ k: 'expiry_date', label: 'تاريخ الانتهاء الميلادي (اختياري؛ للهجري استخدم زر «تاريخ الانتهاء» بعد الإضافة)', type: 'date' }])];
function expiryDays(iso){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(iso||'')||!/^\d{4}-\d{2}-\d{2}$/.test(today||''))return null;
  const end=Date.parse(iso+'T00:00:00Z'),start=Date.parse(today+'T00:00:00Z');
  return Number.isFinite(end)&&Number.isFinite(start)?Math.round((end-start)/86400000):null;
}
function trackedRemaining(rows){
  if(!rows?.length)return remaining(null);
  return rows.map(t=>el('div',{},rows.length>1?el('span',{},(t.title||'وثيقة')+' — '):null,remaining(expiryDays(t.expiry_date))));
}

function itemsView(sec) {
  return async p => {
    const r = await api('GET', '/api/items?' + qs({ ...p, section: sec }));
    const photos=await recordPhotoMap('item',sec);
    const defs = [{ k: 'result', label: 'المطابقة', type: 'select', options: [['', 'الكل'], ['conforming', 'مطابق'], ['nonconforming', 'غير مطابق'], ['incomplete', 'غير مكتمل'], ['unrecorded', 'لم تسجل']] }, { k: 'no_doc', label: 'بلا مرفق', type: 'check' }];
    if (sec === 'equipment') defs.push({ k: 'short', label: 'بها نقص كمية', type: 'check' });
    if (sec !== 'equipment') defs.push({ k: 'expiry', label: 'الصلاحية', type: 'select', options: [['', 'الكل'], ['expired,today', 'منتهي/اليوم'], ['soon', 'قريب'], ['valid', 'ساري'], ['unrecorded', 'غير مسجل']] });
    const cols = [{ h: 'م', f: i => i.seq }, { h: 'البند', f: i => recordLabel(i.name,photos.get(i.id)) }, ...(sec !== 'licenses' ? [{ h: 'المطلوب', f: i => i.required_qty != null ? [i.required_qty, ' ', badge(i.required_qty_confirmed ? 'مؤكد' : 'مقترح', i.required_qty_confirmed ? 'ok' : 'warn')] : val(null) }, { h: 'المتوفر', f: i => val(i.available_qty) }] : []),
      ...(sec === 'equipment' ? [{ h: 'الناقص', f: i => i.short || '—' }, { h: 'الحالة التشغيلية', f: i => i.op_status ? L.op[i.op_status] : val(null) }] : []),
      ...(sec !== 'equipment' ? [{ h: 'الانتهاء', f: i => ltr(i.expiry_date || '') }] : []), ...(sec === 'licenses' ? [{h:'المدة المتبقية',f:i=>remaining(expiryDays(i.expiry_date))}]:[]), ...(sec !== 'equipment' ? [{h:'حالة الوثيقة',f:i=>validityBadge(i.expiry_status)}]:[]), ...(sec !== 'licenses' || true ? [{ h: 'المطابقة', f: i => i.consultant_result_raw !== null || i.consultant_result ? resBadge(i.consultant_result) : badge('لا يوجد عمود نتيجة في المصدر', 'mute') }] : []),
      { h: 'مرفق', f: i => i.has_attachment ? badge('نعم', 'ok') : badge('لا', 'warn') }];
    const addBtn = canWrite() && el('button', { class: 'btn primary', onclick: () => formModal('إضافة بند — ' + L.sec[sec], ITEM_ADD_FIELDS(sec), {}, async v => {
      const body = { ...v, section: sec }; if (body.expiry_date) body.calendar = 'gregorian';
      await api('POST', '/api/items', body); toast('تمت إضافة البند'); reload(); }) }, 'إضافة بند');
    return el('div', {}, el('div', { class: 'row' }, el('h2', { style: 'flex:1' }, L.sec[sec] + (sec === 'vehicles' ? ' — بنود المتابعة' : '')), addBtn), filterBar(defs, p, v => go(sec, v)),

      el('div', { class: 'card' }, table(cols, r.rows, i => itemDetail(sec, i),sec==='vehicles'?{id:'vehicles:followup',label:'السيارات والاستمارات — بنود المتابعة'}:sec==='licenses'?{id:'licenses:main',label:'السجلات والتراخيص — البنود'}:{})));
  };
}
function itemDetail(sec, i) {
  const body = el('div', {});
  const draw = async () => {
    const r = (await api('GET', '/api/items?section=' + sec)).rows.find(x => x.id === i.id);
    if(!r){m.close();return;}
    const photos=await recordPhotoMap('item',sec),photosForRecord=id=>photos.get(id);
    body.replaceChildren(recordPhotoPanel('item',r.id,photosForRecord(r.id),r.name,sec),el('div', { class: 'kv' }, [['البند', r.name], ['المطابقة', resBadge(r.consultant_result)], ['القيمة الأصلية', r.consultant_result_raw], ['المطلوب', r.required_qty != null ? `${r.required_qty} (${r.qty_basis})` : null], ['المتوفر', r.available_qty], ['الناقص', r.short || null], ['وحدة العد', r.unit], ['الحالة التشغيلية', r.op_status && L.op[r.op_status]], ['الموقع', r.location], ['المسؤول', r.responsible], ['ملاحظات', r.note],
      ...(sec !== 'equipment' ? [['الانتهاء', ltr(r.expiry_date || '')], ['حالة الصلاحية', stBadge(r.expiry_status)]] : [])].map(([k, v]) => el('div', {}, el('b', {}, k), val(v)))),
      el('h3', {}, 'المواصفات'), el('p', { style: 'white-space:pre-wrap' }, r.spec || (r.spec_merged_from ? 'خلية مدمجة مع بند رقم ' + r.spec_merged_from + ' في Excel.' : 'غير مسجلة')),
      r.qty_basis && !r.required_qty_confirmed && el('p', { class: 'note' }, 'الكمية المطلوبة استُخرجت من نص المواصفات وتحتاج تأكيدك؛ احفظ القيمة لتأكيدها أو صحّحها.'),
      canWrite() && el('div', { class: 'row noprint' }, el('button', { class: 'btn', onclick: () => recordEditForm('item',r.id,'تعديل: ' + r.name, ITEM_FIELDS(sec), { ...r, consultant_result: r.consultant_result || '', op_status: r.op_status || '' }, async v => { await api('PUT', '/api/items/' + r.id, v); draw(); }) }, 'تعديل'),
        el('button', { class: 'btn danger', onclick: () => confirmBox('حذف البند «' + r.name + '» نهائيًا؟ سيُحذف معه تاريخ انتهائه وسجل تجديده وروابطه ومرفقاته المحلية (لا يُحذف شيء من Drive). المرجع التعاقدي المشترك مع بنود أخرى يبقى لها. يُسجَّل الحذف في سجل التعديلات.',
          async () => { await api('DELETE', '/api/items/' + r.id); m.close(); toast('تم حذف البند'); reload(); }) }, 'حذف البند'),
        sec !== 'equipment' && el('button', { class: 'btn', onclick: async () => { const t = r.tracked_id ? (await api('GET', '/api/tracked_docs?owner_type=item&owner_id=' + r.id)).rows[0] : { title: r.name, doc_type: sec === 'licenses' ? 'license' : 'vehicle_followup' }; expiryModal('item', r.id, t, draw); } }, 'تاريخ الانتهاء')),
      el('h3', {}, 'المرجع التعاقدي والمرفقات'), docsBlock('item', r.id, r.documents, draw));
  };
  const m = watchDataModal(modal(i.name, body), draw); draw();
}
VIEWS.equipment = itemsView('equipment');
VIEWS.licenses = itemsView('licenses');
const vehItems = itemsView('vehicles');
VIEWS.vehicles = async p => {
  const tab = p.tab || 'items', tabs = el('div', { class: 'tabs' }, [['items', 'بنود المتابعة'], ['cars', 'السيارات'], ['drivers', 'رخص السائقين'], ['moves', 'استلام وتسليم']].map(([k, t]) => el('a', { href: '#/vehicles?tab=' + k, class: tab === k ? 'on' : '' }, t)));
  if (tab === 'items') { const v = await vehItems(p); v.insertBefore(tabs, v.children[1]); return v; }
  const wrap = el('div', {}, el('h2', {}, 'السيارات والاستمارات'), tabs);
  if (tab === 'cars') {
    const r = await api('GET', '/api/vehicles'), drivers = (await api('GET', '/api/drivers')).rows;
    const photos=await recordPhotoMap('vehicle');
    if(p.doc_status){r.rows=r.rows.filter(v=>matchesDocumentStatus(v.tracked,p.doc_status));r.total=r.rows.length;}
    const F = [{ k: 'plate', label: 'اللوحة' }, { k: 'model', label: 'الموديل' }, { k: 'year', label: 'سنة الصنع' }, { k: 'driver_id', label: 'السائق', type: 'select', options: [['', 'بدون'], ...drivers.map(d => [d.id, d.name])] }, { k: 'notes', label: 'ملاحظات', type: 'textarea' }];
    wrap.append(el('div', { class: 'card' }, el('div', { class: 'row' }, el('h3', { style: 'flex:1' }, `السيارات المسجلة فرديًا (${r.total})`), canWrite() && el('button', { class: 'btn primary', onclick: () => formModal('إضافة سيارة', F, {}, async v => { await api('POST', '/api/vehicles', v); reload(); }) }, 'إضافة سيارة')),
      r.rows.length ? table([{ h: 'حالة الاستمارة',f:v=>trackedStates(v.tracked) }, { h: 'اللوحة', f: v => val(v.plate) }, { h: 'الموديل', f: v => recordLabel(val(v.model),photos.get(v.id)) }, { h: 'السنة', f: v => val(v.year) }, { h: 'السائق', f: v => (drivers.find(d => d.id === v.driver_id) || {}).name || val(null) },
        { h: 'المرفقات', f:v=>el('button',{class:'btn sm',onclick:()=>recordDocs('vehicle',v.id)},'عرض المرفقات') }, {h:'المدة المتبقية',f:v=>trackedRemaining(v.tracked)}, { h: 'تاريخ الانتهاء', f: v => [trackedLines('vehicle',v.id,v.tracked,reload), !v.tracked.length && canWrite() && el('button', { class: 'btn sm', onclick: () => expiryModal('vehicle', v.id, { title: 'استمارة' }, reload) }, 'تاريخ الانتهاء')] },
        { h: '', f: v => canWrite() && el('span', { class: 'row' }, el('button', { class: 'btn sm', onclick: () => recordEditForm('vehicle',v.id,'تعديل سيارة', F, v, async x => { await api('PUT', '/api/vehicles/' + v.id, x); reload(); }) }, 'تعديل'), el('button', { class: 'btn sm danger', onclick: () => confirmBox('حذف السيارة وسجلاتها؟', async () => { await api('DELETE', '/api/vehicles/' + v.id); reload(); }) }, 'حذف')) }], r.rows,null,{id:'vehicles:cars',label:'السيارات والاستمارات — السيارات'})
        : el('p', { class: 'muted' }, 'لا توجد سيارات مسجلة بعد. لم يُنشئ البرنامج سيارات افتراضية؛ أضفها بياناتها الفعلية.')));
  } else if (tab === 'drivers') {
    const r = await api('GET', '/api/drivers');
    const photos=await recordPhotoMap('driver');
    if(p.doc_status){r.rows=r.rows.filter(v=>matchesDocumentStatus(v.tracked,p.doc_status));r.total=r.rows.length;}
    const F = [{ k: 'name', label: 'اسم السائق' }, { k: 'license_no', label: 'رقم الرخصة', ltr: true }, { k: 'phone', label: 'الجوال', ltr: true }, { k: 'notes', label: 'ملاحظات', type: 'textarea' }];
    wrap.append(el('div', { class: 'card' }, el('div', { class: 'row' }, el('h3', { style: 'flex:1' }, `رخص السائقين (${r.total})`), canWrite() && el('button', { class: 'btn primary', onclick: () => formModal('إضافة سائق', F, {}, async v => { const d=await api('POST', '/api/drivers', v); await reload(); expiryModal('driver',d.id,{title:'رخصة قيادة',doc_type:'driver_license'},reload); }) }, 'إضافة سائق')),
      r.rows.length ? table([{ h: 'حالة الرخصة',f:d=>trackedStates(d.tracked) }, { h: 'الاسم', f: d => recordLabel(d.name,photos.get(d.id)) }, { h: 'الرخصة', f: d => ltr(d.license_no || '') }, { h: 'المرفقات', f:d=>el('button',{class:'btn sm',onclick:()=>recordDocs('driver',d.id)},'عرض المرفقات') }, {h:'المدة المتبقية',f:d=>trackedRemaining(d.tracked)}, { h: 'تاريخ الانتهاء', f: d => [trackedLines('driver',d.id,d.tracked,reload), !d.tracked.length && canWrite() && el('button', { class: 'btn sm', onclick: () => expiryModal('driver', d.id, { title: 'رخصة قيادة', doc_type: 'driver_license' }, reload) }, 'إضافة تاريخ انتهاء الرخصة')] },
        { h: '', f: d => canWrite() && el('span', { class: 'row' }, el('button', { class: 'btn sm', onclick: () => recordEditForm('driver',d.id,'تعديل سائق', F, d, async x => { await api('PUT', '/api/drivers/' + d.id, x); reload(); }) }, 'تعديل'), el('button', { class: 'btn sm danger', onclick: () => confirmBox('حذف السائق؟', async () => { await api('DELETE', '/api/drivers/' + d.id); reload(); }) }, 'حذف')) }], r.rows,null,{id:'vehicles:drivers',label:'السيارات والاستمارات — رخص السائقين'}) : el('p', { class: 'muted' }, 'لا يوجد سائقون مسجلون.')));
  } else {
    const r = await api('GET', '/api/handovers'), cars = (await api('GET', '/api/vehicles')).rows;
    const F = [{ k: 'vehicle_id', label: 'السيارة', type: 'select', options: cars.map(c => [c.id, c.plate || ('سيارة ' + c.id)]) }, { k: 'kind', label: 'الحركة', type: 'select', options: [['receive', 'استلام'], ['handover', 'تسليم']] }, { k: 'event_date', label: 'التاريخ', type: 'date' }, { k: 'person', label: 'الشخص' }, { k: 'odometer', label: 'قراءة العداد' }, { k: 'notes', label: 'ملاحظات', type: 'textarea' }];
    wrap.append(el('div', { class: 'card' }, el('div', { class: 'row' }, el('h3', { style: 'flex:1' }, 'سجل الاستلام والتسليم'), canWrite() && cars.length && el('button', { class: 'btn primary', onclick: () => formModal('حركة جديدة', F, {}, async v => { await api('POST', '/api/handovers', v); reload(); }) }, 'إضافة حركة')),
      !cars.length && el('p', { class: 'muted' }, 'سجّل سيارة أولًا.'), r.rows.length ? table([{ h: 'السيارة', f: h => (cars.find(c => c.id === h.vehicle_id) || {}).plate || h.vehicle_id }, { h: 'الحركة', f: h => h.kind === 'receive' ? 'استلام' : 'تسليم' }, { h: 'التاريخ', f: h => ltr(h.event_date || '') }, { h: 'الشخص', f: h => val(h.person) }, { h: 'العداد', f: h => val(h.odometer) }, {h:'المرفقات',f:h=>el('button',{class:'btn sm',onclick:()=>recordDocs('handover',h.id)},'عرض المرفقات')},
        { h: '', f: h => canWrite() && el('button', { class: 'btn sm danger', onclick: () => confirmBox('حذف الحركة؟', async () => { await api('DELETE', '/api/handovers/' + h.id); reload(); }) }, 'حذف') }], r.rows,null,{id:'vehicles:handovers',label:'السيارات والاستمارات — استلام وتسليم'}) : el('p', { class: 'muted' }, 'لا توجد حركات.')));
  }
  return wrap;
};

/* ---------- الصلاحيات والتنبيهات ---------- */
VIEWS.expiries = async p => {
  const r = await api('GET', '/api/tracked_docs?' + qs(p));
  let desktopCard = null;
  if (isOwner()) {
    const n = await api('GET', '/api/settings/desktop-notifications');
    desktopCard = el('div', {class:'card noprint', 'data-desktop-notifications':true},
      el('h3', {}, 'إشعارات الجهاز الأساسي'),
      el('p', {}, n.enabled ? 'إشعارات ويندوز مفعّلة على الجهاز الأساسي' : 'إشعارات ويندوز متوقفة على الجهاز الأساسي'),
      el('p', {class:'muted'}, 'هذا الإعداد يخص جهاز ويندوز الأساسي الذي يشغّل البرنامج، وليس جهاز المستخدم الذي يفتح الرابط. تنبيه يومي للوثائق المنتهية والقريبة خلال 30 يومًا، يعمل في الخلفية ومع بدء ويندوز حتى لو أغلقت الصفحة. يجب أن يكون الجهاز الأساسي مستيقظًا. تظهر أسماء السجلات في الإشعار.'),
      n.supported ? el('div', {class:'row'},
        el('button', {class:'btn primary', onclick:guarded(async()=>{await api('PUT','/api/settings/desktop-notifications',{enabled:!n.enabled}); toast(n.enabled?'تم إيقاف إشعارات سطح المكتب':'تم تفعيل إشعارات سطح المكتب'); await reload();})}, n.enabled?'إيقاف إشعارات سطح المكتب':'تفعيل إشعارات سطح المكتب'),
        n.enabled && el('button', {class:'btn', onclick:guarded(async()=>{await api('POST','/api/settings/desktop-notifications');toast('تم إرسال الاختبار لويندوز على الجهاز الأساسي؛ تأكد من ظهوره هناك خارج المتصفح');})}, 'اختبار الإشعار')) : el('p', {class:'muted'}, 'متاحة عندما يكون الجهاز الأساسي يعمل بنظام ويندوز.'),
      n.error && el('p', {class:'note'}, n.error),
      el('p', {class:'muted'}, 'لو لم يظهر الاختبار: فعّل إشعارات ويندوز وإشعارات نظام الحراسات، وأوقف مساعد التركيز/عدم الإزعاج.'));
  }
  const bar = filterBar([{ k: 'q', label: 'بحث' }, { k: 'status', label: 'الحالة', type: 'select', options: [['', 'الكل'], ['expired,today', 'منتهي/اليوم'], ['soon', 'ينتهي قريبًا'], ['expired,today,soon', 'منتهي وقريب'], ['valid', 'ساري'], ['unrecorded', 'غير مسجل']] },
    { k: 'owner_type', label: 'النوع', type: 'select', options: [['', 'الكل'], ['employee', 'كادر'], ['item', 'بنود/تراخيص'], ['vehicle', 'سيارات'], ['driver', 'سائقون']] }, { k: 'from', label: 'من', type: 'date' }, { k: 'to', label: 'إلى', type: 'date' }], p, v => go('expiries', v));
  const attendanceCard=r.attendance_alerts?.length&&el('div',{class:'card','data-attendance-alerts':true},el('h3',{},'تنبيهات الحضور والانصراف'),el('ul',{},r.attendance_alerts.map(a=>el('li',{},el('a',{href:a.href},a.text)))));
  const checkCard = r.check_alerts?.length && el('div', {class:'card', 'data-check-alerts':true},
    el('h3', {}, 'اشتراطات كادر غير مطابقة ('+r.check_alerts.length+')'),
    el('p', {class:'muted'}, 'حالة الاشتراط الحالية؛ مستقلة عن تواريخ انتهاء الوثائق وفلاتر التاريخ والحالة أدناه.'),
    table([{h:'الاسم',f:c=>c.name},{h:'الاشتراط',f:c=>displayLabel(c.label)},{h:'الحالة',f:()=>badge('غير مطابق','bad')},{h:'السبب',f:c=>c.reason||'غير مسجل'}],r.check_alerts,c=>empDetail(c.employee_id)));
  const incompleteCard = r.incomplete_alerts?.length && el('div', {class:'card', 'data-incomplete-alerts':true},
    el('h3', {}, `غير مكتمل — يحتاج استكمالًا (${r.incomplete_alerts.length})`),
    el('p', {class:'muted'}, 'مطابق مبدئيًا لكن غير مكتمل. تنبيه مستقل عن تاريخ انتهاء الوثائق؛ يختفي بعد تغيير الحالة إلى مطابق.'),
    table([{h:'السجل',f:t=>t.owner_label},{h:'البند',f:t=>t.title},{h:'الحالة',f:()=>badge('غير مكتمل','warn')},{h:'الملاحظات',f:t=>t.reason||'—'}],r.incomplete_alerts,t=>t.owner_type==='employee'?empDetail(t.owner_id):itemDetail(t.section,{id:t.owner_id})));
  return el('div', {}, el('h2', {}, 'الصلاحيات والتنبيهات'), window.EwanPush && await window.EwanPush.card(), desktopCard, attendanceCard, incompleteCard, checkCard, bar, el('div', { class: 'card' }, el('p', { class: 'muted' }, `السجلات: ${r.total} — الحالات محسوبة من تاريخ اليوم ${today} بتوقيت السعودية؛ التنبيه قبل 30 يومًا.`),
    table([{ h: 'السجل', f: t => t.owner_label }, { h: 'الوثيقة', f: t => t.title }, { h: 'الانتهاء', f: t => ltr(t.expiry_date || '') }, { h: 'المتبقي', f: t => t.days_left == null ? val(null) : t.days_left + ' يوم' }, { h: 'الحالة', f: t => stBadge(t.status) },
      { h: '', f: t => trackedActions(t.owner_type,t.owner_id,t,reload) }], r.rows)));
};

/* ---------- التقارير ---------- */
VIEWS.reports = async p => {
  const list = (await api('GET', '/api/reports')).rows, name = p.name || 'readiness';
  const params = { ...p }; delete params.name;
  const r = await api('GET', `/api/reports/${name}?` + qs(params));
  const defs = [{ k: 'name', label: 'التقرير', type: 'select', options: list.map(x => [x.name, x.title]) }];
  if (['consultant', 'authority'].includes(name)) defs.push({ k: 'status', label: 'الحالة', type: 'select', options: name === 'consultant' ? [['', 'الكل'], ['conforming', 'مطابق'], ['nonconforming', 'غير مطابق'], ['incomplete', 'غير مكتمل'], ['unrecorded', 'لم تسجل']] : [['', 'الكل'], ['approved', 'معتمد'], ['rejected', 'مرفوض'], ['unrecorded', 'لم يسجل']] });
  if (name === 'expiries') defs.push({ k: 'status', label: 'الحالات', type: 'select', options: [['', 'منتهي وقريب'], ['expired,today', 'منتهي/اليوم'], ['soon', 'قريب'], ['valid', 'ساري'], ['unrecorded', 'غير مسجل']] }, { k: 'from', label: 'من تاريخ', type: 'date' }, { k: 'to', label: 'إلى تاريخ', type: 'date' });
  const bar = filterBar(defs, { name, ...params }, v => go('reports', v));
  const rows = r.rows.map(x => Object.fromEntries(r.columns.map(c => [c.key, x[c.key]])));
  return el('div', {}, el('div', { class: 'row noprint' }, el('h2', { style: 'flex:1' }, 'التقارير'), can('reports','print') && el('button', { class: 'btn', onclick: () => window.print() }, 'طباعة / حفظ PDF'), can('reports','export') && el('a', { class: 'btn', href: `/api/export/${name}.xlsx?` + qs(params) }, 'تصدير Excel')), bar,
    el('div', { class: 'card', id: 'reportCard' }, el('div', { class: 'printhead' }, el('img', { src: '/static/img/ewan.png', alt: 'إيوان' }), el('div', {}, appearance.title || 'نظام إدارة عقد الحراسات الأمنية', el('br'), r.title, el('br'), 'تاريخ التقرير: ' + today), el('img', { src: '/static/img/authority.png', alt: 'الهيئة' })),
      el('h3', {}, r.title + ` (${r.rows.length})`), table(r.columns.map(c => ({ h: c.label, f: x => x[c.key] === null || x[c.key] === undefined || x[c.key] === '' ? el('span', { class: 'muted' }, '—') : (c.key.match(/date|national_id/) ? ltr(x[c.key]) : String(x[c.key])) })), rows)));
};

/* ---------- الإدارة ---------- */
VIEWS.audit = async p => {
  const r = await api('GET', '/api/audit?' + qs(p));
  return el('div', {}, el('h2', {}, 'سجل التعديلات'), filterBar([{ k: 'q', label: 'بحث' }, { k: 'entity', label: 'السجل (entity)' }, { k: 'username', label: 'المستخدم' }, { k: 'action', label: 'العملية' }, { k: 'from', label: 'من', type: 'date' }, { k: 'to', label: 'إلى', type: 'date' }], p, v => go('audit', v)),
    el('div', { class: 'card' }, table([{ h: 'الوقت (مكة المكرمة)', f: a => ltr(localTime(a.ts)) }, { h: 'المستخدم', f: a => a.username }, { h: 'العملية', f: a => a.action }, { h: 'السجل', f: a => a.entity + (a.entity_id ? ' #' + a.entity_id : '') }, { h: 'الوصف', f: a => a.summary }], r.rows,
      a => modal('تفاصيل التعديل', el('p', {}, a.summary), a.before_json && [el('h4', {}, 'قبل'), el('pre', { class: 'json' }, a.before_json)], a.after_json && [el('h4', {}, 'بعد'), el('pre', { class: 'json' }, a.after_json)]))));
};
function editUserAccount(u){
  const fields=[{k:'username',label:'اسم الدخول',ltr:true},{k:'display_name',label:'الاسم الظاهر'},{k:'role',label:'الدور',type:'select',options:[['owner','مالك — إدارة كاملة'],['manager','مدير — صلاحيات مخصصة'],['supervisor','مشرف مجمع — صلاحيات مخصصة']]},{k:'active',label:'حالة الحساب',type:'select',options:[['1','مفعّل'],['0','موقوف']]},{k:'can_see_full_id',label:'عرض الهوية كاملة',type:'select',options:[['1','نعم'],['0','لا']]},{k:'password',label:'كلمة مرور جديدة (اتركها فارغة للإبقاء عليها)',type:'password'}];
  formModal('تعديل الحساب — '+u.username,fields,{...u,active:String(u.active),can_see_full_id:String(u.can_see_full_id)},async v=>{
    const own=me.id===u.id;await api('PUT','/api/users/'+u.id,{...v,active:v.active==='1',can_see_full_id:v.can_see_full_id==='1'});toast('تم حفظ بيانات الحساب');
    if(own){await boot();if(me)go('dashboard');}else reload();
  });
}
VIEWS.users = async () => {
  const r=await api('GET','/api/users');
  return el('div',{},el('div',{class:'row'},el('h2',{style:'flex:1'},'الحسابات والصلاحيات'),el('button',{class:'btn primary',onclick:()=>formModal('حساب جديد',[{k:'username',label:'اسم الدخول',ltr:true},{k:'display_name',label:'الاسم الظاهر'},{k:'role',label:'الدور',type:'select',options:[['manager','مدير — صلاحيات مخصصة'],['supervisor','مشرف مجمع — صلاحيات مخصصة'],['owner','مالك — إدارة كاملة']]},{k:'password',label:'كلمة المرور (10 أحرف+)',type:'password'}],{role:'manager'},async v=>{await api('POST','/api/users',v);reload();})},'إضافة حساب')),
    el('div',{class:'card'},table([{h:'اسم الدخول',f:u=>ltr(u.username)},{h:'الاسم الظاهر',f:u=>u.display_name||u.username},{h:'الدور',f:u=>L.roles[u.role]},{h:'حالة الحساب',f:u=>badge(u.active?'مفعّل':'موقوف',u.active?'ok':'mute')},{h:'الإجراءات',f:u=>el('div',{class:'row'},el('button',{class:'btn sm',onclick:()=>editUserAccount(u)},'تعديل بيانات الحساب'),u.role==='owner'?badge('كامل الصلاحيات','info'):el('button',{class:'btn sm',onclick:()=>permissionModal(u)},'تخصيص الصلاحيات'),el('button',{class:'btn sm',onclick:()=>formModal('كلمة مرور جديدة: '+u.username,[{k:'password',label:'كلمة المرور (10 أحرف+)',type:'password'}],{},async v=>{await api('POST',`/api/users/${u.id}/password`,v);toast('تمت إعادة التعيين');})},'إعادة تعيين كلمة المرور'))}],r.rows)),
    el('p',{class:'note'},'المالك يستطيع تعديل بيانات جميع الحسابات، بما فيها حسابه. يلزم بقاء مالك واحد مفعّل على الأقل؛ لإنقاص صلاحيات حساب مالك، وفّر مالكًا آخر ثم غيّر دوره إلى مدير أو مشرف وخصص صلاحياته.'));
};
VIEWS.import = async () => {
  const out = el('div', {});
  const show = (r, token) => out.replaceChildren(el('div', { class: 'card' }, el('h3', {}, 'معاينة الاستيراد: ' + r.filename), el('div', { class: 'kv' }, [['الموظفون', r.summary.employees], ['أساسية', r.summary.core], ['بدلاء', r.summary.relief], ['بنود السيارات', r.summary.items.vehicles], ['بنود الأجهزة', r.summary.items.equipment], ['بنود التراخيص', r.summary.items.licenses],
    ['خلايا الروابط', r.summary.link_cells], ['روابط فريدة', r.summary.unique_urls], ['خلايا الاشتراطات', r.summary.employee_checks], ['موظفون موجودون في القاعدة', r.summary.already_in_db.employees]].map(([k, v]) => el('div', {}, el('b', {}, k), v))),
    r.summary.ambiguous.length ? el('div', { class: 'note' }, el('b', {}, 'قيم غامضة للمراجعة:'), el('ul', {}, r.summary.ambiguous.map(x => el('li', {}, x)))) : el('p', { class: 'muted' }, 'لا توجد قيم غامضة.'),
    el('p', { class: 'muted' }, 'التنفيذ يضيف الجديد فقط ولا يعدّل ولا يكرر ما هو موجود.'),
    el('button', { class: 'btn primary', onclick: guarded(async () => { const c = await api('POST', '/api/import/commit', { token }); out.replaceChildren(el('div', { class: 'card' }, el('h3', {}, 'تم الاستيراد'), el('p', {}, 'المضاف: ' + Object.entries(c.report.added).map(([k, v]) => k + ' ' + v).join('، ')), el('p', {}, 'المتخطى (موجود مسبقًا): ' + Object.entries(c.report.skipped).map(([k, v]) => k + ' ' + v).join('، ')), el('a', { class: 'btn', href: '#/dashboard' }, 'إلى لوحة التحكم'))); }) }, 'تنفيذ الاستيراد')));
  const file = el('input', { type: 'file', accept: '.xlsx', id: 'imp_file' });
  return el('div', {}, el('h2', {}, 'استيراد Excel'), el('div', { class: 'card' }, el('p', {}, 'يُستورد الملف أول مرة فقط؛ بعدها تتم كل الإضافة والتعديل داخل البرنامج دون ربط مستمر بالإكسيل.'),
    el('div', { class: 'row' }, el('button', { class: 'btn', onclick: guarded(async () => { const r = await api('POST', '/api/import/preview'); show(r, r.token); }) }, 'معاينة الملف المرفق مع الحزمة'),
      el('label', { for: 'imp_file', style: 'margin:0' }, 'أو اختر ملفًا:'), file, el('button', { class: 'btn', onclick: guarded(async () => { if (!file.files[0]) throw new Error('اختر ملفًا'); const f = new FormData(); f.append('file', file.files[0]); const r = await api('POST', '/api/import/preview', undefined, f); show(r, r.token); }) }, 'معاينة'))), out);
};
VIEWS.backup = async () => {
  const r = await api('GET', '/api/backup/list');
  return el('div', {}, el('h2', {}, 'النسخ الاحتياطي'), el('div', { class: 'card' }, el('p', {}, 'النسخة تشمل قاعدة البيانات والمرفقات المحلية وإعدادات التشغيل. مجلد النسخ: ', ltr(r.folder)), el('button', { class: 'btn primary', onclick: guarded(async () => { await api('POST', '/api/backup/create'); toast('تم إنشاء النسخة'); reload(); }) }, 'إنشاء نسخة الآن'),
    table([{ h: 'الملف', f: b => ltr(b.name) }, { h: 'الحجم', f: b => Math.round(b.size / 1024) + ' ك.بايت' }, { h: '', f: b => el('a', { class: 'btn sm', href: '/api/backup/download/' + b.name }, 'تنزيل') }], r.rows),
    el('p', { class: 'note' }, 'الاستعادة تتم من خارج البرنامج بعد إيقافه: شغّل restore.bat واتبع التعليمات (موضحة في الدليل). تُحفظ نسخة أمان من الوضع الحالي قبل الاستبدال.')));
};
