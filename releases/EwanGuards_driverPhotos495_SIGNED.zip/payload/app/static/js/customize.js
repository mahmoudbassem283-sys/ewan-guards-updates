'use strict';
const LABEL_CATALOG=["شهادة الفحص الطبي","إلى", "إلى تاريخ", "اسم البند", "اسم السائق", "اسم المستخدم", "اسم المشروع", "اسم مستخدم المالك", "اشتراطات غير مطابقة", "اعتماد الجهة", "اعتماد الجهة النهائي", "الاستشاري", "الاسم", "الاسم الظاهر", "الاشتراط", "الانتهاء", "البند", "التاريخ", "التفسير", "التقرير", "الجوال", "الحالات", "الحالة", "الحالة التشغيلية", "الحجم", "الحركة", "الدور", "الرابط (https)", "الرخصة", "الرقم (اختياري، يُرقَّم تلقائيًا إن تُرك فارغًا)", "السائق", "السبب", "السجل", "السجل (entity)", "السنة", "السيارة", "الشخص", "الشركة", "الصفحة", "الصلاحيات", "الصلاحية", "العداد", "العملية", "الفئة", "القيمة", "القيمة الأصلية", "القيمة النصية", "اللوحة", "المبلغ (ريال، اتركه فارغًا إن لم يكن مبلغًا)", "المتبقي", "المتوفر", "المدة المتبقية", "المرفقات", "المسؤول", "المستخدم", "المصدر", "المطابقة", "المطابقة التعاقدية (الاستشاري)", "المطلوب", "المطلوب (حفظه يؤكّده)", "الملف", "المواصفات", "الموديل", "الموقع", "الناقص", "النص", "النوع", "الهوية", "الوثائق", "الوثيقة", "الوردية", "الوصف", "الوظيفة", "الوقت", "الوقت (مكة المكرمة)", "انتهاء الرخصة", "انتهاء الهوية", "بحث", "بلا مرفق", "بها نقص كمية", "تاريخ الانتهاء الميلادي (اختياري؛ للهجري استخدم زر «تاريخ الانتهاء» بعد الإضافة)", "تاريخ المباشرة", "تاريخ توقيع العقد (ميلادي)", "تاريخ قرار الجهة", "تاريخ محضر تسلم الموقع (ميلادي)", "رقم الرخصة", "رقم العقد", "رقم الهوية", "سبب النقص (إن عُرف)", "سنة الصنع", "صلاحية الهوية", "قراءة العداد", "كلمة المرور", "كلمة المرور (10 أحرف+)", "لديه اشتراط غير مطابق", "م", "مراجعة الاستشاري", "مرفق", "مرفقات", "ملاحظات", "ملاحظة", "ملاحظة الاستشاري", "ملاحظة الجهة", "من", "من تاريخ", "وحدة العد", "يحتاج مراجعة؟"];
Object.assign(columnCatalog,{"dashboard:الوقت|المستخدم|العملية": [{"key": "0", "label": "الوقت"}, {"key": "1", "label": "المستخدم"}, {"key": "2", "label": "العملية"}], "dashboard:السجل|الوثيقة|الانتهاء|الحالة": [{"key": "0", "label": "السجل"}, {"key": "1", "label": "الوثيقة"}, {"key": "2", "label": "الانتهاء"}, {"key": "3", "label": "الحالة"}], "employees:م|الاسم|الهوية|الوظيفة|الفئة|انتهاء الهوية|المدة المتبقية|الاستشاري|اعتماد الجهة|اشتراطات غير مطابقة|مرفقات": [{"key": "0", "label": "م"}, {"key": "1", "label": "الاسم"}, {"key": "2", "label": "الهوية"}, {"key": "3", "label": "الوظيفة"}, {"key": "4", "label": "الفئة"}, {"key": "5", "label": "انتهاء الهوية"}, {"key": "6", "label": "المدة المتبقية"}, {"key": "7", "label": "الاستشاري"}, {"key": "8", "label": "اعتماد الجهة"}, {"key": "9", "label": "اشتراطات غير مطابقة"}, {"key": "10", "label": "مرفقات"}], "registers:اسم البند|التاريخ|مرفق التقرير اليومي|ملاحظات|الإجراءات": [{"key": "0", "label": "اسم البند"}, {"key": "1", "label": "التاريخ"}, {"key": "2", "label": "مرفق التقرير اليومي"}, {"key": "3", "label": "ملاحظات"}, {"key": "4", "label": "الإجراءات"}], "claims:اسم البند|التاريخ|مرفق المستخلص الشهري|ملاحظات|الإجراءات": [{"key": "0", "label": "اسم البند"}, {"key": "1", "label": "التاريخ"}, {"key": "2", "label": "مرفق المستخلص الشهري"}, {"key": "3", "label": "ملاحظات"}, {"key": "4", "label": "الإجراءات"}], "contract:البند|القيمة|المصدر|الحالة|ملاحظة|المرفقات|": [{"key": "0", "label": "البند"}, {"key": "1", "label": "القيمة"}, {"key": "2", "label": "المصدر"}, {"key": "3", "label": "الحالة"}, {"key": "4", "label": "ملاحظة"}, {"key": "5", "label": "المرفقات"}, {"key": "6", "label": "إجراءات 7"}], "equipment:م|البند|المطلوب|المتوفر|الناقص|الحالة التشغيلية|المطابقة|مرفق": [{"key": "0", "label": "م"}, {"key": "1", "label": "البند"}, {"key": "2", "label": "المطلوب"}, {"key": "3", "label": "المتوفر"}, {"key": "4", "label": "الناقص"}, {"key": "5", "label": "الحالة التشغيلية"}, {"key": "6", "label": "المطابقة"}, {"key": "7", "label": "مرفق"}], "licenses:م|البند|الانتهاء|المطابقة|مرفق": [{"key": "0", "label": "م"}, {"key": "1", "label": "البند"}, {"key": "2", "label": "الانتهاء"}, {"key": "3", "label": "المطابقة"}, {"key": "4", "label": "مرفق"}], "vehicles:م|البند|المطلوب|المتوفر|الانتهاء|المطابقة|مرفق": [{"key": "0", "label": "م"}, {"key": "1", "label": "البند"}, {"key": "2", "label": "المطلوب"}, {"key": "3", "label": "المتوفر"}, {"key": "4", "label": "الانتهاء"}, {"key": "5", "label": "المطابقة"}, {"key": "6", "label": "مرفق"}], "expiries:السجل|الوثيقة|الانتهاء|المتبقي|الحالة|": [{"key": "0", "label": "السجل"}, {"key": "1", "label": "الوثيقة"}, {"key": "2", "label": "الانتهاء"}, {"key": "3", "label": "المتبقي"}, {"key": "4", "label": "الحالة"}, {"key": "5", "label": "إجراءات 6"}], "reports:المجال|المؤشر|القيمة": [{"key": "0", "label": "المجال"}, {"key": "1", "label": "المؤشر"}, {"key": "2", "label": "القيمة"}], "audit:الوقت (مكة المكرمة)|المستخدم|العملية|السجل|الوصف": [{"key": "0", "label": "الوقت (مكة المكرمة)"}, {"key": "1", "label": "المستخدم"}, {"key": "2", "label": "العملية"}, {"key": "3", "label": "السجل"}, {"key": "4", "label": "الوصف"}], "registers:اسم البند|التاريخ|مرفق التقرير الشهري|ملاحظات|الإجراءات": [{"key": "0", "label": "اسم البند"}, {"key": "1", "label": "التاريخ"}, {"key": "2", "label": "مرفق التقرير الشهري"}, {"key": "3", "label": "ملاحظات"}, {"key": "4", "label": "الإجراءات"}]});
Object.assign(columnCatalog,{"vehicles:اللوحة|الموديل|السنة|السائق|المرفقات|الوثائق|": [{"key": "0", "label": "اللوحة"}, {"key": "1", "label": "الموديل"}, {"key": "2", "label": "السنة"}, {"key": "3", "label": "السائق"}, {"key": "4", "label": "المرفقات"}, {"key": "5", "label": "الوثائق"}, {"key": "6", "label": "الإجراءات"}], "vehicles:الاسم|الرخصة|المرفقات|انتهاء الرخصة|": [{"key": "0", "label": "الاسم"}, {"key": "1", "label": "الرخصة"}, {"key": "2", "label": "المرفقات"}, {"key": "3", "label": "انتهاء الرخصة"}, {"key": "4", "label": "الإجراءات"}], "vehicles:السيارة|الحركة|التاريخ|الشخص|العداد|المرفقات|": [{"key": "0", "label": "السيارة"}, {"key": "1", "label": "الحركة"}, {"key": "2", "label": "التاريخ"}, {"key": "3", "label": "الشخص"}, {"key": "4", "label": "العداد"}, {"key": "5", "label": "المرفقات"}, {"key": "6", "label": "الإجراءات"}], "employees:الاشتراط|الحالة|القيمة الأصلية|سبب عدم المطابقة|": [{"key": "0", "label": "الاشتراط"}, {"key": "1", "label": "الحالة"}, {"key": "2", "label": "القيمة الأصلية"}, {"key": "3", "label": "سبب عدم المطابقة"}, {"key": "4", "label": "الإجراءات"}], "employees:الوثيقة|الانتهاء|الحالة|": [{"key": "0", "label": "الوثيقة"}, {"key": "1", "label": "الانتهاء"}, {"key": "2", "label": "الحالة"}, {"key": "3", "label": "الإجراءات"}], "reports:م|الاسم|رقم الهوية|الوظيفة|الفئة|مراجعة الاستشاري|اشتراطات غير مطابقة": [{"key": "0", "label": "م"}, {"key": "1", "label": "الاسم"}, {"key": "2", "label": "رقم الهوية"}, {"key": "3", "label": "الوظيفة"}, {"key": "4", "label": "الفئة"}, {"key": "5", "label": "مراجعة الاستشاري"}, {"key": "6", "label": "اشتراطات غير مطابقة"}], "reports:م|الاسم|الوظيفة|الفئة|مراجعة الاستشاري|اشتراطات غير مطابقة": [{"key": "0", "label": "م"}, {"key": "1", "label": "الاسم"}, {"key": "2", "label": "الوظيفة"}, {"key": "3", "label": "الفئة"}, {"key": "4", "label": "مراجعة الاستشاري"}, {"key": "5", "label": "اشتراطات غير مطابقة"}]});
const sectionNames={dashboard:'لوحة التحكم',contract:'العقد',employees:'اعتماد الكادر',vehicles:'السيارات والاستمارات',equipment:'الأجهزة والأدوات',licenses:'السجلات والتراخيص',expiries:'الصلاحيات والتنبيهات',reports:'تقارير الجاهزية',daily_reports:'التقارير اليومية',weekly_reports:'التقارير الأسبوعية',attendance:'الحضور والانصراف',monthly_reports:'التقارير الشهرية',claims:'المستخلصات الشهرية'};
const actionNames={view:'مشاهدة',add:'إضافة',edit:'تعديل',delete:'حذف',export:'تصدير',print:'طباعة'};
const widgetDefs=[['staff_total','إجمالي الكادر','employees'],['staff_conforming','مطابق وفق مراجعة الاستشاري','employees'],['staff_nonconforming','غير مطابق وفق الاستشاري','employees'],['staff_pending','لم تسجل له نتيجة','employees'],['staff_approved','اعتماد الجهة النهائي','employees'],['fleet_total','سيارات مسجلة فرديًا','vehicles'],['equipment_nc','أجهزة وأدوات غير مطابقة','equipment'],['expired_total','وثائق منتهية','expiries'],['docs_total','روابط ومرفقات محفوظة','dashboard'],['chart_staff','مراجعة الاستشاري للكادر','employees'],['chart_expiry','صلاحية الوثائق وتواريخها','expiries'],['chart_equipment','مطابقة الأجهزة والأدوات','equipment'],['attention','تنبيهات ونواقص تحتاج متابعة','dashboard'],['expiry_list','وثائق منتهية أو قريبة الانتهاء','expiries'],['attachments','المستندات المرفقة والناقصة','dashboard'],['recent','أحدث التعديلات','audit']];
widgetDefs.forEach(([key,label,section],order)=>widgetCatalog[key]={key,label,section,order});
function textColor(hex) { const c=hex.replace('#',''); const vals=[0,2,4].map(i=>parseInt(c.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4); return vals[0]*.2126+vals[1]*.7152+vals[2]*.0722>.4?'#17303d':'#ffffff'; }
function applyAppearance(){
  const a=appearance, st=document.documentElement.style;
  for(const [k,v] of Object.entries(a.colors||{}))st.setProperty('--'+k,v);
  for(const k of ['blue','teal','orange','amber','gray']) if(a.colors?.[k])st.setProperty('--'+k+'-text',textColor(a.colors[k]));
  const w=a.watermark||{}; st.setProperty('--wm-image',w.src?'url("'+w.src+'")':'none');st.setProperty('--wm-size',(w.size||520)+'px');st.setProperty('--wm-opacity',w.visible===false?'0':String((w.opacity??5)/100));
  document.title=a.title||'نظام إدارة عقد الحراسات الأمنية';
}
function brandingDOM(){
  const a=appearance;
  const map={login:'.login > img',sidebar:'.side > img.ewan',header:'.topbar > img.authority'};
  for(const [k,sel] of Object.entries(map))document.querySelectorAll(sel).forEach(img=>{img.src=a.logos?.[k]||'/static/img/'+(k==='header'?'authority':'ewan')+'.png';img.hidden=a.logo_visible?.[k]===false;const oldSize=a.sizes?.[k];const logoSize=k==='header'&&(!oldSize||oldSize===76)?112:k==='sidebar'&&(!oldSize||oldSize===150)?180:(oldSize||100);img.style.height=logoSize+'px';img.style.width='auto';img.style.maxWidth='100%';img.style.objectFit='contain';});
  const host=document.querySelector('.topbar')||document.querySelector('.login');
  if(host){let img=host.querySelector('.consultant-logo');if(a.logos?.consultant && a.logo_visible?.consultant!==false){if(!img){img=el('img',{class:'consultant-logo',alt:'شعار الاستشاري'});host.append(img);}img.src=a.logos.consultant;img.style.height=(a.sizes?.consultant||90)+'px';img.style.maxWidth='180px';img.style.objectFit='contain';}else if(img)img.remove();}
  document.querySelectorAll('.printhead img').forEach((img,i)=>{img.src=a.logos?.[i?'header':'sidebar']||img.src;});
  const clock=document.getElementById('makkahClock');if(clock){const t=localTime(new Date().toISOString());if(clock.textContent!==t)clock.textContent=t;}
  // الحقول التاريخية تعرض المقابل الهجري أسفلها؛ التحويل المعتمد يبقى في نافذة التاريخ.

}
let queued=false;
new MutationObserver(()=>{if(!queued){queued=true;requestAnimationFrame(()=>{queued=false;brandingDOM();});}}).observe($root,{childList:true,subtree:true});
// النافذة ليست داخل root؛ تهيئة حقول التاريخ فيها مرة واحدة بعد إضافتها.
new MutationObserver(changes=>{if(changes.some(c=>[...c.addedNodes].some(n=>n.nodeType===1&&n.classList.contains('overlay'))))brandingDOM();}).observe(document.body,{childList:true});
setInterval(()=>{const c=document.getElementById('makkahClock');if(c)c.textContent=localTime(new Date().toISOString());},1000);
// أوقات التنبيهات تتحدث عند العودة للنافذة وفي اليوم الجديد دون ترك نموذج مفتوح.
setInterval(async()=>{if(!me||document.hidden||document.querySelector('.overlay'))return;try{const r=await api('GET','/api/status');const changed=today!==r.today;today=r.today;permissions=r.permissions;if(changed)reload();}catch{}},60000);
const baseDashboard=VIEWS.dashboard;
VIEWS.dashboard=async()=>{
  const view=await baseDashboard();const kpis=view.querySelector('.kpis'), donuts=view.querySelector('.donuts');
  const all=[...kpis.children,...donuts.children,...view.querySelectorAll('.grid.two > .card')];
  all.forEach((node,i)=>{const def=widgetDefs[i];if(!def)return;const [key,label,section]=def,cfg=appearance.widgets?.[key]||{};node.dataset.widget=key;node.style.order=String(cfg.order??i);node.hidden=cfg.visible===false||!can(section);const title=node.querySelector('.t,h3');if(title&&cfg.label)title.textContent=cfg.label;if(cfg.color){node.style.background=cfg.color;node.style.color=textColor(cfg.color);}});
  return view;
};
async function recordDocs(type,id){const box=el('div',{});const draw=async()=>{const r=await api('GET',`/api/documents?owner_type=${type}&owner_id=${id}`);box.replaceChildren(docsBlock(type,id,r.rows,draw));};watchDataModal(modal('المرفقات',box),draw);await draw();}
async function permissionModal(u){
  const r=await api('GET',`/api/users/${u.id}/permissions`), draft=structuredClone(r.permissions), checks={};
  const rows=Object.entries(r.sections).map(([s,label])=>el('tr',{},el('th',{},label),Object.entries(actionNames).map(([action,t])=>{const cb=el('input',{type:'checkbox',checked:!!draft[s]?.[action],'aria-label':label+' — '+t});checks[s+':'+action]=cb;return el('td',{},cb);} )));
  const box=el('div',{class:'tw'},el('table',{},el('thead',{},el('tr',{},el('th',{},'القسم'),Object.values(actionNames).map(t=>el('th',{},t)))),el('tbody',{},rows)));
  const m=modal('صلاحيات '+u.display_name,el('p',{class:'note'},'إلغاء المشاهدة يمنع جميع عمليات القسم. التصدير والطباعة تخص التقارير الحالية؛ إلغاء الطباعة لا يمنع أدوات المتصفح أو تصوير الشاشة. إدارة الحسابات والسجل والنسخ الاحتياطي للمالك؛ يمكن منح تخصيص اللوحات والمظهر وقواعد المخاطر بشكل مستقل.'),box,
    el('button',{class:'btn primary',onclick:guarded(async()=>{for(const s of Object.keys(r.sections)){draft[s]={};for(const a of Object.keys(actionNames))draft[s][a]=checks[s+':view'].checked&&checks[s+':'+a].checked;}await api('PUT',`/api/users/${u.id}/permissions`,{permissions:draft});m.close();toast('تم حفظ الصلاحيات');reload();})},'حفظ الصلاحيات'));
}
function registerView(section){return async p=>{
  const base=section==='registers'?(can('daily_reports')?'daily_reports':can('weekly_reports')?'weekly_reports':'monthly_reports'):section;
  const actual=p.kind&&['daily_reports','weekly_reports','monthly_reports'].includes(p.kind)&&section!=='claims'?p.kind:base;
  if(!can(actual))return el('p',{class:'note'},'هذا القسم غير متاح لحسابك');
  const r=await api('GET','/api/registers?section='+actual+'&'+qs({attachment:p.attachment})),weekly=actual==='weekly_reports',monthly=actual==='monthly_reports',claim=actual==='claims',label=claim?'مرفق المستخلص الشهري':monthly?'مرفق التقرير الشهري':weekly?'مرفق التقرير الأسبوعي':'مرفق التقرير اليومي';
  const F=[{k:'name',label:claim?'اسم المستخلص':'اسم التقرير'},{k:'event_date',label:'التاريخ',type:'date'},{k:'url',label:label+' — رابط Drive',ltr:true},{k:'notes',label:'ملاحظات',type:'textarea'}];
  const edit=row=>formModal((row.id?'تعديل ':'إضافة ')+(claim?'مستخلص':'تقرير'),F,row,async v=>{await api(row.id?'PUT':'POST','/api/registers'+(row.id?'/'+row.id:''),{...v,section:actual});toast('تم الحفظ');reload();});
  const tabs=!claim&&el('div',{class:'tabs'},['daily_reports','weekly_reports','monthly_reports'].filter(x=>can(x)).map(x=>el('a',{href:'#/registers?kind='+x,class:actual===x?'on':''},sectionNames[x])));
  return el('div',{},el('div',{class:'row'},el('h2',{style:'flex:1'},sectionNames[actual]),can(actual,'add')&&el('button',{class:'btn primary',onclick:()=>edit({event_date:today})},claim?'إضافة مستخلص':'إضافة تقرير')),tabs,
    el('div',{class:'card'},table([{h:'اسم البند',f:x=>x.name},{h:'التاريخ',f:x=>ltr(x.event_date)},{h:label,f:x=>x.url?el('a',{href:x.url,target:'_blank',rel:'noopener noreferrer'},label):badge('لم يرد','warn')},{h:'ملاحظات',f:x=>x.notes||''},{h:'الإجراءات',f:x=>el('div',{class:'row'},can(actual,'edit')&&el('button',{class:'btn sm',onclick:()=>edit(x)},'تعديل'),can(actual,'delete')&&el('button',{class:'btn sm danger',onclick:()=>confirmBox('حذف هذا السجل من البرنامج؟ الملف على Drive لا يتغير.',async()=>{await api('DELETE','/api/registers/'+x.id);reload();})},'حذف'))}],r.rows)));
};}
VIEWS.registers=registerView('registers');VIEWS.claims=registerView('claims');
// سياق القسم الفعلي للتقارير اليومية والشهرية

/* Section-grouped settings catalogs use UI definitions, never record values. */
const SETTINGS_SECTION_ORDER=['dashboard','contract','employees','vehicles','equipment','licenses','attendance','daily_reports','weekly_reports','monthly_reports','claims','expiries','notifications','reports','users','audit','import','backup','settings','updates','shared'];
const SETTINGS_SECTION_NAMES={...sectionNames,users:'الحسابات',audit:'سجل التعديلات',import:'الاستيراد',backup:'النسخ الاحتياطي',settings:'إعدادات البرنامج',updates:'تحديث البرنامج',notifications:'الإشعارات',shared:'مسميات مشتركة'};
const SETTINGS_EXTRA_LABELS={
 contract:['العقد','اسم المشروع','رقم العقد','الشركة','تاريخ توقيع العقد (ميلادي)','تاريخ محضر تسلم الموقع (ميلادي)','القيمة النصية','المصدر','يحتاج مراجعة؟'],
 employees:['اعتماد الكادر','شهادة الفحص الطبي','الاسم','الهوية','رقم الهوية','الوظيفة','الفئة','تاريخ المباشرة','انتهاء الهوية','حالة الهوية','المدة المتبقية','الاستشاري','اعتماد الجهة','اشتراطات غير مطابقة','المؤهل','الحس الأمني','الخبرة العسكرية','القيادة','صحيفة السوابق'],
 vehicles:['السيارات والاستمارات','بنود المتابعة','السيارات','رخص السائقين','استلام وتسليم','اللوحة','الموديل','سنة الصنع','السنة','رقم الرخصة','حالة الاستمارة','حالة الرخصة','تاريخ الانتهاء','المدة المتبقية','المرفقات'],
 licenses:['السجلات والتراخيص','البند','الانتهاء','المدة المتبقية','حالة الوثيقة','المطابقة','مرفق'],
 equipment:['الأجهزة والأدوات','البند','المطلوب','المتوفر','الناقص','الحالة التشغيلية','المطابقة','مرفق'],
 users:['الحسابات','الحسابات والصلاحيات','اسم الدخول','اسم المستخدم','الاسم الظاهر','الدور','حالة الحساب','الصلاحيات','كلمة المرور','كلمة المرور (10 أحرف+)','عرض الهوية كاملة','تعديل بيانات الحساب','تخصيص الصلاحيات','إعادة تعيين كلمة المرور','كلمة مرور جديدة (اتركها فارغة للإبقاء عليها)'],
 attendance:['الحضور والانصراف','الوردية','الموظف','الحضور','الانصراف','الموقع / النقطة','اليوم','التأخير بالدقائق','الانصراف المبكر','الاعتماد','المطلوب','نقص الحضور المسجل'],
 daily_reports:['التقارير اليومية','اسم البند','التاريخ','مرفق التقرير اليومي','ملاحظات'],weekly_reports:['التقارير الأسبوعية','اسم البند','التاريخ','مرفق التقرير الأسبوعي','ملاحظات'],monthly_reports:['التقارير الشهرية','اسم البند','التاريخ','مرفق التقرير الشهري','ملاحظات'],claims:['المستخلصات الشهرية','اسم البند','التاريخ','مرفق المستخلص الشهري','ملاحظات']
};
Object.assign(columnCatalog,{
 'users:اسم الدخول|الاسم الظاهر|الدور|حالة الحساب|الإجراءات':['اسم الدخول','الاسم الظاهر','الدور','حالة الحساب','الإجراءات'].map((label,i)=>({key:String(i),label})),
 'backup:الملف|الحجم|':['الملف','الحجم','الإجراءات'].map((label,i)=>({key:String(i),label})),
 'registers:اسم البند|التاريخ|مرفق التقرير الأسبوعي|ملاحظات|الإجراءات':['اسم البند','التاريخ','مرفق التقرير الأسبوعي','ملاحظات','الإجراءات'].map((label,i)=>({key:String(i),label}))
});
function settingTableSection(key){
  const prefix=key.split(':')[0];
  if(prefix!=='registers')return prefix;
  return key.includes('الأسبوعي')?'weekly_reports':key.includes('الشهري')?'monthly_reports':'daily_reports';
}
function settingSectionList(groups){
  return [...new Set([...SETTINGS_SECTION_ORDER,...Object.keys(groups)])].filter(k=>groups[k]?.length||groups[k]?.size);
}
function settingsLabels(){
  const groups={};const add=(section,label)=>{
    if(typeof label!=='string'||label.length>160||!/[\u0621-\u064a]/.test(label)||label.includes('\n'))return;
    (groups[section]??=new Set()).add(label);
  };
  const extract=(section,fn)=>{
    if(typeof fn!=='function')return;
    for(const m of fn.toString().matchAll(/'((?:\\.|[^'\\])*)'|"((?:\\.|[^"\\])*)"/g)){
      const value=(m[1]??m[2]).replace(/\\(['"\\])/g,'$1');
      if(!value.includes('\\'))add(section,value);
    }
  };
  for(const [section,labels] of Object.entries(SETTINGS_EXTRA_LABELS))for(const label of labels)add(section,label);
  for(const [section,label] of NAV)add(section==='registers'?'daily_reports':section,label);
  for(const [section,fn] of Object.entries(VIEWS))extract(section==='registers'?'daily_reports':section,fn);
  for(const section of ['vehicles','licenses','equipment']){extract(section,ITEM_FIELDS);extract(section,ITEM_ADD_FIELDS);}
  extract('employees',empDetail);extract('users',editUserAccount);extract('users',permissionModal);
  if(window.EwanPush)extract('notifications',window.EwanPush.card);
  for(const label of Object.values(L.roles))add('users',label);
  for(const [key,cols] of Object.entries(columnCatalog))for(const c of cols)add(settingTableSection(key),c.label);
  for(const w of Object.values(widgetCatalog))add(w.section||'dashboard',w.label);
  const used=new Set(Object.values(groups).flatMap(set=>[...set]));
  for(const label of [...LABEL_CATALOG,'هـ','م','سارية','منتهية'])if(!used.has(label))add('shared',label);
  return Object.fromEntries(Object.entries(groups).map(([k,set])=>[k,[...set].sort((a,b)=>a.localeCompare(b,'ar'))]));
}
function groupedLabelSettings(draft){
  const groups=settingsLabels(),section=el('select',{'aria-label':'قسم المسميات','data-settings-filter':true},el('option',{value:''},'كل الأقسام'),settingSectionList(groups).map(k=>el('option',{value:k},SETTINGS_SECTION_NAMES[k]||k))),search=el('input',{placeholder:'ابحث باسم الخانة أو بالمسمى المعدّل','aria-label':'بحث المسميات','data-settings-filter':true}),list=el('div',{});
  const draw=()=>{
    const query=search.value.trim();const blocks=[];
    for(const key of settingSectionList(groups)){
      if(section.value&&section.value!==key)continue;
      const labels=groups[key].filter(x=>!query||x.includes(query)||String(draft.labels[x]||'').includes(query));
      if(!labels.length)continue;
      const body=el('div',{},labels.map(label=>el('div',{class:'setting-row','data-label-key':label},el('span',{},label),el('input',{value:draft.labels[label]??label,'aria-label':label,oninput:e=>draft.labels[label]=e.target.value}))));
      blocks.push(el('details',{class:'card','data-label-section':key,open:!!section.value||!!query},el('summary',{},(SETTINGS_SECTION_NAMES[key]||key)+' ('+labels.length+')'),body));
    }
    list.replaceChildren(...(blocks.length?blocks:[el('p',{class:'muted'},'لا توجد مسميات مطابقة للبحث.')]));
  };
  section.onchange=draw;search.oninput=draw;draw();
  return el('div',{},el('p',{class:'note'},'اختر القسم أو افتح مجموعته. التعديل يخص الاسم الظاهر فقط. المسمى المشترك بين أقسام يتغير في كل مواضعه؛ لتعديل عنوان عمود في جدول بعينه استخدم «أعمدة الجداول». لا تُعرض قيم السجلات وأرقام الهويات كمسميات.'),el('div',{class:'row card'},el('label',{},'القسم',section),search),list);
}
function groupedColumnSettings(draft,checkbox){
  const grouped={};
  for(const [key,cols] of Object.entries(columnCatalog)){
    if((key.startsWith('vehicles:')&&!Object.hasOwn(tableCatalogLabels,key))||(key.startsWith('licenses:')&&key!=='licenses:main'))continue;
    (grouped[settingTableSection(key)]??=[]).push([key,cols]);
  }
  const section=el('select',{'aria-label':'قسم أعمدة الجداول','data-settings-filter':true},settingSectionList(grouped).map(k=>el('option',{value:k},SETTINGS_SECTION_NAMES[k]||k))),select=el('select',{'aria-label':'جدول القسم','data-settings-filter':true}),list=el('div',{});
  const draw=()=>{
    const key=select.value,cols=columnCatalog[key];if(!cols){list.replaceChildren(el('p',{},'لا توجد جداول لهذا القسم.'));return;}
    const cfg=draft.tables[key]=normalizedTableColumns(key,cols,draft.tables);
    list.replaceChildren(...cfg.map((c,i)=>el('div',{class:'setting-row','data-column-key':c.key},checkbox('إظهار',c.visible!==false,v=>c.visible=v),el('input',{value:c.label,'aria-label':'اسم العمود',oninput:e=>c.label=e.target.value}),el('button',{class:'btn sm',disabled:i===0,onclick:()=>{[cfg[i-1],cfg[i]]=[cfg[i],cfg[i-1]];draw();}},'أعلى'),el('button',{class:'btn sm',disabled:i===cfg.length-1,onclick:()=>{[cfg[i+1],cfg[i]]=[cfg[i],cfg[i+1]];draw();}},'أسفل'))));
  };
  const choose=()=>{
    select.replaceChildren(...(grouped[section.value]||[]).map(([key,cols])=>el('option',{value:key},tableCatalogLabels[key]||cols.slice(0,3).map(c=>c.label).join(' / '))));draw();
  };
  section.onchange=choose;select.onchange=draw;choose();
  return el('div',{class:'card'},el('p',{class:'muted'},'اختر القسم أولًا، ثم الجدول المطلوب. تظهر هنا أعمدة هذا الجدول فقط.'),el('div',{class:'row'},el('label',{},'القسم',section),el('label',{},'الجدول',select)),list);
}

VIEWS.settings=async()=>{
  const r=await api('GET','/api/settings/appearance');let draft=structuredClone(r.appearance);const original=structuredClone(appearance);draft.colors.navy ||= '#062947';
  registerTableCatalog(r.table_catalog);loadIndicatorCatalog((await api('GET','/api/section-cards')).sections);settingsDirty=false;let pendingUploads=0,savingSettings=false;
  const tabBox=el('div',{}),buttons=el('div',{class:'tabs settings-tabs'}),status=el('p',{class:'muted'},'التعديلات في هذه الصفحة لا تُحفظ إلا عند الضغط على حفظ.');
  const title=field({k:'title',label:'اسم البرنامج'},draft.title);title.querySelector('input').oninput=e=>draft.title=e.target.value;
  function numeric(label,value,min,max,cb){const i=el('input',{type:'number',value,min,max});i.oninput=()=>cb(Number(i.value));return el('div',{},el('label',{},label),i);}
  function checkbox(label,value,cb){return el('label',{class:'inline-check'},el('input',{type:'checkbox',checked:value,onchange:e=>cb(e.target.checked)}),label);}
  function imageControl(k,label,water=false){
    const value=water?draft.watermark.src:draft.logos[k],img=el('img',{class:'logo-preview',src:value||null,hidden:!value,alt:label});
    const upload=el('input',{type:'file',accept:'image/png,image/jpeg,image/webp',onchange:guarded(async e=>{if(!e.target.files[0])return;pendingUploads++;try{const f=new FormData();f.append('file',e.target.files[0]);const x=await api('POST','/api/settings/logo',undefined,f);if(water)draft.watermark.src=x.url;else draft.logos[k]=x.url;img.src=x.url;img.hidden=false;toast('تم رفع الصورة؛ اضغط حفظ لتطبيقها');}finally{pendingUploads--;}})});
    return el('div',{class:'card settings-image-card'},el('h3',{},label),img,upload,
      checkbox('إظهار الشعار/العلامة',water?draft.watermark.visible:draft.logo_visible[k],v=>{if(water)draft.watermark.visible=v;else draft.logo_visible[k]=v;}),
      numeric('الحجم بالبكسل',water?draft.watermark.size:draft.sizes[k],water?100:30,water?1200:300,v=>{if(water)draft.watermark.size=v;else draft.sizes[k]=v;}),
      water&&numeric('درجة الظهور % (0 شفاف تمامًا)',draft.watermark.opacity,0,30,v=>draft.watermark.opacity=v));
  }
  const pages={
    'المؤشرات والتواريخ':()=>metricSettings(draft),
    'الاسم والشعارات':()=>el('div',{},title,el('div',{class:'grid settings-logo-grid'},[['login','شعار شاشة الدخول'],['sidebar','شعار القائمة'],['header','شعار أعلى الصفحة (الهيئة)'],['consultant','شعار الاستشاري']].map(([k,l])=>imageControl(k,l)),imageControl('watermark','العلامة المائية',true))),
    'بطاقات الأقسام':()=>sectionCardSettings(draft),
    'الألوان':()=>el('div',{class:'card kv'},Object.entries({bg:'الخلفية',card:'خلفية البطاقات',blue:'الأزرار والبطاقات الزرقاء',teal:'مطابق / ساري',orange:'غير مطابق / منتهي',amber:'التنبيهات',gray:'غير مسجل',navy:'الشريط الجانبي والعناوين'}).map(([k,t])=>el('div',{},el('label',{},t),el('input',{type:'color',value:draft.colors[k],oninput:e=>draft.colors[k]=e.target.value})))),
    'المسميات':()=>groupedLabelSettings(draft),
    'أعمدة الجداول':()=>groupedColumnSettings(draft,checkbox)
  };
  function show(name){tabBox.replaceChildren(pages[name]());buttons.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.textContent===name));}
  for(const name of Object.keys(pages))buttons.append(el('button',{class:'btn',onclick:()=>show(name)},name));show('الاسم والشعارات');
  const preview=el('div',{class:'appearance-preview',hidden:true});
  async function saveSettings(){
    if(savingSettings)return;
    if(pendingUploads)throw new Error('انتظر اكتمال رفع الشعار قبل حفظ الإعدادات');
    savingSettings=true;const button=page.querySelector('.sticky-settings .primary');if(button)button.disabled=true;
    try{const x=await api('PUT','/api/settings/appearance',draft);appearance=x.appearance;draft=structuredClone(x.appearance);settingsDirty=false;applyAppearance();toast('تم حفظ إعدادات البرنامج');renderShell();}finally{savingSettings=false;if(button)button.disabled=false;}
  }
  settingsSaveHook=saveSettings;
  const page=el('div',{'data-settings-page':true},el('h2',{},'إعدادات البرنامج'),status,buttons,tabBox,
    el('div',{class:'row card sticky-settings'},el('button',{class:'btn primary',onclick:guarded(async()=>{await saveSettings();})},'حفظ الإعدادات'),
      el('button',{class:'btn',onclick:()=>{preview.hidden=false;preview.replaceChildren(el('h3',{},draft.title),el('p',{},'معاينة الألوان والشعارات قبل الحفظ'),el('div',{class:'row'},Object.values(draft.logos).filter(Boolean).map(src=>el('img',{src,alt:'معاينة شعار',style:'height:70px;max-width:120px;object-fit:contain'}))),el('button',{class:'btn',style:'background:'+draft.colors.blue+';color:'+textColor(draft.colors.blue)},'زر نموذجي'),el('div',{style:'padding:1rem;background:'+draft.colors.teal+';color:'+textColor(draft.colors.teal)},'بطاقة مؤشر — 44'));preview.style.background=draft.colors.bg;}},'معاينة'),
      el('span',{},'')),preview);
  const markDirty=(e)=>{if(e?.target?.closest('[data-settings-filter]'))return;settingsDirty=true;status.textContent='توجد تعديلات غير محفوظة — اضغط حفظ الإعدادات.';status.className='note';};page.addEventListener('input',markDirty,true);page.addEventListener('change',markDirty,true);
  page.addEventListener('click',e=>{if(e.target.closest('.setting-row button')||/إضافة بطاقة|إضافة مؤشر|حذف تخصيص/.test(e.target.textContent||''))markDirty();});
  page.insertBefore(page.querySelector('.sticky-settings'),buttons);
  return page;
};

