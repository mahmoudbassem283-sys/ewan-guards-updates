"""Silent Windows worker and fixed notification activation entry point."""
import argparse
import time
import webbrowser
from pathlib import Path
from urllib.parse import urlsplit
from app import default_data_dir
from app.desktop_notifications import ensure_server, server_port, supported, worker, read_json

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--data-dir', default=default_data_dir())
    p.add_argument('--worker', action='store_true')
    p.add_argument('--open', action='store_true')
    a = p.parse_args()
    if supported():
        if a.open:
            url=read_json(Path(a.data_dir)/'sharing.json').get('url','')
            try:
                u=urlsplit(url)
                valid=u.scheme=='https' and u.hostname and u.hostname.endswith('.shares.zrok.io') and not u.username and not u.password and u.port in (None,443) and u.path in ('','/') and not u.query and not u.fragment
            except (ValueError,TypeError):valid=False
            if not valid:
                ensure_server(a.data_dir)
                time.sleep(1.5)
            base=url.rstrip('/') if valid else f'http://127.0.0.1:{server_port(a.data_dir)}'
            webbrowser.open(base+'/#/notifications')
        elif a.worker:
            worker(a.data_dir)
