"""Single Windows-compatible production server behind a local HTTPS tunnel.

Never binds a LAN/public address. Uses the SAME data directory and port as run.py.
No tunnelling, account creation or data import occurs on module import.
"""
import argparse
import os
from pathlib import Path
import sqlite3
import threading
from urllib.parse import urlsplit


def public_url(value):
    import re
    u=urlsplit(value.strip())
    if (u.scheme!='https' or not u.hostname or u.username or u.password or u.port
            or u.path not in ('','/') or u.query or u.fragment
            or not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?',u.hostname)
            or '.' not in u.hostname or u.hostname in ('localhost','127.0.0.1')
            or all(c.isdigit() or c=='.' for c in u.hostname)):
        raise ValueError('Use the HTTPS public URL shown by the sharing service, without a path.')
    return 'https://'+u.hostname


def require_database(data):
    path=Path(data).resolve()/'guards.sqlite'
    if not path.is_file():
        raise ValueError('Existing database not found. Run the installed program locally first; no new database was created.')
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as conn:
        if conn.execute('PRAGMA quick_check').fetchone()[0]!='ok':
            raise ValueError('Database check failed. Restore a verified backup before sharing.')
        if not conn.execute("SELECT 1 FROM users WHERE role='owner' AND active=1 LIMIT 1").fetchone():
            raise ValueError('An existing active owner account is required. Complete local setup first.')
    return path.parent


def create_shared_app(data,url):
    from flask import g,jsonify,request
    from app import create_app
    folder=require_database(data);url=public_url(url)
    app=create_app(str(folder))
    app.config['UPDATER_ROOT']=str(Path(__file__).resolve().parent)
    app.config.update(SESSION_COOKIE_SECURE=True,SHARING_URL=url,
        TRUSTED_HOSTS=['localhost','127.0.0.1',urlsplit(url).hostname])

    @app.before_request
    def no_remote_setup():
        if request.path=='/api/setup':
            return jsonify(error='الإعداد الأول متاح من التشغيل المحلي فقط'),403

    @app.after_request
    def shared_headers(response):
        response.headers['X-Ewan-Server']='shared'
        if request.path=='/api/status' and response.is_json and g.user:
            body=response.get_json();body['sharing']={'enabled':True,'url':url,'refresh_seconds':10}
            response.set_data(app.json.dumps(body))
        return response
    return app


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data-dir',required=True);ap.add_argument('--url',required=True)
    ap.add_argument('--port',type=int,required=True)
    a=ap.parse_args()
    if not 1024<=a.port<=65535:raise ValueError('Invalid port')
    from waitress import serve
    from app.backup import create_backup
    from run import backup_loop
    app=create_shared_app(a.data_dir,a.url)
    create_backup(a.data_dir,tag='-before-sharing')
    threading.Thread(target=backup_loop,args=(a.data_dir,app.logger),daemon=True).start()
    # Headers sent by internet clients are not trusted for authentication / IP limits.
    # Only this loopback listener is forwarded by the tunnel. No router changes.
    serve(app,host='127.0.0.1',port=a.port,threads=12,ident='',
          clear_untrusted_proxy_headers=True,channel_timeout=120,connection_limit=64,
          max_request_header_size=16384,max_request_body_size=25*1024*1024)


if __name__=='__main__':
    import sys
    # A controller-created Windows process group receives targeted CTRL_BREAK.
    # The existing supervisor catches KeyboardInterrupt and closes its own child.
    import signal
    def stop_requested(signum,frame):raise KeyboardInterrupt
    if os.name=='nt':
        import ctypes
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.GetConsoleWindow.restype=ctypes.c_void_p
        kernel.AttachConsole.argtypes=[ctypes.c_uint32]
        if not kernel.GetConsoleWindow():kernel.AttachConsole(0xFFFFFFFF)
    if hasattr(signal,'SIGBREAK'):signal.signal(signal.SIGBREAK,stop_requested)
    if os.environ.get('EWAN_SUPERVISED_CHILD'):
        main()
    else:
        from runtime_supervisor import supervise
        raise SystemExit(supervise(__file__,sys.argv[1:]))
