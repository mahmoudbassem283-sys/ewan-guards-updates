"""Owner-run sharing setup/controller. Does not publish anything on import/install.

The third-party client is downloaded by the user from the official site. The
account token is passed only to its enable command; never saved/logged here.
"""
import argparse
from contextlib import contextmanager
import getpass
import json
import logging
import os
from pathlib import Path
import re
import secrets
import signal
import shutil
import socket
import subprocess
import sys
import time
import threading
from urllib.parse import urlsplit
import urllib.request
import webbrowser

ROOT=Path(__file__).resolve().parent
DOWNLOAD='https://netfoundry.io/docs/zrok/how-tos/install/windows/'
ACCOUNT='https://myzrok.io/'


def data_folder():
    from app import default_data_dir
    return Path(default_data_dir()).resolve()


def config_path(data):return Path(data)/'sharing.json'


def save_config(data,cfg):
    path=config_path(data);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.json.new')
    with temp.open('w',encoding='utf-8') as f:json.dump(cfg,f,ensure_ascii=False,indent=2)
    os.replace(temp,path)


def validate_config(cfg):
    from share_server import public_url
    if cfg.get('provider')!='zrok2':raise ValueError('Run SETUP_SHARING.bat first.')
    name=cfg.get('name','')
    if not re.fullmatch('[a-z0-9]{4,32}',name):raise ValueError('Invalid reserved share name.')
    port=cfg.get('port')
    if type(port)!=int or not 1024<=port<=65535:raise ValueError('Invalid sharing port.')
    cfg['url']=public_url(cfg.get('url',''))
    hostname=urlsplit(cfg['url']).hostname
    if not hostname.startswith(name+'.') or not hostname.endswith('.zrok.io'):
        raise ValueError('The saved URL does not match the reserved zrok public name. Run SETUP_SHARING.bat.')
    exe=Path(cfg.get('client',''))
    if not exe.is_file():raise ValueError('zrok2 client was moved or removed. Run SETUP_SHARING.bat again.')
    cfg['client']=str(exe.resolve())
    return cfg


def read_config(data):
    if not config_path(data).is_file():raise ValueError('Run SETUP_SHARING.bat first.')
    return validate_config(json.loads(config_path(data).read_text(encoding='utf-8')))


class CommandUnavailable(ValueError):pass


def invoke(exe,args,timeout=90):
    # Always an argv list. Never pass the token through a shell or persist stdout.
    try:
        r=subprocess.run([str(exe),*args],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout)
    except subprocess.TimeoutExpired:
        raise CommandUnavailable('Sharing client did not respond. Check the client and internet connection; no account token is printed.') from None
    except OSError:
        raise ValueError('Cannot run the saved zrok client. Check its file, permissions and Windows architecture; no account token is printed.') from None
    if r.returncode:
        raise CommandUnavailable('Sharing service command failed ('+args[0]+'). Check the account, connection and service limits. No account token is printed.')
    return re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',r.stdout+r.stderr)


def ensure_v2(exe):
    version=invoke(exe,['version'],timeout=15)
    if not re.search(r'\bv2\.\d+',version):raise ValueError('This launcher requires zrok2 version 2.x. See the official download guide.')


def find_public_url(output,name):
    from share_server import public_url
    found=[]
    for token in re.findall(r'(?:https://)?'+re.escape(name)+r'\.[A-Za-z0-9.-]+',output):
        if not token.startswith('https://'):token='https://'+token
        if urlsplit(token).hostname.startswith(name+'.'):
            found.append(public_url(token))
    return next(iter(dict.fromkeys(found)),None)


def current_port(data):
    cfg=Path(data)/'config.json'
    v=json.loads(cfg.read_text(encoding='utf-8')) if cfg.is_file() else {}
    port=int(v.get('port',8765))
    if not 1024<=port<=65535:raise ValueError('Invalid local program port.')
    return port


def choose_client():
    local=ROOT/'sharing_tools'/'zrok2.exe'
    found=local if local.is_file() else shutil.which('zrok2')
    if found:return Path(found).resolve()
    print('حمّل zrok2 من الدليل الرسمي، ثم اختر zrok2.exe بعد فك الضغط. لا يلزم تثبيته على أجهزة المشاهدين.')
    webbrowser.open(DOWNLOAD)
    try:
        from tkinter import Tk,filedialog
        window=Tk();window.withdraw()
        value=filedialog.askopenfilename(title='اختر zrok2.exe',filetypes=[('zrok2','zrok2.exe'),('Executables','*.exe')]);window.destroy()
    except Exception:value=input('مسار ملف zrok2.exe بعد فك الضغط: ').strip().strip('"')
    if not value or not Path(value).is_file():raise ValueError('No sharing client selected. No changes were made.')
    return Path(value).resolve()


def setup(data):
    from share_server import require_database,public_url
    require_database(data)
    try:import waitress
    except ImportError:raise ValueError('Run INSTALL_SHARING_SUPPORT.bat first.')
    old=json.loads(config_path(data).read_text(encoding='utf-8')) if config_path(data).is_file() else {}
    exe=choose_client();ensure_v2(exe)
    try:status=invoke(exe,['status'])
    except ValueError:status=''
    enabled=bool(re.search(r'EnvZId[^\n]*<<SET>>',status))
    if not enabled:
        print('أنشئ حساب Free في myzrok.io، بدون بطاقة دفع. أدخل Account Token هنا فقط؛ لا ترسله في الشات.')
        webbrowser.open(ACCOUNT)
        token=getpass.getpass('Account Token (مخفي): ').strip()
        if not token or len(token)>1024 or any(c.isspace() for c in token):raise ValueError('Invalid account token.')
        try:invoke(exe,['enable',token])
        finally:token=None
    name=old.get('name') or 'ewan'+secrets.token_hex(6)
    if not re.fullmatch('[a-z0-9]{4,32}',name):raise ValueError('Invalid saved reserved name.')
    # Save the chosen public name before reserving, so an interrupted setup can
    # resume the same reservation rather than accumulate inaccessible names.
    draft={'provider':'zrok2','name':name,'port':current_port(data),'client':str(exe)}
    if old.get('url'):draft['url']=old['url']
    save_config(data,draft)
    names=invoke(exe,['list','names'])
    url=find_public_url(names,name)
    reserved=bool(re.search(r'\b'+re.escape(name)+r'\b',names))
    if not url and reserved and old.get('url'):url=public_url(old['url'])
    if not url and not reserved:
        invoke(exe,['create','name','-n','public',name])
        names=invoke(exe,['list','names']);url=find_public_url(names,name)
    if not url:
        print('افتح قائمة الأسماء في حساب الخدمة وانسخ رابط HTTPS للاسم '+name)
        url=public_url(input('رابط HTTPS المحجوز: ').strip())
    draft['url']=url;validate_config(draft);save_config(data,draft)
    (Path(data)/'SHARING_LINK.txt').write_text(url+'\n',encoding='utf-8')
    print('\nتم تجهيز الرابط: '+url)
    print('لم يبدأ النشر بعد. أغلق البرنامج والإشعارات ثم شغّل START_SHARING.bat.')
    print('الجميع، بما فيهم المالك، يستخدمون هذا الرابط أثناء المشاركة.')


@contextmanager
def exclusive(data):
    lock=Path(data)/'sharing.lock';lock.parent.mkdir(parents=True,exist_ok=True)
    f=lock.open('a+b');f.seek(0);f.write(b'0');f.flush();f.seek(0)
    try:
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except (OSError,BlockingIOError):raise ValueError('Sharing is already running on this device.')
        yield
    finally:f.close()


def port_busy(port):
    with socket.socket() as probe:
        probe.settimeout(.5)
        return probe.connect_ex(('127.0.0.1',port))==0


def is_shared_server(port):
    try:
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://127.0.0.1:'+str(port)+'/',timeout=2) as response:
            return response.headers.get('X-Ewan-Server')=='shared'
    except Exception:return False


def ensure_console():
    """pythonw startup needs a console for targeted CTRL_BREAK child cleanup."""
    if os.name!='nt':return
    import ctypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetConsoleWindow.restype=ctypes.c_void_p
    if not kernel.GetConsoleWindow():
        if not kernel.AllocConsole():raise ValueError('Cannot create sharing control console.')
        user=ctypes.WinDLL('user32',use_last_error=True)
        user.ShowWindow.argtypes=[ctypes.c_void_p,ctypes.c_int]
        user.ShowWindow(kernel.GetConsoleWindow(),0)


def child_flags():
    return {'creationflags':subprocess.CREATE_NEW_PROCESS_GROUP} if os.name=='nt' else {}


def terminate(child):
    if child and child.poll() is None:
        # Only children created by this controller, never arbitrary python processes.
        try:
            child.send_signal(signal.CTRL_BREAK_EVENT if os.name=='nt' else signal.SIGINT)
            child.wait(timeout=30)
            return
        except (OSError,subprocess.TimeoutExpired):pass
        if child.poll() is not None:return
        logging.warning('Graceful stop was unavailable or timed out; forcing only owned child tree PID %s',child.pid)
        if os.name=='nt':
            subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15)
        else:child.terminate()
        try:child.wait(timeout=8)
        except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)


def tunnel_args(cfg):
    return [cfg['client'],'share','public','http://127.0.0.1:'+str(cfg['port']),'-n','public:'+cfg['name'],'--headless','--force-local']


class ClientOutput:
    """Retain classifications only, never vendor output, request paths or tokens."""
    def __init__(self):
        self.busy=False;self.permanent=False;self.started=False;self.retry_after=0

    def accept(self,line):
        low=line.lower()
        if 'service is busy' in low or re.search(r'status\s+(?:429|503)\b',low):self.busy=True
        if 'retrying will not change the answer' in low or 'name ' in low and 'in use by share' in low:self.permanent=True
        if 'access your zrok share at' in low:self.started=True
        match=re.search(r'retry in (\d+) seconds?',low)
        if match:self.retry_after=max(self.retry_after,min(int(match[1]),86400))

    def drain(self,stream):
        try:
            # Bounded reads; do not persist raw output even on an exception.
            while True:
                row=stream.readline(4096)
                if not row:break
                self.accept(row)
        except (OSError,ValueError):pass
        finally:stream.close()


def retry_delay(attempt,output):
    if output.busy:return max(output.retry_after,min(1800,600*2**min(max(attempt-1,0),2)))
    return max(output.retry_after,min(300,30*2**min(max(attempt-1,0),4)))


def wait_stop(stop,seconds):
    deadline=time.monotonic()+seconds
    while not stop.exists() and time.monotonic()<deadline:
        time.sleep(min(.5,max(0,deadline-time.monotonic())))
    return stop.exists()


def report(data,phase,message,**extra):
    from update_engine import write_json
    write_json(Path(data)/'sharing_status.json',dict(phase=phase,message=message,updated=time.time(),**extra))
    print(message,flush=True)


def start(data,background=False):
    from share_server import require_database
    require_database(data);cfg=read_config(data)
    if current_port(data)!=cfg['port']:raise ValueError('The program port changed. Run SETUP_SHARING.bat to update the existing reservation.')
    stop=Path(data)/'sharing.stop'
    with exclusive(data):
        if port_busy(cfg['port']):
            raise ValueError('The local program is still running. Close it and desktop notifications, then retry. No process was killed.')
        stop.unlink(missing_ok=True)
        ensure_console()
        logfile=Path(data)/'sharing.log'
        logging.basicConfig(filename=str(logfile),level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s',force=True)
        server=None;tunnel=None;final_phase='stopped'
        try:
            attempt=0
            while not stop.exists():
                try:ensure_v2(cfg['client']);break
                except CommandUnavailable:
                    attempt+=1;delay=min(300,30*2**min(attempt-1,4))
                    report(data,'waiting_client','Sharing client check timed out/failed; waiting before retry.',next_retry=time.time()+delay)
                    if wait_stop(stop,delay):return
            if stop.exists():return
            env={**os.environ,'GUARDS_DATA_DIR':str(data),'PYTHONUNBUFFERED':'1'}
            with logfile.open('a',encoding='utf-8') as log:
                server=subprocess.Popen([sys.executable,str(ROOT/'share_server.py'),'--data-dir',str(data),'--url',cfg['url'],'--port',str(cfg['port'])],cwd=ROOT,env=env,stdout=log,stderr=log,**child_flags())
                deadline=time.monotonic()+45
                while not is_shared_server(cfg['port']):
                    if stop.exists():return
                    if server.poll() is not None or time.monotonic()>deadline:raise ValueError('Shared server could not start. Check sharing.log; no tunnel was opened.')
                    time.sleep(.3)
                print('Local server ready. Saved public link: '+cfg['url'],flush=True)
                print('Keep the host online. Stop with STOP_SHARING.bat; wait for cleanup before closing Windows.',flush=True)
                # No payloads / request traces from the vendor client are logged here.
                attempts=0;healthy_since=None;output=None;reader=None;announced=False
                while not stop.exists():
                    if server.poll() is not None:raise ValueError('Shared application stopped; the tunnel is being closed.')
                    if tunnel is None or tunnel.poll() is not None:
                        if tunnel is not None:
                            result=tunnel.returncode
                            if reader:reader.join(timeout=3)
                            if result==2 or output.permanent:
                                final_phase='blocked'
                                report(data,'blocked','zrok refused this connection. Automatic retries stopped. Check the saved name/account; no name was deleted.',exit_code=result)
                                return
                            attempts+=1;logging.warning('Sharing connection ended; retry attempt %s',attempts)
                            delay=retry_delay(attempts,output)
                            report(data,'rate_limited' if output.busy else 'retrying',
                                   'zrok is limiting requests; waiting before retry.' if output.busy else 'Sharing connection ended; waiting before retry.',
                                   next_retry=time.time()+delay,attempt=attempts,exit_code=result)
                            # No automatic deletion of a reserved name or existing share.
                            if wait_stop(stop,delay):break
                        if stop.exists():break
                        report(data,'connecting','Local server ready; connecting the public link. Public access is not yet verified.')
                        output=ClientOutput();announced=False
                        tunnel=subprocess.Popen(tunnel_args(cfg),cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                                text=True,encoding='utf-8',errors='replace',**child_flags())
                        reader=threading.Thread(target=output.drain,args=(tunnel.stdout,),daemon=True);reader.start()
                        healthy_since=time.monotonic()
                    elif output.started and not announced:
                        announced=True
                        report(data,'client_started','zrok reports the link started. Verify it from another device.')
                    elif healthy_since and time.monotonic()-healthy_since>120:
                        attempts=0
                    time.sleep(1)
        except KeyboardInterrupt:pass
        except Exception:
            final_phase='failed'
            report(data,'failed','Sharing stopped after a local error; check sharing.log. No account token is printed.')
            raise
        finally:
            report(data,'stopping','Stopping owned sharing processes; waiting for cleanup.')
            terminate(tunnel);terminate(server);stop.unlink(missing_ok=True)
            report(data,final_phase,'Sharing stopped; database and saved link retained.' if final_phase=='stopped' else
                   'Sharing needs attention; automatic retries stopped.' if final_phase=='blocked' else 'Sharing failed; inspect sharing.log.')
            logging.info('Sharing stopped. Source database retained.')
        print('Sharing stopped. Saved data and accounts retained.')


def autostart(data,remove=False):
    if os.name!='nt':raise ValueError('Automatic login startup is available on Windows only.')
    folder=Path(os.environ['APPDATA'])/'Microsoft/Windows/Start Menu/Programs/Startup'
    link=folder/'EwanGuardsSharing.lnk'
    if remove:
        link.unlink(missing_ok=True);print('تم إلغاء التشغيل التلقائي.');return
    read_config(data);folder.mkdir(parents=True,exist_ok=True)
    exe=Path(sys.executable).with_name('pythonw.exe')
    if not exe.is_file():raise ValueError('pythonw.exe is missing from the program environment.')
    def ps(value):return "'"+str(value).replace("'","''")+"'"
    import base64
    args='"'+str(ROOT/'sharing.py')+'" start --background --data-dir "'+str(data)+'"'
    script="$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut("+ps(link)+");$s.TargetPath="+ps(exe)+";$s.Arguments="+ps(args)+";$s.WorkingDirectory="+ps(ROOT)+";$s.WindowStyle=7;$s.Save()"
    encoded=base64.b64encode(script.encode('utf-16le')).decode('ascii')
    subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded],check=True)
    print('تم تفعيل التشغيل بعد تسجيل الدخول إلى Windows. الجهاز يحتاج إنترنت وعدم الدخول في السكون.')


def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    p=argparse.ArgumentParser();p.add_argument('action',choices=['setup','start','stop','check','open','autostart','no-autostart']);p.add_argument('--background',action='store_true');p.add_argument('--data-dir');a=p.parse_args()
    data=Path(a.data_dir).resolve() if a.data_dir else data_folder()
    if a.background:
        # pythonw has no console; do not open browser or prompt in background mode.
        data.mkdir(parents=True,exist_ok=True)
        sys.stdout=open(data/'sharing-launch.log','a',encoding='utf-8');sys.stderr=sys.stdout
    if a.action=='setup':setup(data)
    elif a.action=='start':start(data,a.background)
    elif a.action=='stop':
        data.mkdir(parents=True,exist_ok=True);(data/'sharing.stop').touch();print('تم طلب إيقاف المشاركة. انتظر عدة ثوانٍ قبل تشغيل النسخة المحلية.')
    elif a.action=='open':webbrowser.open(read_config(data)['url'])
    elif a.action in ('autostart','no-autostart'):autostart(data,a.action=='no-autostart')
    else:
        from share_server import require_database
        require_database(data);cfg=read_config(data);ensure_v2(cfg['client'])
        from update_engine import read_json
        print('Saved public link: '+cfg['url'])
        print('Local shared server: '+('RUNNING' if is_shared_server(cfg['port']) else 'NOT RUNNING'))
        state=read_json(data/'sharing_status.json')
        print('Last sharing state: '+state.get('phase','unknown')+' - '+state.get('message','No runtime status yet.'))
        if state.get('next_retry'):print('Next retry: '+time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(state['next_retry'])))
        print('External availability must be verified from another device. Last state may be stale if Windows stopped abruptly.')


if __name__=='__main__':
    try:main()
    except Exception as exc:
        if sys.stderr:print('لم تكتمل الخطوة: '+str(exc),file=sys.stderr)
        sys.exit(1)
