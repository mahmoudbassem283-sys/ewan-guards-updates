'use strict';
// No page/API caches, credentials, record details, or endpoint secrets are stored.
self.addEventListener('push',event=>{
  let p={};try{p=event.data?.json()||{};}catch{}
  const body=typeof p.body==='string'?p.body.slice(0,650):'لديك تنبيهات. افتح البرنامج لعرض التفاصيل حسب صلاحياتك.';
  event.waitUntil(self.registration.showNotification('نظام إدارة عقد الحراسات الأمنية',{
    body,icon:'/static/img/ewan.png',badge:'/static/img/ewan.png',lang:'ar',dir:'rtl',
    tag:'ewan-alerts',data:{url:'/#/notifications'}
  }));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  event.waitUntil((async()=>{
    const url=new URL('/#/notifications',self.location.origin).href;
    const pages=await self.clients.matchAll({type:'window',includeUncontrolled:true});
    for(const page of pages){if(new URL(page.url).origin===self.location.origin){await page.navigate(url);await page.focus();return;}}
    await self.clients.openWindow(url);
  })());
});
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
