'use strict';
// Optional browser capability: one account opt-in per browser profile/device.
window.EwanPush=(()=>{
  const tokenKey='ewan_push_device',userKey='ewan_push_user';
  function device(){let v=localStorage.getItem(tokenKey);if(!/^[a-f0-9]{64}$/.test(v||'')){v=Array.from(crypto.getRandomValues(new Uint8Array(32)),n=>n.toString(16).padStart(2,'0')).join('');localStorage.setItem(tokenKey,v);}return v;}
  function supported(){return window.isSecureContext&&'serviceWorker'in navigator&&'PushManager'in window&&'Notification'in window;}
  const decode=s=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),c=>c.charCodeAt(0));
  async function registration(){return navigator.serviceWorker.register('/ewan-push-sw.js',{scope:'/'}).then(()=>navigator.serviceWorker.ready);}
  async function disable(){
    await api('DELETE','/api/push/device',{device:device()});
    if('serviceWorker'in navigator){const r=await navigator.serviceWorker.getRegistration('/');const s=await r?.pushManager.getSubscription();if(s)await s.unsubscribe();}
    localStorage.removeItem(userKey);
  }
  async function sync(){
    // Account changes must not leave the previous account's subscription active.
    try{
      const old=localStorage.getItem(userKey);
      if(old&&(!me||old!==String(me.id))){const r=await navigator.serviceWorker?.getRegistration('/');const sub=await r?.pushManager.getSubscription();if(sub)await sub.unsubscribe();localStorage.removeItem(userKey);}
    }catch{}
  }
  async function card(){
    const area=el('div',{class:'card noprint','data-webpush':true},el('h3',{},'إشعارات هذا الجهاز'),el('p',{},'تظهر بشعار إيوان واسم البرنامج، وتخص الأقسام المسموح لحسابك بمشاهدتها. الضغط على الإشعار يفتح التفاصيل.'));
    area.append(el('p',{class:'muted'},'تعمل بعد إغلاق الصفحة عبر خدمة إشعارات المتصفح. يجب أن يظل الجهاز الأساسي مشغّلًا ومتصلًا بالإنترنت. إيقاف المتصفح بالقوة أو تعطيل عمله في الخلفية قد يؤخر الإشعارات. على آيفون: أضف البرنامج للشاشة الرئيسية وافتحه من الأيقونة على iOS 16.4 أو أحدث.'));
    if(!supported()){area.append(el('p',{class:'note'},'الإشعارات غير متاحة في هذا المتصفح حاليًا. افتح رابط HTTPS في Chrome أو Edge أو Firefox؛ وعلى آيفون افتح نسخة الشاشة الرئيسية.'));return area;}
    const r=await navigator.serviceWorker.getRegistration('/'),s=await r?.pushManager.getSubscription();
    const enabled=!!s&&Notification.permission==='granted'&&localStorage.getItem(userKey)===String(me.id);
    area.append(el('p',{},enabled?'الإشعارات مفعّلة لهذا الحساب على هذا الجهاز.':Notification.permission==='denied'?'إذن الإشعارات محظور؛ اسمح به من إعدادات الموقع في المتصفح، ثم أعد المحاولة.':'الإشعارات غير مفعّلة على هذا الجهاز.'));
    const buttons=el('div',{class:'row'});
    if(enabled){
      buttons.append(el('button',{class:'btn',onclick:guarded(async()=>{await api('POST','/api/push/test',{device:device()});toast('قَبِلت خدمة الإشعارات الاختبار؛ تأكد من ظهوره على هذا الجهاز.');})},'اختبار الإشعار'),
        el('button',{class:'btn',onclick:guarded(async()=>{await disable();toast('تم إيقاف إشعارات هذا الجهاز');await reload();})},'إيقاف إشعارات هذا الجهاز'));
    }else buttons.append(el('button',{class:'btn primary',disabled:Notification.permission==='denied',onclick:guarded(async()=>{
      // Prompt is directly inside the explicit user click, including Safari/iOS.
      const permission=await Notification.requestPermission();
      if(permission!=='granted')throw new Error('لم يُمنح إذن الإشعارات لهذا الموقع.');
      const cfg=await api('GET','/api/push/config');const reg=await registration();
      let sub=await reg.pushManager.getSubscription();
      if(sub){await sub.unsubscribe();sub=null;}
      sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:decode(cfg.public_key)});
      try{await api('POST','/api/push/device',{device:device(),subscription:sub.toJSON()});}
      catch(error){await sub.unsubscribe();throw error;}
      localStorage.setItem(userKey,String(me.id));toast('تم تفعيل إشعارات هذا الجهاز؛ اضغط اختبار الإشعار للتأكد من وصولها.');await reload();
    })},'تفعيل إشعارات هذا الجهاز'));
    area.append(buttons);return area;
  }
  return{card,disable,sync,deviceId:()=>{try{return localStorage.getItem(tokenKey)||'';}catch{return '';}}};
})();
VIEWS.notifications=async()=>{
  const r=await api('GET','/api/push/alerts');
  const labels={expired:'منتهية',today:'تنتهي اليوم',soon:'تنتهي قريبًا',incomplete:'غير مكتمل',nonconforming:'غير مطابق',attendance:'الحضور والانصراف'};
  const wrap=el('div',{},el('h2',{},'تنبيهات حسابك'),await window.EwanPush.card());
  wrap.append(el('div',{class:'card'},el('h3',{},'تفاصيل التنبيهات ('+r.total+')'),el('p',{class:'muted'},'تعرض هذه القائمة الأقسام المسموح لك بمشاهدتها وفق الصلاحيات الحالية.'),r.rows.length?table([{h:'السجل',f:x=>x.name},{h:'التنبيه',f:x=>x.title},{h:'الحالة',f:x=>labels[x.status]||x.status},{h:'التاريخ',f:x=>x.date||'—'}],r.rows):el('p',{},'لا توجد تنبيهات حالية في الأقسام المسموح لك بمشاهدتها.')));
  return wrap;
};
// The first boot can finish before this optional script loads on fast devices.
if(typeof me!=='undefined')window.EwanPush.sync();
