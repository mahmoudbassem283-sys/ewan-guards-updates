'use strict';
/* Presentation only: existing field names, table identities and permission matrix stay intact. */
async function recordPhotoMap(kind,section){
  const r=await api('GET','/api/record-photos?'+qs({owner_type:kind,section}));
  return new Map(r.rows.map(x=>[x.owner_id,x.url]));
}
let recordPrintBusy=false;
async function printRecordPhotos(section,pages){
  if(!can(section,'print'))throw new Error('لا تملك صلاحية الطباعة لهذا القسم.');
  if(recordPrintBusy)throw new Error('توجد عملية طباعة قيد التجهيز.');
  if(!pages.length)throw new Error('لا توجد صور محفوظة للطباعة.');
  for(const page of pages){const u=new URL(page.url,location.href);if(u.origin!==location.origin||!/^\/api\/(record-photos\/|vehicle-monthly\/records\/)/.test(u.pathname))throw new Error('رابط الصورة غير صالح.');}
  recordPrintBusy=true;
  const area=el('div',{class:'record-print-area','aria-hidden':'true'},pages.map(page=>el('section',{class:'record-print-page'},el('h2',{},page.title||'صورة السجل'),page.subtitle&&el('p',{},page.subtitle),el('img',{src:page.url,alt:page.title||'صورة السجل'}))));
  let fallback;
  const cleanup=()=>{clearTimeout(fallback);window.removeEventListener('afterprint',cleanup);area.remove();document.body.classList.remove('printing-record-photos');recordPrintBusy=false;};
  document.body.append(area);
  try{
    toast('جارٍ تجهيز الصور للطباعة…');
    await Promise.all([...area.querySelectorAll('img')].map(image=>new Promise((resolve,reject)=>{
      let timer;const done=ok=>{clearTimeout(timer);image.onload=image.onerror=null;ok?resolve():reject(new Error('تعذر تحميل إحدى الصور. أعد المحاولة؛ لم تتم طباعة صور ناقصة.'));};
      image.onload=()=>done(image.naturalWidth>0);image.onerror=()=>done(false);timer=setTimeout(()=>done(false),30000);
      if(image.complete)done(image.naturalWidth>0);
    })));
    if(!can(section,'print'))throw new Error('لم تعد صلاحية الطباعة متاحة لهذا القسم.');
    document.body.classList.add('printing-record-photos');
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    window.addEventListener('afterprint',cleanup);
    fallback=setTimeout(cleanup,10*60*1000);
    window.print();
  }catch(e){cleanup();throw e;}
}
function showRecordPhoto(url,title='صورة السجل',section=parseHash().path,subtitle){
  return modal(title,el('div',{},can(section,'print')&&el('button',{class:'btn noprint',type:'button',onclick:guarded(()=>printRecordPhotos(section,[{url,title,subtitle}]))},'طباعة الصورة فقط'),el('img',{class:'record-photo-large',src:url,alt:title})));
}
function recordLabel(label,url,options={}){
  return el('span',{class:'record-label'},url&&el('button',{type:'button',class:'record-thumb-button','aria-label':'تكبير صورة السجل',onclick:e=>{e.stopPropagation();showRecordPhoto(url,options.title||label||'صورة السجل',options.section||parseHash().path);}},el('img',{class:'record-thumb',src:url,alt:options.title||'صورة السجل',loading:'lazy'})),el('span',{},label));
}
function recordPhotoPanel(kind,id,initialUrl,name,section){
  const currentSection=['vehicle','driver'].includes(kind)?'vehicles':section||parseHash().path;
  const frame=el('div',{class:'record-photo-frame'}),status=el('p',{class:'muted record-photo-status','aria-live':'polite'});
  const box=el('section',{class:'record-photo-panel'},el('h3',{},kind==='driver'?'صورة الرخصة':'صورة السجل'),frame,status);
  let url=initialUrl,busy=false;
  const upload=el('input',{type:'file',accept:'image/png,image/jpeg,image/webp','aria-label':kind==='driver'?'اختيار صورة الرخصة':'اختيار صورة السجل'});
  const remove=el('button',{class:'btn sm danger',type:'button',onclick:()=>confirmBox('حذف صورة السجل فقط؟',async()=>{
    if(busy)return;busy=true;remove.disabled=true;
    try{await api('DELETE',`/api/record-photos/${kind}/${id}`);url=null;draw();toast('تم حذف الصورة');}finally{busy=false;remove.disabled=false;}
  })},'حذف الصورة');
  function draw(){
    frame.replaceChildren(url?el('button',{type:'button',class:'record-photo-zoom','aria-label':'تكبير صورة '+name,onclick:()=>showRecordPhoto(url,name,currentSection)},el('img',{src:url,alt:name})):
      el('div',{class:'record-photo-empty'},typeof exIcon==='function'?exIcon(kind==='vehicle'?'vehicles':kind==='driver'?'licenses':'equipment'):null,el('span',{},kind==='driver'?'يمكنك إضافة صورة رخصة السائق':'يمكنك إضافة صورة السجل')));
    remove.hidden=!url;
  }
  upload.addEventListener('change',guarded(async()=>{
    const f=upload.files[0];if(!f||busy)return;
    if(f.size>8*1024*1024){upload.value='';throw new Error('حجم الصورة لا يتجاوز 8 ميجابايت');}
    const form=new FormData();form.append('file',f);busy=true;upload.disabled=true;remove.disabled=true;status.textContent='جارٍ حفظ الصورة…';
    try{const r=await api('POST',`/api/record-photos/${kind}/${id}`,undefined,form);url=r.url;draw();status.textContent='تم حفظ الصورة';toast('تم حفظ الصورة');}
    catch(e){status.textContent='لم تُحفظ الصورة';throw e;}
    finally{busy=false;upload.disabled=false;remove.disabled=false;upload.value='';}
  }));
  if(can(currentSection,'edit'))box.append(el('label',{class:'record-photo-upload'},'اختيار / تغيير الصورة',upload),el('small',{class:'muted'},'PNG، JPEG، WebP — حتى 8 ميجابايت. تُحفظ الصورة مباشرة.'));
  if(can(currentSection,'delete'))box.append(remove);
  draw();return box;
}
function recordEditForm(kind,id,title,fields,values,onSave){
  const m=formModal(title,fields,values,onSave),form=m.el.querySelector('.record-fields');
  m.el.classList.add('record-editor');
  const summary=el('aside',{class:'record-summary'},el('h3',{},kind==='vehicle'?'ملخص السيارة':kind==='driver'?'بيانات السائق':'بيانات البند'));
  const layout=el('div',{class:'record-editor-layout'});form.before(layout);layout.append(form,summary);
  const content=el('div',{class:'record-summary-values'});summary.append(content);
  const update=()=>{
    const chosen=fields.filter(f=>kind==='vehicle'?['plate','model','year','driver_id'].includes(f.k):kind==='driver'?['name','license_no','phone'].includes(f.k):['name','required_qty','available_qty','op_status'].includes(f.k));
    content.replaceChildren(...chosen.map(f=>{const input=form.querySelector('[data-k="'+f.k+'"]');return el('div',{},el('span',{class:'muted'},f.label),el('b',{},f.type==='select'?input.selectedOptions[0]?.textContent||'—':input.value||'—'));}));
  };
  form.addEventListener('input',update);form.addEventListener('change',update);update();
  const host=el('div',{});summary.prepend(host);
  const sec=['vehicle','driver'].includes(kind)?undefined:values.section||parseHash().path;
  recordPhotoMap(kind,sec).then(photos=>{if(m.el.isConnected)host.replaceChildren(recordPhotoPanel(kind,id,photos.get(id),values.model||values.name||title,sec));}).catch(e=>{if(m.el.isConnected)host.replaceChildren(el('p',{class:'note'},e.message));});
  if(['vehicle','driver'].includes(kind))layout.append(recordDatesEditor(kind,id));
  return m;
}
