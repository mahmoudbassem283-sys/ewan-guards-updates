"""Live executive analytics. No source records or review results are rewritten."""
import copy,json,math,re
from flask import Blueprint,g,jsonify,request
from .customize import can,owner_section
from .dates import today_riyadh,status_for

bp=Blueprint('analytics',__name__,url_prefix='/api/analytics')
ORDER=['contract','employees','vehicles','equipment','licenses','attendance','registers','claims']
NAMES=dict(contract='العقد',employees='الكادر',vehicles='السيارات والاستمارات',equipment='الأجهزة والمعدات',licenses='السجلات والتراخيص',attendance='الحضور والانصراف',registers='التقارير اليومية والأسبوعية والشهرية',claims='المستخلصات الشهرية')
RULES=dict(nonconforming=100,expired=100,incomplete=50,soon=25,review=50)
REASONS=dict(nonconforming='غير مطابق',expired='وثيقة منتهية',incomplete='ملف أو بند غير مكتمل',soon='وثيقة تنتهي قريبًا',review='بند يحتاج مراجعة')
DEFAULT=dict(subtitle='بمجمع الدوائر الحكومية بمزدلفة',rules=RULES,high_from=60,medium_from=25,cards={},pages={},extra=[],global_order=['risk','alerts'],global_visible={'risk':True,'alerts':True},revision=0)

def layout():
    row=g.db.execute("SELECT value FROM settings WHERE key='executive41'").fetchone()
    if row:return json.loads(row[0])
    d=copy.deepcopy(DEFAULT)
    from .customize import appearance
    d['cards']=copy.deepcopy(appearance().get('section_cards',{}))
    for i,key in enumerate(ORDER):
        d['cards'].setdefault(key,{})['order']=i
    return d

def valid(b):
    if not isinstance(b,dict):raise ValueError('إعدادات غير صالحة')
    d=copy.deepcopy(DEFAULT)
    for k in ['subtitle']:
        v=b.get(k,d[k])
        if not isinstance(v,str) or len(v)>160:raise ValueError('مسمى طويل')
        d[k]=v
    r=b.get('rules',RULES)
    if not isinstance(r,dict) or set(r)!=set(RULES):raise ValueError('قواعد المخاطر غير صالحة')
    if any(type(v) not in (int,float) or not math.isfinite(v) or not 0<=v<=100 for v in r.values()):raise ValueError('الوزن من صفر إلى100')
    if not (r['nonconforming']>=r['incomplete']>=r['soon'] and r['expired']>=r['incomplete']):raise ValueError('حافظ على ترتيب الخطورة العالية ثم المتوسطة ثم التنبيه المبكر')
    d['rules']=r
    for k in ['high_from','medium_from']:
        v=b.get(k,d[k])
        if type(v) not in (int,float) or not math.isfinite(v):raise ValueError('حدود المخاطر غير صالحة')
        d[k]=v
    if not 0<d['medium_from']<d['high_from']<=100:raise ValueError('حدود المخاطر: صفر < متوسط < مرتفع ≤100')
    from .enhancements import section_layout
    d['cards']=section_layout(b.get('cards',{}))
    for field in ['pages']:
        value=b.get(field,{})
        if not isinstance(value,dict) or set(value)-set(ORDER+['main']):raise ValueError('لوحات غير صالحة')
        for key,cfg in value.items():
            if not isinstance(cfg,dict) or set(cfg)-{'order','hidden','labels'}:raise ValueError('تخصيص لوحة غير صالح')
            for a in ['order','hidden']:
                vals=cfg.get(a,[])
                if not isinstance(vals,list) or len(vals)>50 or any(not isinstance(x,str) or len(x)>80 for x in vals):raise ValueError('عناصر اللوحة غير صالحة')
            labels=cfg.get('labels',{})
            if not isinstance(labels,dict) or len(labels)>100 or any(not isinstance(x,str) or not isinstance(v,str) or len(v)>120 for x,v in labels.items()):raise ValueError('مسميات غير صالحة')
        d[field]=value
    extra=b.get('extra',[])
    if not isinstance(extra,list) or len(extra)>40:raise ValueError('عدد المؤشرات غير صالح')
    ids=set()
    from .enhancements import validate_card
    for x in extra:
        c=validate_card(x)
        if not c['id'] or c['id'] in ids:raise ValueError('معرف مؤشر مكرر')
        ids.add(c['id']);d['extra'].append(c)
    order=b.get('global_order',['risk','alerts'])
    if not isinstance(order,list) or sorted(order)!=['alerts','risk']:raise ValueError('ترتيب المؤشرات العامة غير صالح')
    d['global_order']=order
    vis=b.get('global_visible',{'risk':True,'alerts':True})
    if not isinstance(vis,dict) or set(vis)!={'risk','alerts'} or any(type(v)!=bool for v in vis.values()):raise ValueError('إظهار المؤشرات العامة غير صالح')
    d['global_visible']=vis
    return d

@bp.route('/layout',methods=['GET','PUT'])
def config():
    if not can('dashboard_design'):return jsonify(error='لا تملك صلاحية تخصيص اللوحات'),403
    if request.method=='GET':return jsonify(layout=layout())
    b=request.get_json(silent=True) or {}
    try:d=valid(b)
    except (ValueError,TypeError,AttributeError) as e:return jsonify(error=str(e)),400
    g.db.execute('BEGIN IMMEDIATE');old=layout()
    if type(b.get('revision'))!=int or b['revision']!=old['revision']:
        g.db.rollback();return jsonify(error='التصميم تغير في نافذة أخرى؛ أعد فتحه'),409
    # Every update requires edit; additional capabilities cover structural changes.
    if not can('dashboard_design','edit'):
        g.db.rollback();return jsonify(error='التعديل غير مصرح'),403
    before={x['id'] for x in old['extra']};after={x['id'] for x in d['extra']}
    hidden_before={s for s,c in old['cards'].items() if c.get('visible') is False}
    hidden_after={s for s,c in d['cards'].items() if c.get('visible') is False}
    hidden_before|={'global:'+k for k,v in old['global_visible'].items() if not v}
    hidden_after|={'global:'+k for k,v in d['global_visible'].items() if not v}
    for page,cfg in old['pages'].items():hidden_before|={page+':'+key for key in cfg.get('hidden',[])}
    for page,cfg in d['pages'].items():hidden_after|={page+':'+key for key in cfg.get('hidden',[])}
    removing=bool(before-after or hidden_after-hidden_before)
    adding=bool(after-before or hidden_before-hidden_after)
    if (adding and not can('dashboard_design','add')) or (removing and not can('dashboard_design','delete')):
        g.db.rollback();return jsonify(error='لا تملك صلاحية إضافة أو إخفاء البطاقات'),403
    if any(d[k]!=old[k] for k in ['rules','high_from','medium_from']) and not can('risk_settings','edit'):
        g.db.rollback();return jsonify(error='تعديل قواعد المخاطر غير مصرح'),403
    d['revision']=old['revision']+1
    g.db.execute("INSERT OR REPLACE INTO settings VALUES('executive41',?)",(json.dumps(d,ensure_ascii=False),));g.db.commit()
    from .api import audit
    audit('update','settings','executive41','تخصيص اللوحات وقواعد المخاطر',old,d)
    return jsonify(ok=True,layout=d)

def operational_attendance():
    # All three shifts now share the business date, including next-midnight third shift.
    from datetime import timedelta
    from .attendance import summary,matches_metric,ATT_METRICS,business_day
    from .dates import now_utc,RIYADH
    now=now_utc().astimezone(RIYADH);day=business_day()
    base=summary({'date':day.isoformat()})
    rows=base['rows'];coverage=base['coverage']
    totals={m:sum(matches_metric(r,m,now) for r in rows) for m in ATT_METRICS if m!='shortfall'}
    totals['shortfall']=sum(c['shortfall'] for c in coverage)
    base.update(rows=rows,coverage=coverage,totals=totals,business_date=day.isoformat())
    return base

def snapshot():
    from .enhancements import section_cards
    from .api import q,EMP_SQL
    from .reports import tracked_rows
    cfg=layout();cards=section_cards().get_json()['sections'];allowed={c['key'] for c in cards}
    units={};events=[];doc_seen=set()
    def unit(key,section,label,href,known=True):
        if key not in units:units[key]=dict(key=key,section=section,label=label,href=href,known=known,conditions=[])
        return units[key]
    def condition(u,kind,detail,href=None):
        if kind not in [x['kind'] for x in u['conditions']]:
            event=dict(kind=kind,reason=REASONS[kind],detail=detail,weight=cfg['rules'][kind],unit=u['key'],section=u['section'],label=u['label'],href=href or u['href'])
            u['conditions'].append(event);events.append(event)
    staff=q(EMP_SQL) if 'employees' in allowed else []
    for e in staff:
        u=unit('employee:'+str(e['id']),'employees',e['name'],'#/employees?id='+str(e['id']))
        state=e['consultant_result'] or 'unrecorded'
        if state in ('incomplete','nonconforming'):condition(u,state,REASONS[state])
        elif state=='unrecorded':condition(u,'incomplete','لم تسجل نتيجة المراجعة؛ يُعرض ضمن الملفات غير المكتملة في التحليل')
        st=status_for(e['id_expiry'])
        if st in ('expired','soon','today'):condition(u,'soon' if st=='today' else st,'صلاحية الهوية')
    for s in ('vehicles','equipment','licenses'):
        if s not in allowed:continue
        for x in q('SELECT * FROM items WHERE section=?',s):
            u=unit('item:'+str(x['id']),s,x['name'],'#/'+s+'?id='+str(x['id']))
            state=x['consultant_result'] or 'unrecorded'
            if state in ('incomplete','nonconforming'):condition(u,state,REASONS[state])
            elif state=='unrecorded':condition(u,'incomplete','لم تسجل نتيجة المراجعة')
        if s=='vehicles':
            for typ,tab,route in [('vehicle','vehicles','cars'),('driver','drivers','drivers')]:
                for x in q('SELECT * FROM '+tab):
                    unit(typ+':'+str(x['id']),s,x.get('plate') or x.get('name') or str(x['id']),'#/vehicles?tab='+route+'&id='+str(x['id']),False)
    for doc in tracked_rows(g.db):
        s=owner_section(doc['owner_type'],doc['owner_id'])
        if s not in allowed:continue
        key=doc['owner_type']+':'+str(doc['owner_id'])
        if key not in units:continue
        u=units[key]
        if doc['expiry_date']:u['known']=True
        st=doc['status']
        if st in ('expired','soon','today'):
            # Dates duplicated as employee identity and tracked document remain one condition per entity.
            condition(u,'soon' if st=='today' else st,doc.get('title') or doc.get('label') or 'صلاحية الوثيقة')
    if 'contract' in allowed:
        for x in q('SELECT * FROM contract_facts ORDER BY id'):
            u=unit('fact:'+str(x['id']),'contract',x['label'],'#/contract?id='+str(x['id']))
            if x['needs_review']:condition(u,'review','بند العقد موسوم بأنه يحتاج مراجعة')
    attendance=None
    if 'attendance' in allowed:
        attendance=operational_attendance()
        for r in attendance['rows']:
            if r['state'] not in ('duty','absent'):continue
            cov=next((c for c in attendance['coverage'] if c['shift_id']==r['shift_id']),None)
            known=bool(r['check_in']) or r['state']=='absent' or bool(cov and cov['started'])
            u=unit('attendance:'+str(r['id']),'attendance',r['name'],'#/attendance?id='+str(r['id'])+'&date='+r['work_date'],known)
            if r['state']=='absent':condition(u,'nonconforming','غياب مسجل')
            elif not r['check_in'] and cov and cov['started']:condition(u,'incomplete','حضور غير مسجل بعد بداية الوردية')
    for s in ('registers','claims'):
        if s not in allowed:continue
        kinds=['claims'] if s=='claims' else [x for x in ('daily_reports','weekly_reports','monthly_reports') if can(x)]
        for x in q('SELECT * FROM registers WHERE section IN ('+','.join('?' for _ in kinds)+')',*kinds):
            u=unit('register:'+str(x['id']),s,x['name'],'#/claims' if s=='claims' else '#/registers?kind='+x['section'])
            if not x['url']:condition(u,'incomplete','رابط المرفق غير مسجل')
    def risk(selected):
        known=[u for u in selected if u['known']];score=round(sum(max([c['weight'] for c in u['conditions']]+[0]) for u in known)/len(known),1) if known else None
        level='unassessed' if score is None else 'high' if score>=cfg['high_from'] else 'medium' if score>=cfg['medium_from'] else 'low'
        return dict(score=score,level=level,assessed=len(known),unknown=sum(not u['known'] for u in selected),affected=sum(bool(u['conditions']) for u in known),denominator=len(known),numerator=sum(max([c['weight'] for c in u['conditions']]+[0]) for u in known))
    sections=[]
    for c in cards:
        s=c['key'];selected=[u for u in units.values() if u['section']==s]
        # UI classification groups unrecorded with incomplete without changing database results.
        for group in c['groups']:
            if group['key']=='result':
                missing=next(x for x in group['segments'] if x['key']=='unrecorded')['value']
                for x in group['segments']:
                    if x['key']=='incomplete':x['value']+=missing;x['href']+('&' if '?' in x['href'] else '?')+'include_unrecorded=1'
                group['segments']=[x for x in group['segments'] if x['key']!='unrecorded']
        c.update(risk=risk(selected),alerts=[e for e in events if e['section']==s])
        if s=='contract':
            facts=q('SELECT * FROM contract_facts ORDER BY id');review=sum(bool(x['needs_review']) for x in facts)
            c.update(total=len(facts),facts=facts,summary={'conforming':len(facts)-review,'incomplete':review,'nonconforming':0})
        elif s in ('employees','vehicles','equipment','licenses'):
            group=next(g for g in c['groups'] if g['key']=='result');c['summary']={x['key']:x['value'] for x in group['segments']}
            c['metrics'].update(c['summary'])
            if s=='vehicles':c['fleet']={x['label']:x['count'] for x in c.get('details',[])}
            if s in ('equipment','vehicles'):
                quantities={str(x['id']):x['available_qty'] for x in q('SELECT id,available_qty FROM items WHERE section=?',s)}
                for x in c['breakdown']:
                    item_id=x['href'].split('id=')[-1]
                    x['count']=quantities.get(item_id)
            if s=='employees':
                rank={'director':0,'supervisor':1,'guard':2,'relief':3}
                c['breakdown'].sort(key=lambda x:next((v for k,v in rank.items() if 'role_type='+k in x['href']),99))
        if s=='attendance':
            cov=attendance['coverage'];c['date']=attendance['business_date'];c['coverage']=cov;c['totals']=attendance['totals'];c['required']=sum(x['required'] or 0 for x in cov)
            c['total']=attendance['totals']['total'];c['metrics'].update(attendance['totals'])
            c['attendance_rows']=[{k:r.get(k) for k in ('id','name','work_date','shift_name','state','check_in','check_out','late_minutes','status_label')} for r in attendance['rows']]
            c['completion']=[min(x['present']/(x['required'] or 1),1) if x['required'] is not None else None for x in cov]
        sections.append(c)
    return dict(sections=sections,alerts=events,risk=risk(list(units.values())),rules=cfg['rules'],layout=cfg,today=today_riyadh().isoformat(),formula='مجموع أعلى وزن لكل سجل ÷ عدد السجلات المقيّمة؛ السجل الواحد لا يُحسب مرتين')

@bp.get('/snapshot')
def data():
    if not can('dashboard'):return jsonify(error='غير مصرح'),403
    return jsonify(snapshot())
