from urllib.parse import urlencode
import io, json, math, os, re, secrets, sqlite3, subprocess, sys, threading
from pathlib import Path
from datetime import timedelta, date, datetime, timezone
from functools import wraps
from flask import Blueprint, current_app, g, jsonify, request, send_file, session
from werkzeug.utils import secure_filename
import openpyxl
from . import hash_pw, verify_pw, start_session, sha, MIN_PW, MAX_FAILS_USER, MAX_FAILS_IP, LOCK_WINDOW_MIN, _DUMMY
from . import importer, reports as R, backup as B
from .importer import ensure_checks
from .security import attachment_path,check_upload
from .dates import dual_calendar, STATUS_AR, now_utc, status_for, today_riyadh
from .customize import can, request_allowed, owner_section, valid_url
from .util import NORM_AR, RESULT_AR, SECTION_AR, can_full_id, can_reports, mask_for_audit, vdate

bp = Blueprint("api", __name__, url_prefix="/api")
ALLOWED_EXT = {"pdf", "png", "jpg", "jpeg", "docx", "xlsx"}
PDF_WORKER_LOCK=threading.BoundedSemaphore(1)


def err(msg, code=400):
    return jsonify(error=msg), code


def q(sql, *a):
    return [dict(r) for r in g.db.execute(sql, a).fetchall()]


def q1(sql, *a):
    r = g.db.execute(sql, a).fetchone()
    return dict(r) if r else None


def ex(sql, *a):
    c = g.db.execute(sql, a)
    g.db.commit()
    return c.lastrowid


def ts():
    return now_utc().isoformat()


def audit(action, entity, eid, summary, before=None, after=None):
    u = g.user or {}
    g.db.execute("INSERT INTO audit_log(ts,user_id,username,action,entity,entity_id,summary,before_json,after_json) VALUES(?,?,?,?,?,?,?,?,?)",
                 (ts(), u.get("id"), u.get("username"), action, entity, str(eid) if eid is not None else None, summary,
                  json.dumps(mask_for_audit(before), ensure_ascii=False, default=str) if before is not None else None,
                  json.dumps(mask_for_audit(after), ensure_ascii=False, default=str) if after is not None else None))
    g.db.commit()


def guard(owner=False, reports=False):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            if not g.user:
                return err("يلزم تسجيل الدخول", 401)
            if not request_allowed(owner=owner):
                return err("لا تملك صلاحية هذه العملية", 403)
            if reports and not can_reports(g.user):
                return err("لا تملك صلاحية التقارير", 403)
            # رابط اختياري عند الإنشاء، مع التحقق قبل حفظ السجل الرئيسي.
            b = body()
            initial = b.get('initial_url', '') if isinstance(b, dict) else ''
            try:
                initial = valid_url(initial)
            except ValueError as e:
                return err(str(e))
            out = f(*a, **k)
            if initial and request.method == 'POST':
                response = current_app.make_response(out)
                data = response.get_json(silent=True) or {}
                typ = {'employee_add':'employee','item_add':'item','fact_add':'contract_fact','add': {'vehicles':'vehicle','drivers':'driver','handovers':'handover'}.get(request.path.split('/')[-1])}.get(f.__name__)
                oid=data.get('id')
                if f.__name__=='tracked_add': typ,oid=b.get('owner_type'),b.get('owner_id')
                if response.status_code < 300 and oid and typ:
                    did = ex("INSERT INTO documents(owner_type,owner_id,role,label,kind,url,link_state,created_at) VALUES(?,?,'attachment',?,'drive',?,'saved',?)",
                             typ, oid, str(b.get('initial_label') or 'مرفق')[:200], initial, ts())
                    audit('create','documents',did,'إضافة رابط مع السجل الجديد')
            return out
        return w
    return deco


def body():
    return request.get_json(silent=True) or {}


def pick(b, fields, nullable=True):
    out = {}
    for k in fields:
        if k in b:
            v = b[k]
            if isinstance(v, str):
                v = v.strip()
            out[k] = None if (v == "" and nullable) else v
    return out


_NUM_RE = re.compile(r"^\s*\d+(\.\d+)?\s*$")


def num(v, hi=1e15):
    """رقم غير سالب ومحدود؛ يرفض النص غير الرقمي وnan وinf والقيم السالبة والمنطقية."""
    if v is None or (isinstance(v, str) and v.strip() == ""):
        return None
    bad = ValueError("قيمة رقمية غير صالحة")
    if isinstance(v, (bool, list, dict)):
        raise bad
    if isinstance(v, str) and not _NUM_RE.match(v):
        raise bad
    try:
        x = float(v)
    except (TypeError, ValueError, OverflowError):
        raise bad
    if not math.isfinite(x) or x < 0 or x > hi:
        raise ValueError("قيمة رقمية خارج النطاق المسموح (من 0 إلى 1e15)")
    return x


def purge_owner(owner_type, oid):
    """يحذف ما يتبع السجل: وثائق الانتهاء وسجل تجديدها والمستندات واقتراحات التواريخ والملفات المحلية."""
    # Record photos are independent of attachments/completeness and follow their record.
    photo = q1("SELECT stored_name FROM record_photos WHERE owner_type=? AND owner_id=?", owner_type, oid)
    if photo:
        g.db.execute("DELETE FROM record_photos WHERE owner_type=? AND owner_id=?", (owner_type, oid))
    tds = q("SELECT id FROM tracked_docs WHERE owner_type=? AND owner_id=?", owner_type, oid)
    docs = q("SELECT * FROM documents WHERE owner_type=? AND owner_id=?", owner_type, oid)
    for t in tds:
        g.db.execute("DELETE FROM expiry_history WHERE tracked_doc_id=?", (t["id"],))
    g.db.execute("DELETE FROM tracked_docs WHERE owner_type=? AND owner_id=?", (owner_type, oid))
    files = []
    if owner_type=='vehicle':
        from .vehicle_monthly import archive_files,file_path
        for name in archive_files(g.db,oid):
            try:files.append(file_path(name))
            except ValueError:pass
    for d in docs:
        g.db.execute("DELETE FROM date_suggestions WHERE document_id=?", (d["id"],))
        if d["kind"] == "local" and d["stored_name"]:
            try:files.append(attachment_path(current_app.config['DATA_DIR'],d['stored_name']))
            except ValueError:pass  # Never delete outside the attachment store.
    g.db.execute("DELETE FROM documents WHERE owner_type=? AND owner_id=?", (owner_type, oid))
    g.db.commit()
    if photo:
        from .record_photos import remove_file
        remove_file(photo["stored_name"])
    for f in files:
        try:
            os.remove(f)
        except OSError:
            pass
    return dict(tracked_docs=len(tds), documents=len(docs), local_files=len(files))


def update_row(table, rid, vals):
    if not vals:
        return
    sets = ",".join(f"{k}=?" for k in vals)
    g.db.execute(f"UPDATE {table} SET {sets}, updated_at=? WHERE id=?" if table != "handovers" else f"UPDATE {table} SET {sets} WHERE id=?",
                 (*vals.values(), ts(), rid) if table != "handovers" else (*vals.values(), rid))
    g.db.commit()


# ---------------- الحالة والدخول ----------------
@bp.get("/status")
def status():
    n = q1("SELECT count(*) c FROM users")["c"]
    u = g.user
    return jsonify(setup_needed=n == 0, csrf=session["csrf"],
                   user=None if not u else dict(id=u["id"], username=u["username"], display_name=u["display_name"], role=u["role"],
                                                can_see_full_id=can_full_id(u), can_use_reports=can_reports(u)),
                   today=today_riyadh().isoformat())


@bp.post("/setup")
def setup():
    if q1("SELECT count(*) c FROM users")["c"] > 0:
        return err("تم الإعداد الأول مسبقًا", 403)
    b = body()
    if not isinstance(b.get('username',''),str) or not isinstance(b.get('password',''),str):return err('بيانات الحساب غير صالحة')
    un, pw = (b.get("username") or "").strip(), b.get("password") or ""
    if not 3<=len(un)<=80 or not MIN_PW<=len(pw)<=1024:
        return err(f"اسم المستخدم 3 أحرف على الأقل وكلمة المرور {MIN_PW} على الأقل")
    uid = ex("INSERT INTO users(username,display_name,role,password_hash,can_see_full_id,can_use_reports,created_at) VALUES(?,?,'owner',?,1,1,?)",
             un, (b.get("display_name") or "المالك").strip(), hash_pw(pw), ts())
    g.user = q1("SELECT * FROM users WHERE id=?", uid)
    audit("create", "users", uid, "إنشاء حساب المالك عند الإعداد الأول")
    start_session(g.db, uid)
    return jsonify(ok=True, csrf=session["csrf"])


@bp.post("/login")
def login():
    b = body()
    if not isinstance(b.get('username',''),str) or not isinstance(b.get('password',''),str):return err('بيانات الحساب غير صالحة')
    un, pw = (b.get("username") or "").strip(), b.get("password") or ""
    if not isinstance(b.get('username',''),str) or not isinstance(b.get('password',''),str):return err('بيانات دخول غير صالحة')
    if not 1<=len(un)<=80 or len(pw)>1024:return err('اسم المستخدم أو كلمة المرور غير صحيحة',401)
    ip = request.remote_addr or ""
    since = (now_utc() - timedelta(minutes=LOCK_WINDOW_MIN)).isoformat()
    g.db.execute("BEGIN IMMEDIATE")
    fu = q1("SELECT count(*) c FROM login_attempts WHERE username=? AND success=0 AND ts>?", un, since)["c"]
    fi = q1("SELECT count(*) c FROM login_attempts WHERE ip=? AND success=0 AND ts>?", ip, since)["c"]
    if fu >= MAX_FAILS_USER or fi >= MAX_FAILS_IP:
        g.db.rollback()
        return err(f"محاولات كثيرة؛ حاول بعد {LOCK_WINDOW_MIN} دقيقة", 429)
    u = q1("SELECT * FROM users WHERE username=?", un)
    ok = verify_pw(u["password_hash"] if u else _DUMMY, pw) and bool(u) and bool(u["active"])
    ex("INSERT INTO login_attempts(username,ip,ts,success) VALUES(?,?,?,?)", un, ip, ts(), 1 if ok else 0)
    if not ok:
        return err("اسم المستخدم أو كلمة المرور غير صحيحة", 401)
    g.user = u
    start_session(g.db, u["id"])
    audit("login", "users", u["id"], "تسجيل دخول")
    return jsonify(ok=True, csrf=session["csrf"])


@bp.post("/logout")
def logout():
    token=(request.get_json(silent=True) or {}).get('push_device','')
    if g.user and isinstance(token,str) and re.fullmatch(r'[a-f0-9]{64}',token):
        ex('DELETE FROM push_devices WHERE device=? AND user_id=?',sha(token),g.user['id'])
    if session.get("sid"):
        ex("DELETE FROM sessions WHERE token_hash=?", sha(session["sid"]))
    session.clear()
    return jsonify(ok=True)


# ---------------- العقد ----------------
def doc_out(d):
    d = dict(d)
    d.pop("stored_name", None)
    if d["owner_type"] == "employee" and not can_full_id(g.user):
        d["url"], d["hidden"] = None, True
        d["local_name"] = None
    return d


@bp.get("/contract")
@guard()
def contract():
    c = q1("SELECT * FROM contract WHERE id=1")
    docs = [doc_out(d) for d in q("SELECT * FROM documents WHERE owner_type='contract' ORDER BY id")]
    return jsonify(contract=c, facts=q("SELECT * FROM contract_facts ORDER BY id"), documents=docs)


@bp.put("/contract")
@guard(owner=True)
def contract_put():
    b = body()
    try:
        vals = pick(b, ["project_name", "contract_no", "company", "notes"])
        for k in ("sign_date", "handover_date"):
            if k in b:
                vals[k] = vdate(b[k])
    except ValueError as e:
        return err(str(e))
    before = q1("SELECT * FROM contract WHERE id=1") or {}
    if not before:
        ex("INSERT INTO contract(id) VALUES(1)")
    sets = ",".join(f"{k}=?" for k in vals)
    if vals:
        ex(f"UPDATE contract SET {sets} WHERE id=1", *vals.values())
    audit("update", "contract", 1, "تعديل بيانات العقد", before, vals)
    return jsonify(ok=True)


def _fact_vals(b):
    v = pick(b, ["label", "value_text", "source", "note"])
    if "label" in v and not v["label"]:
        raise ValueError("اسم البند مطلوب")
    if "amount" in b:
        v["amount"] = num(b["amount"])
    if "page" in b:
        p = b["page"]
        if p in (None, ""):
            v["page"] = None
        else:
            if isinstance(p, bool) or not re.fullmatch(r"\d{1,4}", str(p)) or int(p) < 1:
                raise ValueError("رقم الصفحة غير صالح")
            v["page"] = int(p)
    if "needs_review" in b:
        v["needs_review"] = 1 if b["needs_review"] else 0
    return v


@bp.post("/contract_facts")
@guard(owner=True)
def fact_add():
    try:
        v = _fact_vals(body())
    except ValueError as e:
        return err(str(e))
    if not v.get("label"):
        return err("اسم البند مطلوب")
    fid = ex(f"INSERT INTO contract_facts({','.join(v)}) VALUES({','.join('?'*len(v))})", *v.values())
    audit("create", "contract_facts", fid, "إضافة بند للعقد: " + v["label"], None, v)
    return jsonify(id=fid)


@bp.put("/contract_facts/<int:fid>")
@guard(owner=True)
def fact_put(fid):
    before = q1("SELECT * FROM contract_facts WHERE id=?", fid)
    if not before:
        return err("غير موجود", 404)
    try:
        v = _fact_vals(body())
    except ValueError as e:
        return err(str(e))
    if v:
        ex(f"UPDATE contract_facts SET {','.join(k+'=?' for k in v)} WHERE id=?", *v.values(), fid)
    msg = "تعديل بند عقد: " + (before["label"] or "")
    if "amount" in v and v["amount"] != before["amount"]:
        f = lambda x: "غير مسجل" if x is None else f"{x:.2f}"
        msg += f" (المبلغ {f(before['amount'])} ← {f(v['amount'])})"
    audit("update", "contract_facts", fid, msg, before, v)
    return jsonify(ok=True)


# ---------------- الكادر ----------------
def emp_view(e):
    e = dict(e)
    if not can_full_id(g.user):
        e["national_id"], e["id_hidden"] = None, True
    e["days_left"] = ( date.fromisoformat(e["id_expiry"]) - today_riyadh()).days if e.get("id_expiry") else None
    e["id_status"] = status_for(e.get("id_expiry"))
    e["id_status_ar"] = STATUS_AR[e["id_status"]]
    return e


EMP_SQL = """SELECT e.*, (SELECT expiry_date FROM tracked_docs t WHERE t.owner_type='employee' AND t.owner_id=e.id AND t.doc_type='national_id' LIMIT 1) id_expiry,
 (SELECT count(*) FROM employee_checks c WHERE c.employee_id=e.id AND c.norm='nonconforming') nc,
 (SELECT count(*) FROM documents d WHERE d.owner_type='employee' AND d.owner_id=e.id AND d.role='attachment') doc_count,
 (SELECT url FROM documents d WHERE d.owner_type='employee' AND d.owner_id=e.id AND d.role='attachment' AND (url LIKE 'https://drive.google.com/%' OR url LIKE 'https://docs.google.com/%') ORDER BY CASE WHEN d.label LIKE '%ملف الموظف%' THEN 0 ELSE 1 END,d.id LIMIT 1) employee_file_url
 FROM employees e"""


@bp.get("/employees")
@guard()
def employees():
    a = request.args
    rows = q(EMP_SQL + " ORDER BY e.seq, e.id")
    out = []
    if a.get("id"):
        rows=[r for r in rows if str(r["id"])==a["id"]]
    if a.get('role_type'):
        from .enhancements import staff_category
        rows=[e for e in rows if staff_category(e)==a['role_type']]
    qq = (a.get("q") or "").strip()
    for e in rows:
        if qq and not (qq in (e["name"] or "") or (can_full_id(g.user) and qq in (e["national_id"] or ""))):
            continue
        if a.get("job_group") and e["job_group"] != a["job_group"]:
            continue
        if a.get("consultant") and (e["consultant_result"] or "unrecorded") not in (["incomplete","unrecorded"] if a["consultant"]=="incomplete" and a.get("include_unrecorded")=="1" else [a["consultant"]]):
            continue
        if a.get("authority") and (e["authority_status"] or "unrecorded") != a["authority"]:
            continue
        if a.get("has_nc") == "1" and not e["nc"]:
            continue
        if a.get("no_doc") == "1" and e["doc_count"]:
            continue
        ev = emp_view(e)
        if a.get("id_status") and ev["id_status"] not in a["id_status"].split(","):
            continue
        if a.get("fail") and not q1("SELECT 1 FROM employee_checks WHERE employee_id=? AND key=? AND norm='nonconforming'", e["id"], a["fail"]):
            continue
        out.append(ev)
    return jsonify(rows=out, total=len(out))


@bp.get("/employees/<int:eid>")
@guard()
def employee(eid):
    e = q1(EMP_SQL + " WHERE e.id=?", eid)
    if not e:
        return err("غير موجود", 404)
    checks = q("SELECT * FROM employee_checks WHERE employee_id=? ORDER BY id", eid)
    for c in checks:
        c["norm_ar"] = NORM_AR.get(c["norm"], c["norm"])
    tr = [r for r in R.tracked_rows(g.db) if r["owner_type"] == "employee" and r["owner_id"] == eid]
    return jsonify(employee=emp_view(e), checks=checks, tracked=tr,
                   documents=[doc_out(d) for d in q("SELECT * FROM documents WHERE owner_type='employee' AND owner_id=?", eid)])


EMP_FIELDS = ["name", "national_id", "job_title", "job_group", "phone", "site", "shift", "notes", "consultant_note", "authority_note"]


def _emp_vals(b):
    v = pick(b, EMP_FIELDS)
    if v.get("national_id") and not re.fullmatch(r"\d{6,15}", v["national_id"]):
        raise ValueError("رقم الهوية أرقام فقط")
    if v.get("job_group") not in (None, "core", "relief"):
        raise ValueError("فئة الوظيفة غير صالحة")
    for k, allowed in (("consultant_result", ("conforming", "nonconforming", "incomplete")), ("authority_status", ("approved", "rejected"))):
        if k in b:
            x = b[k] or None
            if x not in (None, *allowed):
                raise ValueError("قيمة غير صالحة: " + k)
            v[k] = x
    for k in ("start_date", "authority_date"):
        if k in b:
            v[k] = vdate(b[k])
    return v


@bp.post("/employees")
@guard(owner=True)
def employee_add():
    try:
        v = _emp_vals(body())
    except ValueError as e:
        return err(str(e))
    if not v.get("name"):
        return err("الاسم مطلوب")
    v.setdefault("job_group", "core")
    try:
        eid = ex(f"INSERT INTO employees({','.join(v)},created_at,updated_at) VALUES({','.join('?'*len(v))},?,?)", *v.values(), ts(), ts())
    except sqlite3.IntegrityError:
        return err("رقم الهوية مسجل مسبقًا", 409)
    ensure_checks(g.db, eid)
    audit("create", "employees", eid, "إضافة موظف: " + v["name"], None, v)
    return jsonify(id=eid)


@bp.put("/employees/<int:eid>")
@guard(owner=True)
def employee_put(eid):
    before = q1("SELECT * FROM employees WHERE id=?", eid)
    if not before:
        return err("غير موجود", 404)
    b = body()
    try:
        v = _emp_vals(b)
    except ValueError as e:
        return err(str(e))
    checks_in = b.get("checks") or []
    if not isinstance(checks_in, list):
        return err("صيغة الاشتراطات غير صالحة")
    planned = []
    for c in checks_in:
        key = c.get("key") if isinstance(c, dict) else None
        old = q1("SELECT * FROM employee_checks WHERE employee_id=? AND key=?", eid, key) if key else None
        if not old:
            return err("اشتراط غير موجود: " + str(key))
        if c.get("norm") not in ("conforming", "nonconforming", "incomplete", "placeholder", "empty"):
            return err(f"تفسير غير صالح للاشتراط «{old['label']}»")
        planned.append((old, c))
    try:
        update_row("employees", eid, v)
    except sqlite3.IntegrityError:
        return err("رقم الهوية مسجل مسبقًا", 409)
    for old, c in planned:
        ex("UPDATE employee_checks SET norm=?, reason=? WHERE id=?", c["norm"], (c.get("reason") or "").strip() or None, old["id"])
        audit("update", "employee_checks", old["id"], f"تعديل اشتراط «{old['label']}» للموظف {before['name']}", old, c)
    audit("update", "employees", eid, "تعديل موظف: " + before["name"], before, v)
    return jsonify(ok=True)


@bp.delete("/employees/<int:eid>")
@guard(owner=True)
def employee_del(eid):
    before = q1("SELECT * FROM employees WHERE id=?", eid)
    if not before:
        return err("غير موجود", 404)
    if q1("SELECT 1 FROM attendance_roster WHERE employee_id=? LIMIT 1",eid):
        return err("الموظف مرتبط بسجلات حضور؛ لا يمكن حذفه حفاظًا على السجل",409)
    removed = purge_owner("employee", eid)
    ex("DELETE FROM employees WHERE id=?", eid)
    audit("delete", "employees", eid, "حذف موظف: " + before["name"], dict(before, _removed=removed))
    return jsonify(ok=True)


# ---------------- البنود (سيارات/أجهزة/تراخيص) ----------------
def item_view(i):
    i = dict(i)
    i["section_ar"] = SECTION_AR[i["section"]]
    i["result_ar"] = RESULT_AR[i["consultant_result"]]
    rq, av = i["required_qty"], i["available_qty"]
    i["short"] = (rq - av) if (rq is not None and av is not None and av < rq) else 0
    i["qty_basis"] = None if rq is None else ("مؤكد" if i["required_qty_confirmed"] else "مقترح من نص المواصفات — يحتاج تأكيدًا")
    docs = R.item_docs(g.db, i)
    i["documents"] = [doc_out(d) for d in docs]
    i["has_attachment"] = any(d["role"] == "attachment" for d in docs)
    t = q1("SELECT * FROM tracked_docs WHERE owner_type='item' AND owner_id=?", i["id"])
    i["expiry_date"] = t["expiry_date"] if t else None
    i["expiry_raw"] = t["expiry_raw"] if t else None
    i["tracked_id"] = t["id"] if t else None
    i["expiry_status"] = status_for(i["expiry_date"]) if i["needs_expiry"] else None
    i["expiry_status_ar"] = STATUS_AR.get(i["expiry_status"])
    return i


@bp.get("/items")
@guard()
def items():
    sec = request.args.get("section")
    rows = [item_view(i) for i in q("SELECT * FROM items WHERE (?1 IS NULL OR section=?1) ORDER BY section, seq", sec)]
    f = request.args
    if f.get("id"):
        rows=[r for r in rows if str(r["id"])==f["id"]]
    if f.get("result"):
        rows = [r for r in rows if (r["consultant_result"] or "unrecorded") in (["incomplete","unrecorded"] if f["result"]=="incomplete" and f.get("include_unrecorded")=="1" else [f["result"]])]
    if f.get("short") == "1":
        rows = [r for r in rows if r["short"]]
    if f.get("no_doc") == "1":
        rows = [r for r in rows if not r["has_attachment"]]
    if f.get("expiry"):
        rows = [r for r in rows if r["expiry_status"] in f["expiry"].split(",")]
    return jsonify(rows=rows, total=len(rows))


ITEM_FIELDS = ["name", "spec", "unit", "op_status", "location", "responsible", "note"]


def _item_vals(b):
    v = pick(b, ITEM_FIELDS)
    if "name" in v and not v["name"]:
        raise ValueError("اسم البند مطلوب")
    if "available_qty" in b:
        v["available_qty"] = num(b["available_qty"])
    if "required_qty" in b:
        v["required_qty"] = num(b["required_qty"])
        v["required_qty_source"] = "entered" if v["required_qty"] is not None else None
        v["required_qty_confirmed"] = 1 if v["required_qty"] is not None else 0
    if "required_qty_confirmed" in b and "required_qty" not in b:
        v["required_qty_confirmed"] = 1 if b["required_qty_confirmed"] else 0
    if "consultant_result" in b:
        x = b["consultant_result"] or None
        if x not in (None, "conforming", "nonconforming", "incomplete"):
            raise ValueError("نتيجة غير صالحة")
        v["consultant_result"] = x
    if v.get("op_status") not in (None, "working", "faulty", "missing", "maintenance"):
        raise ValueError("حالة تشغيلية غير صالحة")
    return v


@bp.post("/items")
@guard(owner=True)
def item_add():
    b = body()
    sec = b.get("section")
    if sec not in SECTION_AR:
        return err("القسم غير صالح")
    try:
        v = _item_vals(b)
        if not v.get("name"):
            raise ValueError("اسم البند مطلوب")
        seq = b.get("seq")
        if seq in (None, ""):
            seq = q1("SELECT COALESCE(MAX(seq),0)+1 s FROM items WHERE section=?", sec)["s"]
        else:
            try:
                if isinstance(seq, bool):
                    raise ValueError
                sf = float(seq)
                if sf != int(sf) or not 1 <= sf <= 100000:
                    raise ValueError
            except (TypeError, ValueError, OverflowError):
                raise ValueError("رقم البند يجب أن يكون عددًا صحيحًا موجبًا")
            seq = int(sf)
        needs = 1 if b.get("needs_expiry", sec != "equipment") else 0
        exp = td_vals({k: b[k] for k in ("expiry_date", "calendar", "expiry_raw") if k in b}) if needs else {}
    except ValueError as e:
        return err(str(e))
    if q1("SELECT 1 FROM items WHERE section=? AND seq=?", sec, seq):
        return err("رقم البند مستخدم في هذا القسم", 409)
    t = ts()
    try:
        iid = ex("""INSERT INTO items(section,seq,name,spec,needs_expiry,required_qty,required_qty_source,required_qty_confirmed,available_qty,unit,
                    consultant_result,op_status,location,responsible,note,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                 sec, seq, v["name"], v.get("spec"), needs, v.get("required_qty"), v.get("required_qty_source"), v.get("required_qty_confirmed", 0),
                 v.get("available_qty"), v.get("unit"), v.get("consultant_result"), v.get("op_status"), v.get("location"), v.get("responsible"), v.get("note"), t, t)
    except sqlite3.IntegrityError:
        return err("رقم البند مستخدم في هذا القسم", 409)
    if needs:
        ex("""INSERT INTO tracked_docs(owner_type,owner_id,doc_type,title,expiry_date,expiry_raw,calendar,source,confirmed,created_at,updated_at)
              VALUES('item',?,?,?,?,?,?,'manual',1,?,?)""", iid, {"licenses": "license", "vehicles": "vehicle_followup"}.get(sec, "item_expiry"), v["name"],
           exp.get("expiry_date"), exp.get("expiry_raw"), exp.get("calendar"), t, t)
    audit("create", "items", iid, f"إضافة بند ({SECTION_AR[sec]}): {v['name']}", None, dict(v, section=sec, seq=seq, needs_expiry=needs, **exp))
    return jsonify(id=iid, seq=seq)


@bp.put("/items/<int:iid>")
@guard(owner=True)
def item_put(iid):
    before = q1("SELECT * FROM items WHERE id=?", iid)
    if not before:
        return err("غير موجود", 404)
    try:
        v = _item_vals(body())
        update_row("items", iid, v)
    except ValueError as e:
        return err(str(e))
    audit("update", "items", iid, "تعديل بند: " + before["name"], before, v)
    return jsonify(ok=True)


@bp.delete("/items/<int:iid>")
@guard(owner=True)
def item_del(iid):
    item = q1("SELECT * FROM items WHERE id=?", iid)
    if not item:
        return err("غير موجود", 404)
    seq, moved = str(item["seq"]), 0
    alive = {int(r["seq"]): r["id"] for r in q("SELECT id,seq FROM items WHERE section=? AND id!=?", item["section"], iid)}
    # مراجع تعاقدية/مستندات بخلايا مدمجة تشمل عدة بنود: لا تضيع من البنود المجاورة
    for d in q("""SELECT d.* FROM documents d JOIN items i ON i.id=d.owner_id WHERE d.owner_type='item' AND i.section=? AND d.span_seqs IS NOT NULL""", item["section"]):
        parts = [x for x in d["span_seqs"].split(",") if x]
        if seq not in parts:
            continue
        rest = [x for x in parts if x != seq and int(x) in alive]
        if d["owner_id"] == iid:
            if rest:
                g.db.execute("UPDATE documents SET owner_id=?, span_seqs=? WHERE id=?", (alive[min(int(x) for x in rest)], ",".join(rest), d["id"]))
                moved += 1
        else:
            g.db.execute("UPDATE documents SET span_seqs=? WHERE id=?", (",".join(rest) or None, d["id"]))
    g.db.commit()
    removed = purge_owner("item", iid)
    ex("DELETE FROM items WHERE id=?", iid)
    audit("delete", "items", iid, f"حذف بند ({SECTION_AR[item['section']]}): {item['name']}", dict(item, _removed=removed, _shared_documents_moved=moved))
    return jsonify(ok=True, removed=removed, shared_documents_moved=moved)


# ---------------- السيارات والسائقون والاستلام ----------------
SIMPLE = {"vehicles": ["plate", "model", "year", "driver_id", "notes"], "drivers": ["name", "license_no", "phone", "notes"],
          "handovers": ["vehicle_id", "kind", "event_date", "person", "odometer", "notes"]}
LABEL = {"vehicles": "سيارة", "drivers": "سائق", "handovers": "استلام/تسليم"}


def simple_vals(ent, b):
    v = pick(b, SIMPLE[ent])
    if "event_date" in v:
        v["event_date"] = vdate(v["event_date"])
    if "kind" in v and v["kind"] not in ("receive", "handover"):
        raise ValueError("نوع الحركة: استلام أو تسليم")
    for k in ("driver_id", "vehicle_id"):
        if v.get(k) is not None:
            v[k] = int(v[k])
    return v


def make_simple(ent):
    def lst():
        rows = q(f"SELECT * FROM {ent} ORDER BY id")
        for r in rows:
            if ent in ("vehicles", "drivers"):
                r["tracked"] = [t for t in R.tracked_rows(g.db) if t["owner_type"] == ent[:-1] and t["owner_id"] == r["id"]]
        return jsonify(rows=rows, total=len(rows))

    def add():
        try:
            v = simple_vals(ent, body())
        except (ValueError, TypeError) as e:
            return err(str(e))
        if ent == "drivers" and not v.get("name"):
            return err("اسم السائق مطلوب")
        if ent == "handovers" and not (v.get("vehicle_id") and v.get("kind")):
            return err("السيارة ونوع الحركة مطلوبان")
        cols = list(v) + (["created_at"])
        rid = ex(f"INSERT INTO {ent}({','.join(cols)}{',updated_at' if ent!='handovers' else ''}) VALUES({','.join('?'*(len(cols)+(1 if ent!='handovers' else 0)))})",
                 *v.values(), ts(), *([ts()] if ent != "handovers" else []))
        audit("create", ent, rid, f"إضافة {LABEL[ent]}", None, v)
        return jsonify(id=rid)

    def put(rid):
        before = q1(f"SELECT * FROM {ent} WHERE id=?", rid)
        if not before:
            return err("غير موجود", 404)
        try:
            v = simple_vals(ent, body())
        except (ValueError, TypeError) as e:
            return err(str(e))
        update_row(ent, rid, v)
        audit("update", ent, rid, f"تعديل {LABEL[ent]}", before, v)
        return jsonify(ok=True)

    def dele(rid):
        before = q1(f"SELECT * FROM {ent} WHERE id=?", rid)
        if not before:
            return err("غير موجود", 404)
        removed = purge_owner(ent[:-1], rid)
        ex(f"DELETE FROM {ent} WHERE id=?", rid)
        audit("delete", ent, rid, f"حذف {LABEL[ent]}", dict(before, _removed=removed))
        return jsonify(ok=True)

    bp.add_url_rule(f"/{ent}", f"{ent}_list", guard()(lst), methods=["GET"])
    bp.add_url_rule(f"/{ent}", f"{ent}_add", guard(owner=True)(add), methods=["POST"])
    bp.add_url_rule(f"/{ent}/<int:rid>", f"{ent}_put", guard(owner=True)(put), methods=["PUT"])
    bp.add_url_rule(f"/{ent}/<int:rid>", f"{ent}_del", guard(owner=True)(dele), methods=["DELETE"])


for _e in SIMPLE:
    make_simple(_e)


# ---------------- تواريخ الانتهاء ----------------
OWNER_TYPES = ("employee", "item", "vehicle", "driver")


def td_vals(b, partial=False):
    from .enhancements import normalize_date_body
    b = normalize_date_body(b)
    v = pick(b, ["title", "doc_type", "expiry_raw", "note"])
    if "expiry_date" in b:
        v["expiry_date"] = vdate(b["expiry_date"])
    cal = b.get("calendar") if "calendar" in b else None
    if "calendar" in b:
        if cal not in (None, "", "gregorian", "hijri"):
            raise ValueError("نوع التقويم: ميلادي أو هجري")
        v["calendar"] = cal or None
    if v.get("calendar") == "hijri" and v.get("expiry_date") and not v.get("expiry_raw"):
        raise ValueError("عند التاريخ الهجري يجب حفظ النص الأصلي (expiry_raw)")
    if v.get("expiry_date") and "calendar" in b and not v.get("calendar"):
        raise ValueError("حدّد نوع التقويم؛ لا يُخمَّن")
    return v


@bp.get("/tracked_docs")
@guard()
def tracked():
    rows = R.tracked_rows(g.db)
    a = request.args
    if a.get("id"):
        rows = [r for r in rows if str(r["id"]) == a["id"]]
    if a.get("section"):
        rows = [r for r in rows if owner_section(r["owner_type"],r["owner_id"]) == a["section"]]
    if a.get("status"):
        rows = [r for r in rows if r["status"] in a["status"].split(",")]
    for k in ("owner_type", "doc_type"):
        if a.get(k):
            rows = [r for r in rows if r[k] == a[k]]
    if a.get("owner_type") and a.get("owner_id"):
        rows = [r for r in rows if r["owner_id"] == int(a["owner_id"])]
    if a.get("from"):
        rows = [r for r in rows if r["expiry_date"] and r["expiry_date"] >= a["from"]]
    if a.get("to"):
        rows = [r for r in rows if r["expiry_date"] and r["expiry_date"] <= a["to"]]
    if a.get("q"):
        rows = [r for r in rows if a["q"] in (r["owner_label"] or "") or a["q"] in (r["title"] or "")]
    rows.sort(key=lambda r: (r["expiry_date"] or "9999"))
    checks = employee_check_attention() if not a.get("status") and not a.get("id") and not a.get("section") and not a.get("owner_id") and a.get("owner_type", "") in ("", "employee") else []
    if a.get("q"):
        checks = [c for c in checks if a["q"] in c["text"]]
    incomplete = [] if any(a.get(k) for k in ("status","id","section","owner_type","owner_id")) else [t for t in R.incomplete_rows(g.db) if can(owner_section(t['owner_type'], t['owner_id']))]
    if a.get('q'):
        incomplete = [t for t in incomplete if a['q'] in t['owner_label'] or a['q'] in t['title']]
    if a.get('owner_type'):
        incomplete = [t for t in incomplete if t['owner_type'] == a['owner_type']]
    if a.get('owner_id'):
        incomplete = [t for t in incomplete if str(t['owner_id']) == a['owner_id']]
    from .attendance import summary as attendance_summary
    attendance_alerts=attendance_summary({})['alerts'] if can('attendance') and not any(a.get(k) for k in ('id','status','section','owner_id','owner_type','q','from','to')) else []
    return jsonify(rows=rows, total=len(rows), check_alerts=checks, incomplete_alerts=incomplete, attendance_alerts=attendance_alerts)


@bp.post("/tracked_docs")
@guard(owner=True)
def tracked_add():
    b = body()
    if b.get("owner_type") not in OWNER_TYPES or not b.get("owner_id"):
        return err("المالك غير صالح")
    try:
        v = td_vals(b)
    except ValueError as e:
        return err(str(e))
    if not v.get("title"):
        return err("اسم الوثيقة مطلوب")
    tid = ex("""INSERT INTO tracked_docs(owner_type,owner_id,doc_type,title,expiry_date,expiry_raw,calendar,source,confirmed,note,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,'manual',1,?,?,?)""", b["owner_type"], int(b["owner_id"]), v.get("doc_type"), v["title"], v.get("expiry_date"),
             v.get("expiry_raw"), v.get("calendar"), v.get("note"), ts(), ts())
    audit("create", "tracked_docs", tid, "إضافة وثيقة بتاريخ انتهاء: " + v["title"], None, v)
    return jsonify(id=tid)


@bp.put("/tracked_docs/<int:tid>")
@guard(owner=True)
def tracked_put(tid):
    before = q1("SELECT * FROM tracked_docs WHERE id=?", tid)
    if not before:
        return err("غير موجود", 404)
    try:
        v = td_vals(body())
    except ValueError as e:
        return err(str(e))
    if "title" in v and not v["title"]:
        return err("اسم الوثيقة مطلوب؛ استخدم حذف لإزالة الوثيقة")
    update_row("tracked_docs", tid, v)
    if "expiry_date" in v and v["expiry_date"] != before["expiry_date"]:
        ex("INSERT INTO expiry_history VALUES(NULL,?,?,?,?,?)", tid, before["expiry_date"], v["expiry_date"], ts(), g.user["username"])
    audit("update", "tracked_docs", tid, "تعديل وثيقة: " + (before["title"] or ""), before, v)
    return jsonify(ok=True)


@bp.post("/tracked_docs/<int:tid>/renew")
@guard(owner=True)
def tracked_renew(tid):
    before = q1("SELECT * FROM tracked_docs WHERE id=?", tid)
    if not before:
        return err("غير موجود", 404)
    try:
        v = td_vals(body())
    except ValueError as e:
        return err(str(e))
    if not v.get("expiry_date"):
        return err("تاريخ الانتهاء الجديد مطلوب")
    update_row("tracked_docs", tid, dict(v, confirmed=1))
    ex("INSERT INTO expiry_history VALUES(NULL,?,?,?,?,?)", tid, before["expiry_date"], v["expiry_date"], ts(), g.user["username"])
    audit("renew", "tracked_docs", tid, f"تجديد: {before['title']} (السابق {before['expiry_date'] or 'غير مسجل'})", before, v)
    return jsonify(ok=True)


@bp.delete("/tracked_docs/<int:tid>")
@guard(owner=True)
def tracked_del(tid):
    before = q1("SELECT * FROM tracked_docs WHERE id=?", tid)
    if not before:
        return err("غير موجود", 404)
    ex("DELETE FROM expiry_history WHERE tracked_doc_id=?", tid)
    ex("DELETE FROM tracked_docs WHERE id=?", tid)
    audit("delete", "tracked_docs", tid, "حذف وثيقة: " + (before["title"] or ""), before)
    return jsonify(ok=True)


@bp.get("/tracked_docs/<int:tid>/history")
@guard()
def tracked_hist(tid):
    return jsonify(rows=q("SELECT * FROM expiry_history WHERE tracked_doc_id=? ORDER BY id DESC", tid))


# ---------------- المرفقات والروابط ----------------
def _owner_ok(t, i):
    tbl = {"employee": "employees", "item": "items", "vehicle": "vehicles", "driver": "drivers", "contract": "contract", "contract_fact":"contract_facts", "handover":"handovers"}.get(t)
    return bool(tbl) and bool(q1(f"SELECT 1 FROM {tbl} WHERE id=?", i))


@bp.get("/documents")
@guard()
def documents():
    t, i = request.args.get("owner_type"), request.args.get("owner_id")
    rows = q("SELECT * FROM documents WHERE owner_type=? AND owner_id=? ORDER BY id", t, i) if t and i else q("SELECT * FROM documents ORDER BY id")
    return jsonify(rows=[doc_out(d) for d in rows], total=len(rows))


@bp.post("/documents")
@guard(owner=True)
def doc_add():
    b = body()
    try:url=valid_url(b.get('url',''))
    except ValueError as e:return err(str(e))
    if not url:return err('الرابط مطلوب')
    if not _owner_ok(b.get("owner_type"), b.get("owner_id")):
        return err("المالك غير موجود")
    did = ex("INSERT INTO documents(owner_type,owner_id,role,label,kind,url,link_state,created_at) VALUES(?,?,?,?, 'drive',?,'saved',?)",
             b["owner_type"], int(b["owner_id"]), b.get("role") if b.get("role") in ("attachment", "contract_ref") else "attachment",
             (b.get("label") or "مرفق").strip(), url, ts())
    audit("create", "documents", did, "إضافة رابط مستند", None, dict(owner_type=b["owner_type"], owner_id=b["owner_id"]))
    return jsonify(id=did)


@bp.post("/documents/upload")
@guard(owner=True)
def doc_upload():
    f = request.files.get("file")
    t, i = request.form.get("owner_type"), request.form.get("owner_id")
    if not f or not f.filename:
        return err("لم يُرفع ملف")
    ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
    if ext not in ALLOWED_EXT:
        return err("نوع الملف غير مسموح (المسموح: " + "، ".join(sorted(ALLOWED_EXT)) + ")")
    if not _owner_ok(t, i):
        return err("المالك غير موجود")
    try:check_upload(f.stream,ext)
    except ValueError as e:return err(str(e))
    stored = secrets.token_hex(16) + "." + ext
    f.save(attachment_path(current_app.config["DATA_DIR"],stored))
    did = ex("""INSERT INTO documents(owner_type,owner_id,role,label,kind,local_name,stored_name,link_state,created_at)
                VALUES(?,?,'attachment',?,'local',?,?,'saved',?)""", t, int(i), request.form.get("label") or "نسخة محلية",
             secure_filename(f.filename) or f"file.{ext}", stored, ts())
    audit("create", "documents", did, "رفع نسخة محلية", None, dict(owner_type=t, owner_id=i, name=f.filename))
    return jsonify(id=did)


@bp.get("/documents/<int:did>/file")
@guard()
def doc_file(did):
    d = q1("SELECT * FROM documents WHERE id=?", did)
    if not d or d["kind"] != "local":
        return err("غير موجود", 404)
    if d["owner_type"] == "employee" and not can_full_id(g.user):
        return err("لا تملك صلاحية عرض مرفقات الكادر", 403)
    try:path=attachment_path(current_app.config['DATA_DIR'],d['stored_name'])
    except ValueError:return err('مسار المرفق غير صالح',404)
    if not path.is_file():return err('المرفق غير موجود',404)
    return send_file(path,download_name=d['local_name'],as_attachment=True)


@bp.put("/documents/<int:did>")
@guard(owner=True)
def doc_put(did):
    before = q1("SELECT * FROM documents WHERE id=?", did)
    if not before:
        return err("غير موجود", 404)
    b = body()
    v = pick(b, ["label", "verify_note"])
    if "url" in b:
        if before["kind"] != "drive": return err("هذا مرفق محلي")
        try: v["url"] = valid_url(b["url"])
        except ValueError as e: return err(str(e))
        if not v["url"]: return err("الرابط مطلوب")
    if "link_state" in b:
        if b["link_state"] not in ("saved", "opened", "verified"):
            return err("حالة غير صالحة")
        v["link_state"] = b["link_state"]
    if v:
        ex(f"UPDATE documents SET {','.join(k+'=?' for k in v)} WHERE id=?", *v.values(), did)
    audit("update", "documents", did, "تعديل حالة مستند", {k: before[k] for k in v}, v)
    return jsonify(ok=True)


@bp.delete("/documents/<int:did>")
@guard(owner=True)
def doc_del(did):
    before = q1("SELECT * FROM documents WHERE id=?", did)
    if not before:
        return err("غير موجود", 404)
    ex("DELETE FROM documents WHERE id=?", did)
    audit("delete", "documents", did, "حذف مستند/رابط", {k: before[k] for k in ("owner_type", "owner_id", "label", "kind")})
    return jsonify(ok=True)


DATE_PATTERNS = [re.compile(r"\b(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})\b"), re.compile(r"\b(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})\b")]


@bp.post("/documents/<int:did>/suggest")
@guard(owner=True)
def doc_suggest(did):
    d = q1("SELECT * FROM documents WHERE id=?", did)
    if not d or d["kind"] != "local" or not d["stored_name"].endswith(".pdf"):
        return err("الاقتراح يعمل على ملفات PDF المحلية فقط؛ ملفات Drive لا يقرؤها البرنامج المستقل")
    try:path=attachment_path(current_app.config['DATA_DIR'],d['stored_name'])
    except ValueError:return err('مسار المرفق غير صالح',404)
    if not path.is_file():return err('المرفق غير موجود',404)
    if not PDF_WORKER_LOCK.acquire(blocking=False):return err('جارٍ فحص ملف آخر؛ حاول بعد قليل',429)
    try:
        worker=Path(__file__).resolve().parents[1]/'scripts/pdf_dates_worker.py'
        result=subprocess.run([sys.executable,str(worker),str(path)],capture_output=True,text=True,encoding='utf-8',timeout=15)
        if result.returncode:return err('تعذر قراءة PDF أو تجاوز حدود الفحص')
        extracted=json.loads(result.stdout)
    except (OSError,subprocess.TimeoutExpired,ValueError):return err('تعذر قراءة PDF خلال المهلة المحددة')
    finally:PDF_WORKER_LOCK.release()
    g.db.execute("DELETE FROM date_suggestions WHERE document_id=? AND status='pending'", (did,))
    for row in extracted['rows']:
        g.db.execute("INSERT INTO date_suggestions(document_id,page,text,status,created_at) VALUES(?,?,?, 'pending',?)", (did,row['page'],row['text'],ts()))
    g.db.commit();n=len(extracted['rows'])
    note='تم الاكتفاء بحدود الفحص: 50 صفحة أو 250 تاريخًا' if extracted['limited'] else None if n else 'لم يُعثر على تواريخ في طبقة النص (قد يكون الملف مصورًا ويحتاج OCR أو مراجعة بشرية)'
    return jsonify(count=n,note=note,rows=q("SELECT * FROM date_suggestions WHERE document_id=? ORDER BY id",did))


@bp.post("/suggestions/<int:sid>/confirm")
@guard(owner=True)
def sug_confirm(sid):
    s = q1("SELECT * FROM date_suggestions WHERE id=?", sid)
    if not s or s["status"] != "pending":
        return err("غير موجود أو سبق البت فيه", 404)
    b = body()
    if b.get("owner_type") not in OWNER_TYPES or not b.get("owner_id"):
        return err("المالك غير صالح")
    if b.get("calendar") not in ("gregorian", "hijri"):
        return err("حدّد نوع التقويم؛ لا يُخمَّن")
    try:
        v = td_vals(b)
    except ValueError as e:
        return err(str(e))
    if not v.get("expiry_date") or not v.get("title"):
        return err("التاريخ الميلادي المؤكد والعنوان مطلوبان")
    v.setdefault("expiry_raw", s["text"])
    tid = ex("""INSERT INTO tracked_docs(owner_type,owner_id,doc_type,title,expiry_date,expiry_raw,calendar,source,confirmed,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,1,?,?)""", b["owner_type"], int(b["owner_id"]), v.get("doc_type"), v["title"], v["expiry_date"],
             v.get("expiry_raw"), v["calendar"], f"اقتراح مؤكد: مستند {s['document_id']} ص{s['page']}", ts(), ts())
    ex("UPDATE date_suggestions SET status='confirmed' WHERE id=?", sid)
    audit("confirm", "date_suggestions", sid, "تأكيد تاريخ مقترح", s, v)
    return jsonify(id=tid)


@bp.post("/suggestions/<int:sid>/reject")
@guard(owner=True)
def sug_reject(sid):
    ex("UPDATE date_suggestions SET status='rejected' WHERE id=? AND status='pending'", sid)
    audit("reject", "date_suggestions", sid, "رفض تاريخ مقترح")
    return jsonify(ok=True)


# ---------------- لوحة التحكم ----------------
def count_by(rows, key, order):
    d = {k: 0 for k in order}
    for r in rows:
        d[r[key] or "unrecorded"] = d.get(r[key] or "unrecorded", 0) + 1
    return d


def employee_check_attention():
    if not can("employees"):
        return []
    alerts = []
    for c in q("""SELECT c.*, e.name FROM employee_checks c JOIN employees e ON e.id=c.employee_id
                  WHERE c.norm='nonconforming' ORDER BY e.seq, e.id, c.id"""):
        text = f"{c['name']} — {c['label']}"
        if c["reason"]:
            text += f" — {c['reason']}"
        alerts.append(dict(kind="غير مطابق", text=text, name=c["name"], label=c["label"], reason=c["reason"],
                           href="#/employees?" + urlencode({"q":c["name"], "fail":c["key"]}),
                           source="employee_check", employee_id=c["employee_id"], check_key=c["key"]))
    return alerts


@bp.get("/dashboard")
@guard()
def dashboard():
    emps = q(EMP_SQL) if can("employees") else []
    items_ = [item_view(i) for i in q("SELECT * FROM items ORDER BY section, seq") if can(i["section"])]
    td = [t for t in R.tracked_rows(g.db) if can(owner_section(t["owner_type"],t["owner_id"]))]
    ex_all = count_by(td, "status", ["valid", "soon", "today", "expired", "unrecorded"])
    by_type = {}
    for t in td:
        k = {"employee": "الهويات", "item": "تراخيص وبنود", "vehicle": "السيارات", "driver": "رخص السائقين"}[t["owner_type"]]
        by_type.setdefault(k, {"valid": 0, "soon": 0, "today": 0, "expired": 0, "unrecorded": 0})[t["status"]] += 1
    equip = [i for i in items_ if i["section"] == "equipment"]
    veh_items = [i for i in items_ if i["section"] == "vehicles"]
    docs = [d for d in q("SELECT * FROM documents") if can(owner_section(d["owner_type"],d["owner_id"]))]
    att = {s: {"with": sum(i["has_attachment"] for i in items_ if i["section"] == s),
               "without": sum(not i["has_attachment"] for i in items_ if i["section"] == s)} for s in SECTION_AR}
    att["employees"] = {"with": sum(1 for e in emps if e["doc_count"]), "without": sum(1 for e in emps if not e["doc_count"])}
    attention = employee_check_attention()
    incomplete = [t for t in R.incomplete_rows(g.db) if can(owner_section(t['owner_type'], t['owner_id']))]
    for t in incomplete:
        section = owner_section(t['owner_type'], t['owner_id'])
        attention.append(dict(kind='غير مكتمل', text=f"{t['owner_label']} — {t['title']}", href=f'#/{section}?id={t["owner_id"]}', source='incomplete'))
    for i in items_:
        if i["consultant_result"] == "nonconforming":
            attention.append(dict(kind="غير مطابق", text=f"{i['section_ar']}: {i['name']}", href=f"#/{i['section']}?id={i['id']}"))
        if i["required_qty"] is not None and not i["required_qty_confirmed"]:
            attention.append(dict(kind="كمية تحتاج تأكيدًا", text=f"{i['name']} (المقترح {i['required_qty']:g})", href=f"#/{i['section']}?id={i['id']}"))
    for t in td:
        if t["status"] in ("expired", "today", "soon"):
            attention.append(dict(kind=STATUS_AR[t["status"]], text=f"{t['owner_label']} — {t['title']} ({t['expiry_date']})", href=f"#/expiries?id={t['id']}"))
    nf = q1("SELECT count(*) c FROM contract_facts WHERE needs_review=1")["c"]
    if nf and can("contract"):
        attention.append(dict(kind="مراجعة العقد", text=f"{nf} بنود في العقد تحتاج مراجعة (منها اختلاف القيم المالية)", href="#/contract"))
    res = dict(
        today=today_riyadh().isoformat(),
        employees=dict(total=len(emps), core=sum(e["job_group"] == "core" for e in emps), relief=sum(e["job_group"] == "relief" for e in emps),
                       consultant=count_by(emps, "consultant_result", ["conforming", "nonconforming", "incomplete", "unrecorded"]),
                       authority=count_by(emps, "authority_status", ["approved", "rejected", "unrecorded"]),
                       with_nc=sum(1 for e in emps if e["nc"]),
                       criteria_nc={r["label"]: r["n"] for r in q("SELECT label, sum(norm='nonconforming') n FROM employee_checks GROUP BY key ORDER BY id")} if can("employees") else {}),
        vehicles=dict(registered=q1("SELECT count(*) c FROM vehicles")["c"] if can("vehicles") else 0, drivers=q1("SELECT count(*) c FROM drivers")["c"] if can("vehicles") else 0,
                      followup_items=len(veh_items), followup=count_by(veh_items, "consultant_result", ["conforming", "nonconforming", "incomplete", "unrecorded"])),
        equipment=dict(items=len(equip), result=count_by(equip, "consultant_result", ["conforming", "nonconforming", "incomplete", "unrecorded"]),
                       short_items=sum(1 for i in equip if i["short"]),
                       short_unconfirmed=sum(1 for i in equip if i["short"] and not i["required_qty_confirmed"]),
                       op_unrecorded=sum(1 for i in equip if not i["op_status"])),
        documents=dict(total=len(docs), states=count_by(docs, "link_state", ["saved", "opened", "verified"]), attachments=att),
        expiry=dict(all=ex_all, by_type=by_type,
                    list=[t for t in td if t["status"] in ("expired", "today", "soon")][:12]),
        attention=attention, attention_total=len(attention), incomplete_total=len(incomplete))
    if g.user["role"] == "owner":
        res["recent"] = q("SELECT ts,username,action,summary FROM audit_log ORDER BY id DESC LIMIT 8")
    if can('attendance'):
        from .attendance import summary as attendance_summary
        att_summary=attendance_summary({})
        res['attendance']=att_summary['totals']
        res['attention'].extend(att_summary['alerts'])
        res['attention_total']=len(res['attention'])
    res["visible_sections"] = [s for s in ("employees","vehicles","equipment","licenses","expiries","contract") if can(s)]
    return jsonify(res)


# ---------------- التقارير والتصدير ----------------
@bp.get("/reports/<name>")
@guard(reports=True)
def report(name):
    try:
        return jsonify(R.build(g.db, g.user, name, request.args))
    except KeyError:
        return err("تقرير غير معروف", 404)


@bp.get("/reports")
@guard(reports=True)
def report_list():
    return jsonify(rows=[dict(name=k, title=v) for k, v in R.REPORTS.items()])


@bp.get("/export/<name>.xlsx")
@guard(reports=True)
def export(name):
    try:
        rep = R.build(g.db, g.user, name, request.args)
    except KeyError:
        return err("تقرير غير معروف", 404)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = rep["title"][:30]
    ws.sheet_view.rightToLeft = True

    def put(r, c, v):
        cell = ws.cell(r, c)
        cell.value = v if not isinstance(v, str) else v
        if isinstance(v, str):
            cell.data_type = "s"          # لا تُفسَّر النصوص كمعادلات (=, +, -, @)
        return cell
    put(1, 1, rep["title"]); put(2, 1, "تاريخ التقرير: " + dual_calendar(today_riyadh().isoformat()))
    for j, c in enumerate(rep["columns"], 1):
        put(4, j, c["label"]).font = openpyxl.styles.Font(bold=True)
    for i, row in enumerate(rep["rows"], 5):
        for j, c in enumerate(rep["columns"], 1):
            v = row.get(c["key"])
            put(i, j, v if v is None or isinstance(v, (int, float)) else dual_calendar(str(v)))
    for j in range(1, len(rep["columns"]) + 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width = 24
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    audit("export", "reports", name, "تصدير Excel: " + rep["title"])
    return send_file(buf, as_attachment=True, download_name=f"{name}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ---------------- السجل والمستخدمون ----------------
@bp.get("/audit")
@guard(owner=True)
def audit_list():
    a = request.args
    sql, args = "SELECT * FROM audit_log WHERE 1=1", []
    for k in ("entity", "username", "action"):
        if a.get(k):
            sql += f" AND {k}=?"; args.append(a[k])
    if a.get("q"):
        sql += " AND (summary LIKE ? OR entity_id=?)"; args += [f"%{a['q']}%", a["q"]]
    if a.get("from"):
        sql += " AND ts>=?"; args.append((datetime.fromisoformat(a["from"]+"T00:00:00+03:00").astimezone(timezone.utc)).isoformat())
    if a.get("to"):
        sql += " AND ts<?"; args.append((datetime.fromisoformat(a["to"]+"T00:00:00+03:00") + timedelta(days=1)).astimezone(timezone.utc).isoformat())
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(min(int(a.get("limit", 200)), 1000))
    return jsonify(rows=q(sql, *args))


USER_COLS = "id,username,display_name,role,active,can_see_full_id,can_use_reports,created_at"


@bp.get("/users")
@guard(owner=True)
def users():
    return jsonify(rows=q(f"SELECT {USER_COLS} FROM users ORDER BY id"))


@bp.post("/users")
@guard(owner=True)
def user_add():
    b = body()
    if not isinstance(b.get('username',''),str) or not isinstance(b.get('password',''),str):return err('بيانات الحساب غير صالحة')
    un, pw, role = (b.get("username") or "").strip(), b.get("password") or "", b.get("role")
    if role not in ("owner", "manager", "supervisor"):
        return err("الدور: مالك أو مدير أو مشرف مجمع")
    if not 3<=len(un)<=80 or not MIN_PW<=len(pw)<=1024:
        return err(f"اسم المستخدم 3 أحرف على الأقل وكلمة المرور {MIN_PW} على الأقل")
    default = 1 if role in ("owner","manager") else 0
    try:
        uid = ex("INSERT INTO users(username,display_name,role,password_hash,can_see_full_id,can_use_reports,created_at) VALUES(?,?,?,?,?,?,?)",
                 un, (b.get("display_name") or un).strip(), role, hash_pw(pw), 1 if b.get("can_see_full_id", default) else 0,
                 1 if b.get("can_use_reports", default) else 0, ts())
    except sqlite3.IntegrityError:
        return err("اسم المستخدم موجود", 409)
    audit("create", "users", uid, f"إنشاء حساب {un} ({role})", None, dict(username=un, role=role))
    return jsonify(id=uid)


@bp.put("/users/<int:uid>")
@guard(owner=True)
def user_put(uid):
    b=body();v={}
    for key in ('username','display_name'):
        if key in b:
            value=b[key]
            if not isinstance(value,str):return err('اسم الحساب غير صالح')
            value=value.strip()
            if key=='username' and (not 3<=len(value)<=80 or any(ord(c)<32 for c in value)):return err('اسم الدخول من 3 إلى 80 حرفًا دون محارف تحكم')
            if key=='display_name' and (not value or len(value)>160):return err('الاسم الظاهر مطلوب حتى 160 حرفًا')
            v[key]=value
    if 'role' in b:
        if b['role'] not in ('owner','manager','supervisor'):return err('دور غير صالح')
        v['role']=b['role']
    for key in ('active','can_see_full_id','can_use_reports'):
        if key in b:
            if type(b[key]) not in (bool,int) or b[key] not in (0,1):return err('حالة أو صلاحية غير صالحة')
            v[key]=int(b[key])
    password=b.get('password')
    if password:
        if not isinstance(password,str) or not MIN_PW<=len(password)<=1024:return err(f'كلمة المرور {MIN_PW} أحرف على الأقل')
        v['password_hash']=hash_pw(password)
    g.db.execute('BEGIN IMMEDIATE')
    before=q1(f'SELECT {USER_COLS} FROM users WHERE id=?',uid)
    if not before:
        g.db.rollback();return err('الحساب غير موجود',404)
    role=v.get('role',before['role']);active=v.get('active',before['active'])
    if before['role']=='owner' and before['active'] and (role!='owner' or not active):
        others=q1("SELECT count(*) n FROM users WHERE role='owner' AND active=1 AND id<>?",uid)['n']
        if not others:
            g.db.rollback();return err('يلزم وجود حساب مالك آخر مفعّل قبل تغيير دور آخر مالك أو تعطيله',409)
    if 'username' in v and q1('SELECT id FROM users WHERE username=? COLLATE NOCASE AND id<>?',v['username'],uid):
        g.db.rollback();return err('اسم المستخدم موجود بالفعل',409)
    try:
        if v:g.db.execute(f"UPDATE users SET {','.join(k+'=?' for k in v)} WHERE id=?",(*v.values(),uid))
        if not active:g.db.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
        elif 'password_hash' in v:
            keep=sha(session['sid']) if uid==g.user['id'] else None
            g.db.execute('DELETE FROM sessions WHERE user_id=? AND token_hash IS NOT ?',(uid,keep))
        g.db.commit()
    except sqlite3.IntegrityError:
        g.db.rollback();return err('اسم المستخدم موجود بالفعل',409)
    safe={k:val for k,val in v.items() if k!='password_hash'}
    if 'password_hash' in v:safe['password']='***'
    audit('update','users',uid,'تعديل بيانات حساب '+before['username'],before,safe)
    return jsonify(ok=True,self_changed=uid==g.user['id'])


@bp.post("/users/<int:uid>/password")
@guard(owner=True)
def user_pw(uid):
    u = q1("SELECT * FROM users WHERE id=?", uid)
    pw = body().get("password") or ""
    if not u:
        return err("غير موجود", 404)
    if not isinstance(pw,str) or not MIN_PW<=len(pw)<=1024:
        return err(f"كلمة المرور {MIN_PW} على الأقل")
    ex("UPDATE users SET password_hash=? WHERE id=?", hash_pw(pw), uid)
    keep = sha(session["sid"]) if uid == g.user["id"] else None
    ex("DELETE FROM sessions WHERE user_id=? AND token_hash IS NOT ?", uid, keep)
    audit("password_reset", "users", uid, "إعادة تعيين كلمة مرور " + u["username"])
    return jsonify(ok=True)


# ---------------- الاستيراد والنسخ الاحتياطي ----------------
@bp.post("/import/preview")
@guard(owner=True)
def import_preview():
    tmp = os.path.join(current_app.config["DATA_DIR"], "tmp")
    token = secrets.token_hex(8)
    path = os.path.join(tmp, f"import_{token}.xlsx")
    f = request.files.get("file")
    if f and f.filename:
        if not f.filename.lower().endswith(".xlsx"):
            return err("ملف .xlsx فقط")
        try:check_upload(f.stream,'xlsx')
        except ValueError as e:return err(str(e))
        f.save(path)
        name = secure_filename(f.filename) or "upload.xlsx"
    else:
        import shutil
        shutil.copy(current_app.config["BUNDLED_EXCEL"], path)
        name = "guards_source.xlsx (المرفق مع الحزمة)"
    try:
        p = importer.parse(path)
    except Exception as e:  # ملف غير مطابق للهيكل
        os.remove(path)
        return err("تعذر قراءة الملف: " + str(e))
    s = importer.summarize(p)
    existing = q1("SELECT count(*) c FROM employees")["c"]
    s["already_in_db"] = dict(employees=existing, previous_imports=q1("SELECT count(*) c FROM import_runs")["c"])
    return jsonify(token=token, filename=name, summary=s)


@bp.post("/import/commit")
@guard(owner=True)
def import_commit():
    token = re.sub(r"[^0-9a-f]", "", body().get("token") or "")
    path = os.path.join(current_app.config["DATA_DIR"], "tmp", f"import_{token}.xlsx")
    if not token or not os.path.exists(path):
        return err("انتهت المعاينة؛ أعدها أولًا")
    p = importer.parse(path)
    rep = importer.commit(g.db, p, os.path.basename(path), importer.file_sha(path), g.user["id"], now_utc())
    os.remove(path)
    audit("import", "import_runs", None, "استيراد Excel", None, rep)
    return jsonify(report=rep)


@bp.post("/backup/create")
@guard(owner=True)
def backup_create():
    out = B.create_backup(current_app.config["DATA_DIR"])
    audit("backup", "backup", os.path.basename(out), "إنشاء نسخة احتياطية")
    return jsonify(name=os.path.basename(out), size=os.path.getsize(out))


@bp.get("/backup/list")
@guard(owner=True)
def backup_list():
    d = os.path.join(current_app.config["DATA_DIR"], "backups")
    return jsonify(rows=[dict(name=n, size=os.path.getsize(os.path.join(d, n))) for n in sorted(os.listdir(d), reverse=True) if n.endswith(".zip")],
                   folder=d)


@bp.get("/backup/download/<name>")
@guard(owner=True)
def backup_dl(name):
    if not re.fullmatch(r"backup-[0-9][A-Za-z0-9_-]*\.zip", name):
        return err("اسم غير صالح", 400)
    p = os.path.join(current_app.config["DATA_DIR"], "backups", name)
    return send_file(p, as_attachment=True) if os.path.isfile(p) and not os.path.islink(p) else err("غير موجود", 404)
