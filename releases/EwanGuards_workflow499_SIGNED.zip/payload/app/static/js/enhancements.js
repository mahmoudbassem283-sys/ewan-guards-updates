'use strict';
NAV.splice(3,0,['attendance','الحضور والانصراف']);
NAV.find(n=>n[0]==='registers')[1]='التقارير اليومية والأسبوعية والشهرية';
Object.assign(sectionNames,{attendance:'الحضور والانصراف',weekly_reports:'التقارير الأسبوعية'});
const metricNames={total:'الإجمالي',conforming:'مطابق',nonconforming:'غير مطابق',incomplete:'غير مكتمل',unrecorded:'لم يسجل',expired:'وثائق منتهية',soon:'وثائق قريبة الانتهاء',valid:'وثائق سارية بعد 30 يومًا'};
const metricSections={employees:'الكادر',vehicles:'بنود متابعة السيارات',equipment:'الأجهزة والأدوات',licenses:'السجلات والتراخيص',attendance:'الحضور والانصراف'};
const attendanceMetricNames={total:'إجمالي التكليفات',present:'المسجل حضورهم',absent:'الغياب المسجل',late:'حالات التأخير',pending:'لم يسجل الحضور',missing_checkout:'انصراف غير مسجل بعد الوردية',shortfall:'نقص الحضور المسجل',unapproved:'سجلات بانتظار الاعتماد',flex_total:'تكليفات الدوام المرن'};
const metricsFor=s=>s==='attendance'?attendanceMetricNames:metricNames;
function defaultAttendanceCards(){return ['present','absent','late','pending','shortfall'].map(metric=>({id:'attendance_'+metric,section:'attendance',metric,label:attendanceMetricNames[metric],note:'اليوم — بتوقيت مكة',align:'center',number_align:'center',visible:true,color:['absent','shortfall'].includes(metric)?'#c8481f':metric==='present'?'#0a8579':'#26789c'}));}
function defaultMetricCards(){return [...Object.keys(metricSections).filter(s=>s!=='attendance').flatMap(section=>['total','conforming','nonconforming','incomplete','unrecorded'].map(metric=>({id:section+'_'+metric,section,metric,label:metricNames[metric],align:'center',number_align:'center',visible:true,color:metric==='nonconforming'?'#c8481f':metric==='unrecorded'?'#a97900':metric==='conforming'?'#0a8579':'#26789c'}))),...defaultAttendanceCards()];}
function metricLink(s,m){if(s==='attendance')return '#/attendance?'+qs({date:today,metric:m});if(['expired','soon','valid'].includes(m))return '#/expiries?'+qs({section:s,status:m==='soon'?'soon,today':m});return '#/'+s+(m==='total'?'':'?'+qs({[s==='employees'?'consultant':'result']:m}));}
function validityBadge(s){return badge(s==='expired'?'منتهية':s==='unrecorded'||!s?'غير مسجل':'سارية',s==='expired'?'bad':s==='unrecorded'||!s?'mute':'ok');}
function trackedStates(rows){return rows.length?rows.map(t=>el('div',{},expiryValidity(t.status,expiryDays(t.expiry_date)))):badge('غير مسجل','mute');}
// A compact edit menu keeps maintenance actions out of the date cell until needed.
trackedLines=function(ot,oid,rows,refresh){return rows.map(t=>el('div',{class:'compact-date'},ltr(t.expiry_date||''),canWrite()&&el('details',{class:'noprint'},el('summary',{},'إجراءات'),trackedActions(ot,oid,t,refresh))));};

function hijriText(iso){if(!iso)return '';const p=Object.fromEntries(new Intl.DateTimeFormat('en-u-ca-islamic-umalqura',{year:'numeric',month:'2-digit',day:'2-digit',timeZone:'Asia/Riyadh'}).formatToParts(new Date(iso+'T12:00:00+03:00')).map(x=>[x.type,x.value]));return p.year+'/'+p.month+'/'+p.day;}
function enhanceDateField(inp,wrap,label){
  const mode=el('select',{'aria-label':'تقويم '+label},[['gregorian','ميلادي'],['hijri','هجري'],['both','ميلادي وهجري']].map(([k,t])=>el('option',{value:k,selected:k===(appearance.date_display||'gregorian')},t)));
  const hi=el('input',{dir:'ltr',placeholder:'1448/06/01','aria-label':'التاريخ الهجري '+label}),note=el('small',{class:'date-error',role:'status'});
  let last=inp.value;
  const draw=()=>{inp.hidden=mode.value==='hijri';hi.hidden=mode.value==='gregorian';hi.value=inp.value?hijriText(inp.value):'';};
  const fromHi=()=>{const parts=Hijri.parseHijriText(hi.value),iso=parts&&Hijri.hijriToGregorian(...parts);inp.value=iso||'';inp.dataset.dateInvalid=hi.value&&!iso?'1':'';note.textContent=inp.dataset.dateInvalid?'تاريخ هجري غير صالح؛ لن يتم الحفظ':'';};
  hi.addEventListener('input',fromHi);inp.addEventListener('input',()=>{inp.dataset.dateInvalid='';note.textContent='';hi.value=inp.value?hijriText(inp.value):'';});mode.addEventListener('change',()=>{if(inp.dataset.dateInvalid){note.textContent='صحّح التاريخ الهجري أو امسحه قبل تغيير التقويم';return;}draw();});
  wrap.insertBefore(mode,inp);wrap.append(hi,note);draw();
}
expiryModal=function(ot,oid,cur,onDone,sugId,renew){
  const title=el('input',{value:cur.title||''}),inp=el('input',{type:'date',value:cur.expiry_date||'',id:'date-expiry'}),dateBox=el('div',{},el('label',{},'تاريخ الانتهاء'),inp);enhanceDateField(inp,dateBox,'تاريخ الانتهاء');
  const select=dateBox.querySelector('select');if(cur.calendar==='hijri'){select.value='hijri';select.dispatchEvent(new Event('change'));}
  const linkLabel=el('input',{value:'مرفق الوثيقة'}),link=el('input',{dir:'ltr',placeholder:'https://drive.google.com/...'});
  const m=modal(renew?'تجديد وثيقة':'تاريخ انتهاء الوثيقة',el('label',{},'اسم الوثيقة'),title,dateBox,
    !cur.id&&!sugId&&el('div',{},el('label',{},'اسم المرفق'),linkLabel,el('label',{},'رابط المرفق'),link),
    el('button',{class:'btn primary',onclick:guarded(async()=>{
      if(inp.dataset.dateInvalid)throw new Error('صحّح التاريخ الهجري قبل الحفظ');
      if(!title.value.trim())throw new Error('اسم الوثيقة مطلوب');
      const calendar=select.value==='hijri'?'hijri':'gregorian',b={title:title.value,expiry_date:inp.value,calendar,expiry_raw:calendar==='hijri'?hijriText(inp.value):inp.value,doc_type:cur.doc_type,initial_label:linkLabel.value,initial_url:!cur.id&&!sugId?link.value:''};
      if(sugId)await api('POST',`/api/suggestions/${sugId}/confirm`,{...b,owner_type:ot,owner_id:oid});
      else if(cur.id)await api(renew?'POST':'PUT',`/api/tracked_docs/${cur.id}`+(renew?'/renew':''),b);
      else await api('POST','/api/tracked_docs',{...b,owner_type:ot,owner_id:oid});
      m.close();await onDone();toast('تم حفظ التاريخ وربطه بالتنبيهات');
    })},'حفظ'));
};
const indicatorCatalog={};
function loadIndicatorCatalog(sections){for(const c of sections||[])indicatorCatalog[c.key]=c.groups.map(g=>({id:g.id||g.key,title:g.title}));}
const businessSectionNames={employees:'الكادر',vehicles:'السيارات والاستمارات',equipment:'الأجهزة والأدوات',licenses:'السجلات والتراخيص',attendance:'الحضور والانصراف',contract:'العقد',registers:'التقارير اليومية والأسبوعية والشهرية',claims:'المستخلصات الشهرية'};
function matchesDocumentStatus(rows,status){const allowed=status.split(',');return rows.length?rows.some(t=>allowed.includes(t.status)):allowed.includes('unrecorded');}
function sectionCardSettings(draft){
  draft.section_cards ||= {};
  const select=(value,cb)=>el('select',{onchange:e=>cb(e.target.value)},[['right','يمين'],['center','وسط'],['left','يسار']].map(([v,t])=>el('option',{value:v,selected:v===value},t)));
  return el('div',{class:'card'},el('p',{},'بطاقة واحدة لكل قسم، بداخلها الإجمالي وتفصيل البنود ومؤشراته. الأعداد مرتبطة بالسجلات الفعلية.'),Object.entries(businessSectionNames).map(([key,title],i)=>{
    const c=draft.section_cards[key] ||= {label:title,visible:true,order:i,color:draft.colors.blue,align:'right',number_align:'right',breakdown:true,indicators:true};
    const checkbox=(label,k)=>el('label',{class:'inline-check'},el('input',{type:'checkbox',checked:c[k]!==false,onchange:e=>c[k]=e.target.checked}),label);
    return el('div',{class:'setting-row section-card-editor','data-section-editor':key},el('b',{},title),checkbox('إظهار القسم','visible'),el('input',{value:c.label,'aria-label':'اسم بطاقة '+title,oninput:e=>c.label=e.target.value}),el('input',{type:'color',value:c.color,oninput:e=>c.color=e.target.value}),el('label',{},'الترتيب',el('input',{type:'number',min:0,max:100,value:c.order,oninput:e=>c.order=Number(e.target.value)})),el('label',{},'محاذاة النص',select(c.align,v=>c.align=v)),el('label',{},'محاذاة العدد',select(c.number_align,v=>c.number_align=v)),checkbox('تفصيل البنود','breakdown'),checkbox('مؤشرات القسم','indicators'),el('div',{class:'section-indicator-settings'},(indicatorCatalog[key]||[]).map(g=>el('label',{class:'inline-check'},el('input',{type:'checkbox',checked:c.indicators!==false&&c.indicator_visibility?.[g.id]!==false,'data-indicator-toggle':g.id,onchange:e=>{c.indicator_visibility ||= {};if(e.target.checked&&c.indicators===false){for(const x of indicatorCatalog[key])c.indicator_visibility[x.id]=false;c.indicators=true;}c.indicator_visibility[g.id]=e.target.checked;}}),g.title))));
  }));
}
VIEWS.dashboard=async()=>{
  const r=await api('GET','/api/section-cards');loadIndicatorCatalog(r.sections);const grid=el('div',{class:'section-overview-grid'}),root=el('div',{'data-dashboard-layout':'sections'},el('h2',{},'لوحة التحكم'),grid);
  const cards=r.sections.map((c,i)=>({...c,order:appearance.section_cards?.[c.key]?.order??i})).sort((a,b)=>a.order-b.order);
  for(const c of cards){
    const config=appearance.section_cards?.[c.key]||{};if(config.visible===false)continue;
    const color=config.color||appearance.colors?.blue||'#26789c',fg=textColor(color),title=config.label??c.title;
    const card=el('section',{class:'card section-overview','data-section-card':c.key});
    const breakdown=el('div',{class:'section-breakdown'},c.breakdown.map(d=>el('a',{href:d.href,class:'section-breakdown-entry'},el('b',{},d.count??'—'),el('span',{},d.label),d.detail&&el('small',{},d.detail))));
    const header=el('div',{class:'section-summary',style:`background:${color};color:${fg};text-align:${config.align||'right'}`},el('div',{class:'section-heading'},el('a',{href:c.href,class:'section-title'},title),el('a',{href:c.href,class:'section-total',style:'text-align:'+(config.number_align||'right')},el('strong',{'data-section-total':c.key},c.total),el('span',{},({employees:'إجمالي الكادر',vehicles:'عدد بنود المتابعة',equipment:'عدد البنود',licenses:'عدد البنود',attendance:'تكليفات اليوم',contract:'عدد العقود',registers:'عدد التقارير',claims:'عدد المستخلصات'})[c.key]||c.unit))),config.breakdown!==false&&breakdown);
    card.append(header);
    if(c.details?.length)card.append(el('div',{class:'section-extra-details'},c.details.map(d=>el('a',{href:d.href},el('b',{},d.count),' ',d.label))));
    if(config.indicators!==false){
      const charts=el('div',{class:'section-local-indicators'}),shown=new Set(['total',...c.groups.flatMap(g=>g.segments.map(x=>x.key))]);
      const indicatorOrder=config.indicator_order||[];const groups=c.groups.map((g,i)=>({...g,defaultOrder:i})).sort((a,b)=>(indicatorOrder.includes(a.id)?indicatorOrder.indexOf(a.id):indicatorOrder.length+a.defaultOrder)-(indicatorOrder.includes(b.id)?indicatorOrder.indexOf(b.id):indicatorOrder.length+b.defaultOrder));
      for(const g of groups){
        if(config.indicator_visibility?.[g.id]===false)continue;
        const segs=g.segments.map(x=>{
          const cfg=(appearance.metric_cards||[]).find(m=>m.section===c.key&&m.metric===x.key);
          // Old metric customization applies to its own data basis only.
          const apply=g.key==='result'||g.key==='attendance'||(g.key==='expiry'&&x.key!=='unrecorded');
          shown.add(x.key);
          return {...x,label:apply?(cfg?.label??x.label):x.label,color:apply&&cfg?.color?cfg.color:COL[x.key]||({present:'#0a8579',pending:'#ffc22d',absent:'#c8481f',attached:'#0a8579',missing:'#a97900'})[x.key]||'#8597a5',visible:!apply||cfg?.visible!==false};
        }).filter(x=>x.visible);
        if(segs.length){const chart=donut(g.title,segs,'');chart.classList.add('section-chart');chart.dataset.indicatorBasis=g.basis;chart.dataset.indicatorId=g.id||g.key;charts.append(chart);}
      }
      card.append(charts);
      const extraOrder=config.extra_order||[];const extra=(appearance.metric_cards||[]).filter(m=>m.section===c.key&&m.visible!==false&&!shown.has(m.metric)&&Object.hasOwn(c.metrics,m.metric)).map((m,i)=>({...m,extraId:m.id||m.metric+'_'+i,defaultOrder:i})).sort((a,b)=>(extraOrder.includes(a.extraId)?extraOrder.indexOf(a.extraId):extraOrder.length+a.defaultOrder)-(extraOrder.includes(b.extraId)?extraOrder.indexOf(b.extraId):extraOrder.length+b.defaultOrder));
      if(extra.length)card.append(el('div',{class:'section-custom-metrics'},extra.map(m=>el('div',{'data-extra-id':m.extraId,class:'extra-metric-entry'},el('a',{href:metricLink(c.key,m.metric),style:'text-align:'+m.align},el('span',{},m.label),el('b',{},c.metrics[m.metric]))))));
    }
    grid.append(card);
  }
  setupDashboardDrag(grid);
  if(isOwner())root.append(el('a',{href:'#/settings',class:'btn noprint'},'تخصيص بطاقات الأقسام'));
  return root;
};
function metricSettings(draft){
  draft.date_display ||= 'gregorian';if(!Array.isArray(draft.metric_cards))draft.metric_cards=defaultMetricCards();
  const list=el('div',{}),mode=el('select',{},[['gregorian','ميلادي فقط'],['hijri','هجري فقط'],['both','ميلادي وهجري']].map(([v,t])=>el('option',{value:v,selected:draft.date_display===v},t)));mode.onchange=()=>draft.date_display=mode.value;
  const select=(values,value,cb)=>el('select',{onchange:e=>cb(e.target.value)},Object.entries(values).map(([v,t])=>el('option',{value:v,selected:v===value},t)));
  const draw=()=>list.replaceChildren(...draft.metric_cards.map((c,i)=>el('div',{class:'setting-row metric-editor'},el('label',{},el('input',{type:'checkbox',checked:c.visible!==false,onchange:e=>c.visible=e.target.checked}),'إظهار'),
    select(metricSections,c.section,v=>{c.section=v;c.metric='total';draw();}),select(metricsFor(c.section),c.metric,v=>c.metric=v),el('input',{value:c.label,'aria-label':'عنوان البطاقة',oninput:e=>c.label=e.target.value}),el('input',{value:c.note||'',placeholder:'وصف اختياري للبطاقة',oninput:e=>c.note=e.target.value}),
    el('label',{},'محاذاة النص',select({right:'يمين',center:'وسط',left:'يسار'},c.align,v=>c.align=v)),el('label',{},'محاذاة الرقم',select({right:'يمين',center:'وسط',left:'يسار'},c.number_align,v=>c.number_align=v)),el('input',{type:'color',value:c.color,oninput:e=>c.color=e.target.value}),
    el('button',{class:'btn sm',disabled:i===0,onclick:()=>{[draft.metric_cards[i-1],draft.metric_cards[i]]=[c,draft.metric_cards[i-1]];draw();}},'أعلى'),
    el('button',{class:'btn sm',disabled:i===draft.metric_cards.length-1,onclick:()=>{[draft.metric_cards[i+1],draft.metric_cards[i]]=[c,draft.metric_cards[i+1]];draw();}},'أسفل'),
    el('button',{class:'btn sm danger',onclick:()=>{draft.metric_cards.splice(i,1);draw();}},'حذف تخصيص المؤشر'))));draw();
  return el('div',{class:'card'},el('h3',{},'طريقة عرض التاريخ في البرنامج'),mode,el('p',{class:'muted'},'تغيير العرض لا يغيّر تاريخ الانتهاء أو حساب التنبيهات. نوع الإدخال متاح عند كل تاريخ.'),el('h3',{},'مؤشرات داخل بطاقات الأقسام'),el('p',{},'اختر القسم ومصدر العدد؛ تتحدث القيمة من السجلات. بطاقات صلاحية الوثائق تعد الوثائق، وبطاقات المطابقة تعد الموظفين أو بنود القسم.'),list,el('button',{class:'btn',onclick:()=>{draft.metric_cards.push({id:'custom_'+Date.now(),section:'employees',metric:'total',label:'مؤشر جديد',align:'center',number_align:'center',visible:true,color:'#26789c'});draw();}},'إضافة مؤشر داخل القسم'));
}

function attendanceConfig(cfg){
  const draft=structuredClone(cfg),box=el('div',{}),inputs=[];
  for(const s of draft.shifts){const row=el('div',{class:'card kv'});for(const [k,l,type] of [['name','اسم الوردية','text'],['start','البداية','time'],['end','النهاية','time'],['required','العدد المطلوب وفق العقد','number']]){const inp=el('input',{type,value:s[k]??'',min:k==='required'?0:null});inp.oninput=()=>s[k]=k==='required'?(inp.value===''?null:Number(inp.value)):inp.value;row.append(el('div',{},el('label',{},l),inp));}box.append(row);}
  const ref=el('textarea',{value:draft.reference,placeholder:'رقم البند وصفحته / المرجع المعتمد'}),grace=el('input',{type:'number',min:0,max:120,value:draft.grace_minutes}),confirmed=el('input',{type:'checkbox',checked:draft.confirmed});
  const m=modal('ضبط الورديات الثلاث',el('p',{class:'note'},'أدخل المواعيد والأعداد من العقد أو الجدول المعتمد. لا يفترض النظام اشتراطات أو سماحًا أو خصومات مالية.'),box,el('label',{},'المرجع المعتمد'),ref,el('label',{},'دقائق السماح المعتمدة (صفر افتراضيًا)'),grace,el('label',{},confirmed,'راجعت واعتمدت إعدادات الورديات'),el('button',{class:'btn primary',onclick:guarded(async()=>{draft.reference=ref.value;draft.grace_minutes=Number(grace.value);draft.confirmed=confirmed.checked;await api('PUT','/api/attendance/config',draft);m.close();reload();})},'حفظ'));
}
async function rosterPlan(cfg,day){
  const r=await api('GET','/api/attendance/employees'),dateField=field({k:'work_date',label:'تاريخ يوم العمل',type:'date'},day),shift=el('select',{'aria-label':'نمط الدوام'},[...cfg.shifts.map(s=>el('option',{value:s.id},s.name+' '+s.start+'–'+s.end)),el('option',{value:'flex'},'دوام مرن — مدير الأمن والمشرفون')]),site=el('input',{}),post=el('input',{}),list=el('div',{class:'roster-pick'}),selected=new Set();
  const draw=()=>{selected.clear();list.replaceChildren(...r.rows.filter(e=>(e.work_pattern==='flexible')===(shift.value==='flex')).map(e=>{const cb=el('input',{type:'checkbox',onchange:x=>x.target.checked?selected.add(e.id):selected.delete(e.id)});return el('label',{},cb,e.name+' — '+(e.job_title||'')+' — '+(e.work_pattern==='flexible'?'دوام مرن':e.job_group==='relief'?'بديل راحات':'أساسي'));}));};shift.onchange=draw;draw();
  const m=modal('توزيع الموظفين على الوردية',dateField,el('label',{},'الوردية / الدوام المرن'),shift,el('p',{class:'muted'},'الثالثة تبدأ بعد منتصف الليل في اليوم التالي وتُحسب ضمن يوم العمل المختار. مدير الأمن والمشرفون دوام مرن خارج أعداد 11 + 11 + 10.'),el('label',{},'الموقع (اتركه لاستخدام موقع الموظف)'),site,el('label',{},'النقطة / المهمة'),post,list,el('button',{class:'btn primary',onclick:guarded(async()=>{const inp=dateField.querySelector('[data-k]');if(inp.dataset.dateInvalid)throw new Error('صحّح التاريخ');await api('POST','/api/attendance/plan',{work_date:inp.value,shift_id:shift.value,employee_ids:[...selected],site:site.value,post:post.value});m.close();reload();})},'حفظ التوزيع'));
}
function editAttendance(r){
  const fields=[{k:'state',label:'حالة الموظف',type:'select',options:[['duty','عمل'],['absent','غياب'],['excused','غياب بعذر'],['leave','إجازة'],['rest','راحة']]},{k:'check_in',label:'الحضور الفعلي بتوقيت مكة',type:'datetime-local'},{k:'check_out',label:'الانصراف الفعلي بتوقيت مكة',type:'datetime-local'},{k:'notes',label:'الملاحظات / سبب الغياب أو الاستبدال',type:'textarea'}];
  formModal('تسجيل الحضور والانصراف — '+r.name,fields,{...r,check_in:r.check_in?.slice(0,16)||'',check_out:r.check_out?.slice(0,16)||''},async v=>{await api('PUT','/api/attendance/'+r.id,{...v,version:r.version});reload();});
}
function attendancePeriodControls(params,businessDate=today){
  const d=(params.date||today).split('-').map(Number),period=el('select',{'aria-label':'نوع الفترة'},[['day','يومي'],['month','شهري'],['year','سنوي']].map(([k,t])=>el('option',{value:k,selected:k===(params.period||'day')},t))),year=el('input',{type:'number',value:d[0],min:1900,max:2100,'aria-label':'السنة'}),month=el('select',{'aria-label':'الشهر'},Array.from({length:12},(_,i)=>el('option',{value:i+1,selected:i+1===d[1]},String(i+1)))),day=el('input',{type:'number',value:d[2],min:1,max:31,'aria-label':'اليوم'});
  const draw=()=>{day.disabled=period.value!=='day';month.disabled=period.value==='year';};period.onchange=draw;draw();
  return el('div',{class:'card row attendance-period'},el('label',{},'الفترة',period),el('label',{},'السنة',year),el('label',{},'الشهر',month),el('label',{},'اليوم',day),el('button',{class:'btn primary',onclick:()=>{const p={...params,date:String(year.value).padStart(4,'0')+'-'+String(period.value==='year'?1:month.value).padStart(2,'0')+'-'+String(period.value==='day'?day.value:1).padStart(2,'0'),period:period.value};delete p.id;delete p.metric;go('attendance',p);}},'عرض الفترة'),el('button',{class:'btn',onclick:()=>go('attendance',{date:businessDate,period:'day'})},'اليوم الحالي'));
}
VIEWS.attendance=async p=>{
  const activeDate=(await api('GET','/api/attendance/config')).business_date||today;
  const params={...p,date:p.date||activeDate,period:p.period||'day'},r=await api('GET','/api/attendance?'+qs(params)),cfg=r.config,root=el('div',{},el('h2',{},'الحضور والانصراف'));
  const controls=el('div',{class:'row card noprint'},can('attendance','edit')&&el('button',{class:'btn',onclick:()=>attendanceConfig(cfg)},'ضبط الورديات'),can('attendance','add')&&el('button',{class:'btn primary',disabled:!cfg.confirmed,onclick:()=>rosterPlan(cfg,params.date)},'توزيع الموظفين'),can('attendance','export')&&el('a',{class:'btn',href:'/api/attendance/export?'+qs(params)},'تصدير كشف الحضور'),can('attendance','print')&&el('button',{class:'btn',onclick:()=>window.print()},'طباعة'));
  root.append(controls,el('p',{class:'attendance-date'},'الفترة: '+r.period_start+' إلى '+r.period_end+' — بتوقيت مكة'),attendancePeriodControls(params,activeDate),filterBar([{k:'shift_id',label:'الوردية',type:'select',options:[['','الكل'],...cfg.shifts.map(s=>[s.id,s.name]),['flex','دوام مرن — مدير الأمن والمشرفون']]},{k:'state',label:'الحالة',type:'select',options:[['','الكل'],['duty','عمل'],['absent','غياب'],['excused','بعذر'],['leave','إجازة'],['rest','راحة']]},{k:'site',label:'الموقع'}],params,v=>go('attendance',{...v,date:params.date,period:params.period})));
  root.append(el('div',{class:'grid kpis'},['present','absent','late','pending','shortfall'].map(k=>el('a',{class:'kpi k-blue',href:'#/attendance?'+qs({...params,metric:k}), 'data-attendance-metric':k},el('div',{class:'t'},attendanceMetricNames[k]),el('div',{class:'n'},r.totals[k])))));
  root.append(donut('مؤشر الحضور للفترة',[['present','#0a8579'],['pending','#ffc22d'],['absent','#c8481f']].map(([k,color])=>({label:attendanceMetricNames[k],value:r.totals[k],color,href:'#/attendance?'+qs({...params,metric:k})})),''));
  root.append(el('div',{class:'card'},el('h3',{},'تنبيهات الحضور والانصراف'),r.alerts.length?el('ul',{},r.alerts.map(a=>el('li',{},el('a',{href:a.href},a.text)))):el('p',{},'لا توجد تنبيهات للفترة المختارة.')));
  root.append((!params.metric||params.metric==='shortfall')&&el('div',{class:'card'},el('h3',{},'تغطية أفراد الورديات — الدوام المرن مستقل'),table([{h:'اليوم',f:c=>ltr(c.work_date)},{h:'الوردية',f:c=>c.name},{h:'المطلوب',f:c=>c.required??'غير محدد للموقع'},{h:'المكلفون',f:c=>c.planned},{h:'المسجل حضورهم',f:c=>c.present},{h:'نقص الحضور المسجل',f:c=>c.started?c.shortfall:'لم تبدأ الوردية'}],r.coverage)),el('p',{class:'muted'},'الأعداد تخص تسجيل الحضور، وليست عدد الموجودين لحظيًا. يظهر نقص الحضور بعد بداية الوردية. مدير الأمن والمشرفون دوام مرن ولا يدخلون ضمن الـ32 فردًا؛ لا يحسب لهم تأخير أو انصراف مبكر وفق مواعيد الورديات.'));
  const action=r=>el('div',{class:'row'},!r.approved_at&&can('attendance','edit')&&el('button',{class:'btn sm',onclick:()=>editAttendance(r)},'تسجيل / تعديل'),!r.approved_at&&can('attendance','edit')&&el('button',{class:'btn sm',onclick:()=>confirmBox('اعتماد سجل '+r.name+'؟',async()=>{await api('POST','/api/attendance/'+r.id+'/approve',{version:r.version});reload();})},'اعتماد'),r.approved_at&&isOwner()&&el('button',{class:'btn sm',onclick:()=>formModal('إعادة فتح سجل',[{k:'reason',label:'سبب إعادة الفتح'}],{},async v=>{await api('POST','/api/attendance/'+r.id+'/reopen',v);reload();})},'إعادة فتح'),!r.approved_at&&can('attendance','delete')&&el('button',{class:'btn sm danger',onclick:()=>confirmBox('حذف التكليف غير المنفذ؟',async()=>{await api('DELETE','/api/attendance/'+r.id);reload();})},'حذف'));
  root.append(el('div',{class:'card'},params.metric&&el('p',{},'عرض: '+attendanceMetricNames[params.metric],el('a',{class:'btn sm',href:'#/attendance?'+qs({date:params.date,period:params.period})},'عرض جميع السجلات')),table([{h:'اليوم',f:x=>ltr(x.work_date)},{h:'الموظف',f:x=>x.name},{h:'الوردية',f:x=>x.shift_name},{h:'الموقع / النقطة',f:x=>x.site+' / '+x.post},{h:'بداية الوردية',f:x=>x.planned_start?ltr(localTime(x.planned_start)):'مرن'},{h:'نهاية الوردية',f:x=>x.planned_end?ltr(localTime(x.planned_end)):'مرن'},{h:'الحضور',f:x=>x.check_in?ltr(localTime(x.check_in)):'لم يسجل'},{h:'الانصراف',f:x=>x.check_out?ltr(localTime(x.check_out)):'لم يسجل'},{h:'الحالة',f:x=>x.status_label},{h:'التأخير بالدقائق',f:x=>x.late_minutes??'—'},{h:'الانصراف المبكر',f:x=>x.early_minutes??'—'},{h:'العمل بالدقائق',f:x=>x.worked_minutes??'—'},{h:'الاعتماد',f:x=>x.approved_at?'معتمد':'مسودة'},{h:'ملاحظات',f:x=>x.notes},{h:'الإجراءات',f:action}],r.rows)));
  return root;
};
// Poll central changes without interrupting typing or unsaved forms.
let sharedRevision=null,syncBusy=false,sharedAppearance=null,sharedPermissions=null,sharedUser=null;
setInterval(async()=>{
  if(!me||document.hidden||syncBusy||dashboardDragging||document.querySelector('.overlay')||['settings','import','updates'].includes(parseHash().path))return;
  if(document.activeElement?.matches('input,select,textarea'))return;
  syncBusy=true;
  try{
    const r=await api('GET','/api/revision'),s=await api('GET','/api/status');
    if(!s.user){me=null;boot();return;}
    const a=JSON.stringify(s.appearance),p=JSON.stringify(s.permissions),u=JSON.stringify(s.user);
    const changed=sharedRevision!==null&&(sharedRevision!==r.revision||sharedAppearance!==a||sharedPermissions!==p||sharedUser!==u||today!==s.today);
    sharedRevision=r.revision;sharedAppearance=a;sharedPermissions=p;sharedUser=u;
    if(changed){me=s.user;appearance=s.appearance;permissions=s.permissions;today=s.today;applyAppearance();renderShell();}
  }catch{}finally{syncBusy=false;}
},10000);
async function editTableColumns(key){
  if(!isOwner())return;
  const r=await api('GET','/api/settings/appearance');registerTableCatalog(r.table_catalog);
  const draft=structuredClone(r.appearance),columns=columnCatalog[key];if(!columns)return;
  draft.tables ||= {};const cfg=draft.tables[key]=normalizedTableColumns(key,columns,draft.tables),list=el('div',{});
  const draw=()=>list.replaceChildren(...cfg.map((c,i)=>el('div',{class:'setting-row','data-column-key':c.key},el('label',{class:'inline-check'},el('input',{type:'checkbox',checked:c.visible!==false,'aria-label':'إظهار '+(columns.find(x=>x.key===c.key)?.label||c.label),onchange:e=>c.visible=e.target.checked}),'إظهار'),el('input',{value:c.label,'aria-label':'اسم العمود '+c.key,oninput:e=>c.label=e.target.value}),el('button',{class:'btn sm',disabled:i===0,onclick:()=>{[cfg[i-1],cfg[i]]=[cfg[i],cfg[i-1]];draw();}},'أعلى'),el('button',{class:'btn sm',disabled:i===cfg.length-1,onclick:()=>{[cfg[i+1],cfg[i]]=[cfg[i],cfg[i+1]];draw();}},'أسفل'))));draw();
  const m=modal('تخصيص أعمدة — '+(tableCatalogLabels[key]||key),el('p',{class:'muted'},'اختر الأعمدة الظاهرة لهذا الجدول ثم احفظ.'),list,el('button',{class:'btn primary',onclick:guarded(async()=>{const saved=await api('PUT','/api/settings/appearance',draft);appearance=saved.appearance;applyAppearance();m.close();await reload();toast('تم حفظ الأعمدة');})},'حفظ الأعمدة'));
}

let dashboardDragging=false;
function addSectionPrintButton(path){
  if(!me||!['dashboard','contract','employees','vehicles','equipment','licenses','registers','claims','expiries'].includes(path)||!canCurrent('print'))return;
  const main=document.getElementById('main');if(!main||main.querySelector('.global-print-actions'))return;
  main.prepend(el('div',{class:'row noprint global-print-actions'},el('button',{class:'btn',onclick:()=>window.print()},'طباعة / حفظ PDF')));
}
function prepareUnifiedPrint(){
  const main=document.getElementById('main');if(!me||!main)return;
  document.querySelectorAll('.unified-print-head,.unified-print-footer').forEach(n=>n.remove());
  const heading=main.querySelector('#reportCard>h3')?.textContent||main.querySelector('h2')?.textContent||'';
  const head=el('div',{class:'unified-print-head'},el('img',{src:appearance.logos?.sidebar||'/static/img/ewan.png',alt:'شعار الشركة'}),el('div',{},el('strong',{},appearance.title||'نظام إدارة عقد الحراسات الأمنية'),heading&&el('div',{},heading)),el('img',{src:appearance.logos?.header||'/static/img/authority.png',alt:'شعار الهيئة'}));
  main.prepend(head);
  document.body.append(el('div',{class:'unified-print-footer'},'تاريخ ووقت الطباعة: '+localTime(new Date().toISOString())));
  document.body.classList.add('printing-section');
}
function finishUnifiedPrint(){document.querySelectorAll('.unified-print-head,.unified-print-footer').forEach(n=>n.remove());document.body.classList.remove('printing-section');}
window.addEventListener('beforeprint',prepareUnifiedPrint);window.addEventListener('afterprint',finishUnifiedPrint);
window.addEventListener('beforeunload',e=>{if(settingsDirty){e.preventDefault();e.returnValue='';}});
function warnUnsavedSettings(target){
  history.replaceState(null,'','#/settings');if(document.querySelector('[data-unsaved-settings]'))return;
  const m=modal('تغييرات غير محفوظة',el('p',{},'احفظ إعداداتك قبل الانتقال، أو اختر الانتقال بدون حفظ.'),el('div',{class:'row'},el('button',{class:'btn primary',onclick:guarded(async()=>{await settingsSaveHook();m.close();location.hash=target;})},'حفظ ثم انتقال'),el('button',{class:'btn',onclick:()=>{settingsDirty=false;m.close();location.hash=target;}},'انتقال بدون حفظ'),el('button',{class:'btn',onclick:()=>m.close()},'البقاء في الإعدادات')));m.el.dataset.unsavedSettings='1';
}
function ensureSectionLayout(draft,key){
  draft.section_cards ||= {};return draft.section_cards[key] ||= {label:businessSectionNames[key],color:draft.colors.blue,order:Object.keys(businessSectionNames).indexOf(key),align:'right',number_align:'right',visible:true,breakdown:true,indicators:true};
}
async function persistDashboardOrder(grid,kind,section,parent){
  const state=await api('GET','/api/settings/appearance'),draft=structuredClone(state.appearance);
  if(kind==='section'){
    const visible=[...grid.querySelectorAll(':scope > [data-section-card]')].map(n=>n.dataset.sectionCard),set=new Set(visible),all=Object.keys(businessSectionNames).sort((a,b)=>(draft.section_cards?.[a]?.order??Object.keys(businessSectionNames).indexOf(a))-(draft.section_cards?.[b]?.order??Object.keys(businessSectionNames).indexOf(b)));let i=0;
    all.map(k=>set.has(k)?visible[i++]:k).forEach((k,order)=>ensureSectionLayout(draft,k).order=order);
  }else ensureSectionLayout(draft,section)[kind==='indicator'?'indicator_order':'extra_order']=[...parent.children].filter(n=>kind==='indicator'?n.dataset.indicatorId:n.dataset.extraId).map(n=>kind==='indicator'?n.dataset.indicatorId:n.dataset.extraId);
  const saved=await api('PUT','/api/settings/appearance',draft);appearance=saved.appearance;applyAppearance();toast('تم حفظ الترتيب');
}
async function hideSectionIndicator(section,id){
  const r=await api('GET','/api/settings/appearance'),draft=structuredClone(r.appearance),c=ensureSectionLayout(draft,section);c.indicator_visibility ||= {};c.indicator_visibility[id]=false;
  const saved=await api('PUT','/api/settings/appearance',draft);appearance=saved.appearance;await reload();toast('تم إخفاء المؤشر');
}
function setupDashboardDrag(grid){
  if(!isOwner())return;
  grid.classList.add('pointer-sortable');let busy=false,blockClicksUntil=0;
  for(const card of grid.querySelectorAll(':scope > [data-section-card]')){
    for(const chart of card.querySelectorAll('[data-indicator-id]'))chart.prepend(el('button',{class:'indicator-visibility-button noprint','data-indicator-hide':chart.dataset.indicatorId,type:'button','aria-label':'إخفاء '+(chart.querySelector('h3')?.textContent||'المؤشر'),title:'إخفاء المؤشر',onclick:guarded(async e=>{e.preventDefault();e.stopPropagation();await hideSectionIndicator(card.dataset.sectionCard,chart.dataset.indicatorId);})},'×'));
  }
  grid.addEventListener('dragstart',e=>e.preventDefault());
  grid.addEventListener('click',e=>{if(Date.now()<blockClicksUntil){e.preventDefault();e.stopPropagation();}},true);
  grid.addEventListener('pointerdown',e=>{
    if(busy||e.button!==0||(e.pointerType&&e.pointerType!=='mouse')||e.target.closest('button,input,select,textarea'))return;
    const card=e.target.closest('[data-section-card]');if(!card)return;
    const extra=e.target.closest('[data-extra-id]'),chart=e.target.closest('[data-indicator-id]'),header=e.target.closest('.section-summary');
    const node=extra||chart||(header?card:null);if(!node)return;
    const kind=extra?'extra':chart?'indicator':'section',section=card.dataset.sectionCard,pointer=e.pointerId;let started=false,ghost=null,hover=null,latest=e;
    const sx=e.clientX,sy=e.clientY;
    const findTarget=event=>{
      const hit=document.elementFromPoint(event.clientX,event.clientY),candidate=hit?.closest(kind==='section'?'[data-section-card]':kind==='indicator'?'[data-indicator-id]':'[data-extra-id]');
      return candidate&&candidate!==node&&grid.contains(candidate)&&(kind==='section'||candidate.closest('[data-section-card]')===card)&&candidate.parentElement===node.parentElement?candidate:null;
    };
    const move=event=>{
      if(event.pointerId!==pointer)return;latest=event;
      if(!started&&Math.hypot(event.clientX-sx,event.clientY-sy)<7)return;
      event.preventDefault();
      if(!started){started=true;dashboardDragging=true;node.classList.add('pointer-dragging');grid.classList.add('pointer-active');try{node.setPointerCapture?.(pointer);}catch{}
        ghost=node.cloneNode(true);ghost.classList.add('pointer-ghost');ghost.classList.remove('pointer-dragging');ghost.style.width=Math.min(node.getBoundingClientRect().width||360,420)+'px';document.body.append(ghost);
      }
      ghost.style.left=Math.max(5,Math.min(event.clientX+12,window.innerWidth-430))+'px';ghost.style.top=Math.max(5,event.clientY+12)+'px';
      hover?.classList.remove('drag-over');hover=findTarget(event);hover?.classList.add('drag-over');
      if(event.clientY<45)window.scrollBy(0,-20);else if(event.clientY>window.innerHeight-45)window.scrollBy(0,20);
    };
    const clean=()=>{document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',up);document.removeEventListener('pointercancel',cancel);ghost?.remove();hover?.classList.remove('drag-over');node.classList.remove('pointer-dragging');grid.classList.remove('pointer-active');dashboardDragging=false;try{if(node.hasPointerCapture?.(pointer))node.releasePointerCapture(pointer);}catch{}};
    const cancel=()=>{if(started)blockClicksUntil=Date.now()+400;clean();};
    const up=event=>{
      if(event.pointerId!==pointer)return;
      if(!started){clean();return;}
      event.preventDefault();blockClicksUntil=Date.now()+400;const target=findTarget(event)||hover,rect=target?.getBoundingClientRect(),after=rect&&event.clientY>rect.top+rect.height/2;clean();
      if(!target||!node.isConnected||!target.isConnected)return;
      const parent=target.parentElement;parent.insertBefore(node,after?target.nextSibling:target);busy=true;
      guarded(async()=>{try{await persistDashboardOrder(grid,kind,section,parent);}catch(error){await reload();throw error;}finally{busy=false;}})();
    };
    document.addEventListener('pointermove',move,{passive:false});document.addEventListener('pointerup',up);document.addEventListener('pointercancel',cancel);
  });
}

