'use strict';
/* Presentation only: existing field names, table identities and permission matrix stay intact. */
async function recordPhotoMap(kind,section){
  const r=await api('GET','/api/record-photos?'+qs({owner_type:kind,section}));
  return new Map(r.rows.map(x=>[x.owner_id,x.url]));
}
let recordPrintBusy=false;
async function printRecordPhotos(section,pages){
  if(!can(section,'print'))throw new Error('لا تملك صلاحية الطباعة لهذا القسم.');
  if(recordPrintBusy)throw new Error('توجد عملية طباعة قيد التجهيز.');
  if(!pages.length)throw new Error('لا توجد صور محفوظة للطباعة.');
  for(const page of pages){const u=new URL(page.url,location.href);if(u.origin!==location.origin||!/^\/api\/(record-photos\/|vehicle-monthly\/records\/)/.test(u.pathname))throw new Error('رابط الصورة غير صالح.');}
  const area=el('div',{class:'record-print-area','aria-hidden':'true'},pages.map(page=>el('section',{class:'record-print-page'},el('h2',{},page.title||'صورة السجل'),page.subtitle&&el('p',{},page.subtitle),el('img',{src:page.url,alt:page.title||'صورة السجل'}))));
  return printIsolatedContent(section,area);
}
async function printIsolatedContent(section,area){
  if(!can(section,'print'))throw new Error('لا تملك صلاحية الطباعة لهذا القسم.');
  if(recordPrintBusy)throw new Error('توجد عملية طباعة قيد التجهيز.');
  recordPrintBusy=true;
  let fallback;
  const cleanup=()=>{clearTimeout(fallback);window.removeEventListener('afterprint',cleanup);area.remove();document.body.classList.remove('printing-record-photos');recordPrintBusy=false;};
  document.body.append(area);
  try{
    toast('جارٍ تجهيز الصور للطباعة…');
    await Promise.all([...area.querySelectorAll('img')].map(image=>new Promise((resolve,reject)=>{
      let timer;const done=ok=>{clearTimeout(timer);image.onload=image.onerror=null;ok?resolve():reject(new Error('تعذر تحميل إحدى الصور. أعد المحاولة؛ لم تتم طباعة صور ناقصة.'));};
      image.onload=()=>done(image.naturalWidth>0);image.onerror=()=>done(false);timer=setTimeout(()=>done(false),30000);
      if(image.complete)done(image.naturalWidth>0);
    })));
    if(!can(section,'print'))throw new Error('لم تعد صلاحية الطباعة متاحة لهذا القسم.');
    document.body.classList.add('printing-record-photos');
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    window.addEventListener('afterprint',cleanup);
    fallback=setTimeout(cleanup,10*60*1000);
    window.print();
  }catch(e){cleanup();throw e;}
}
function showRecordPhoto(url,title='صورة السجل',section=parseHash().path,subtitle){
  return modal(title,el('div',{},can(section,'print')&&el('button',{class:'btn noprint',type:'button',onclick:guarded(()=>printRecordPhotos(section,[{url,title,subtitle}]))},'طباعة الصورة فقط'),el('img',{class:'record-photo-large',src:url,alt:title})));
}
function recordLabel(label,url,options={}){
  return el('span',{class:'record-label'},url&&el('button',{type:'button',class:'record-thumb-button','aria-label':'تكبير صورة السجل',onclick:e=>{e.stopPropagation();showRecordPhoto(url,options.title||label||'صورة السجل',options.section||parseHash().path);}},el('img',{class:'record-thumb',src:url,alt:options.title||'صورة السجل',loading:'lazy'})),el('span',{},label));
}
function recordPhotoPanel(kind,id,initialUrl,name,section){
  const currentSection=['vehicle','driver'].includes(kind)?'vehicles':section||parseHash().path;
  const frame=el('div',{class:'record-photo-frame'}),status=el('p',{class:'muted record-photo-status','aria-live':'polite'});
  const box=el('section',{class:'record-photo-panel'},el('h3',{},kind==='driver'?'صورة الرخصة':'صورة السجل'),frame,status);
  let url=initialUrl,busy=false;
  const upload=el('input',{type:'file',accept:'image/png,image/jpeg,image/webp','aria-label':kind==='driver'?'اختيار صورة الرخصة':'اختيار صورة السجل'});
  const remove=el('button',{class:'btn sm danger',type:'button',onclick:()=>confirmBox('حذف صورة السجل فقط؟',async()=>{
    if(busy)return;busy=true;remove.disabled=true;
    try{await api('DELETE',`/api/record-photos/${kind}/${id}`);url=null;draw();toast('تم حذف الصورة');}finally{busy=false;remove.disabled=false;}
  })},'حذف الصورة');
  function draw(){
    frame.replaceChildren(url?el('button',{type:'button',class:'record-photo-zoom','aria-label':'تكبير صورة '+name,onclick:()=>showRecordPhoto(url,name,currentSection)},el('img',{src:url,alt:name})):
      el('div',{class:'record-photo-empty'},typeof exIcon==='function'?exIcon(kind==='vehicle'?'vehicles':kind==='driver'?'licenses':'equipment'):null,el('span',{},kind==='driver'?'يمكنك إضافة صورة رخصة السائق':'يمكنك إضافة صورة السجل')));
    remove.hidden=!url;
  }
  upload.addEventListener('change',guarded(async()=>{
    const f=upload.files[0];if(!f||busy)return;
    if(f.size>8*1024*1024){upload.value='';throw new Error('حجم الصورة لا يتجاوز 8 ميجابايت');}
    const form=new FormData();form.append('file',f);busy=true;upload.disabled=true;remove.disabled=true;status.textContent='جارٍ حفظ الصورة…';
    try{const r=await api('POST',`/api/record-photos/${kind}/${id}`,undefined,form);url=r.url;draw();status.textContent='تم حفظ الصورة';toast('تم حفظ الصورة');}
    catch(e){status.textContent='لم تُحفظ الصورة';throw e;}
    finally{busy=false;upload.disabled=false;remove.disabled=false;upload.value='';}
  }));
  if(can(currentSection,'edit'))box.append(el('label',{class:'record-photo-upload'},'اختيار / تغيير الصورة',upload),el('small',{class:'muted'},'PNG، JPEG، WebP — حتى 8 ميجابايت. تُحفظ الصورة مباشرة.'));
  if(can(currentSection,'delete'))box.append(remove);
  draw();return box;
}
function recordEditForm(kind,id,title,fields,values,onSave){
  const m=formModal(title,fields,values,onSave),form=m.el.querySelector('.record-fields');
  m.el.classList.add('record-editor');
  const summary=el('aside',{class:'record-summary'},el('h3',{},kind==='vehicle'?'ملخص السيارة':kind==='driver'?'بيانات السائق':'بيانات البند'));
  const layout=el('div',{class:'record-editor-layout'});form.before(layout);layout.append(form,summary);
  const content=el('div',{class:'record-summary-values'});summary.append(content);
  const update=()=>{
    const chosen=fields.filter(f=>kind==='vehicle'?['plate','model','year','driver_id'].includes(f.k):kind==='driver'?['name','license_no','phone'].includes(f.k):['name','required_qty','available_qty','op_status'].includes(f.k));
    content.replaceChildren(...chosen.map(f=>{const input=form.querySelector('[data-k="'+f.k+'"]');return el('div',{},el('span',{class:'muted'},f.label),el('b',{},f.type==='select'?input.selectedOptions[0]?.textContent||'—':input.value||'—'));}));
  };
  form.addEventListener('input',update);form.addEventListener('change',update);update();
  const host=el('div',{});summary.prepend(host);
  const sec=['vehicle','driver'].includes(kind)?undefined:values.section||parseHash().path;
  recordPhotoMap(kind,sec).then(photos=>{if(m.el.isConnected)host.replaceChildren(recordPhotoPanel(kind,id,photos.get(id),values.model||values.name||title,sec));}).catch(e=>{if(m.el.isConnected)host.replaceChildren(el('p',{class:'note'},e.message));});
  if(['vehicle','driver'].includes(kind))layout.append(recordDatesEditor(kind,id));
  if(kind==='vehicle')layout.append(el('button',{class:'btn noprint',type:'button',onclick:guarded(()=>vehicleMonthlyWindow({id,plate:values.plate}))},'صور التحديث الشهري والأرشيف'));
  return m;
}

function expiryValidity(status,days){return badge(status==='expired'?'منتهية':status==='today'?'تنتهي اليوم':status==='soon'?'تنتهي قريبًا':status==='unrecorded'||!status?'غير مسجل':'سارية',days!=null&&days<=20?'bad':days!=null&&days<=30?'warn':status==='unrecorded'||!status?'mute':'ok');}
function licensePriority(a,b){
  const rank=x=>{const d=expiryDays(x.expiry_date);return d==null?2:d<=0?0:d<=30?1:3;};
  return rank(a)-rank(b)||(expiryDays(a.expiry_date)??Infinity)-(expiryDays(b.expiry_date)??Infinity)||(a.seq??a.id)-(b.seq??b.id);
}
function employeeFileLink(employee){
  let url;try{url=new URL(employee.employee_file_url);if(url.protocol!=='https:'||!['drive.google.com','docs.google.com'].includes(url.hostname))return el('span',{class:'muted'},'لا يوجد ملف Drive');}catch{return el('span',{class:'muted'},'لا يوجد ملف Drive');}
  return el('a',{href:url.href,target:'_blank',rel:'noopener noreferrer',onclick:e=>e.stopPropagation()},'ملف الموظف');
}
async function printEmployeeDetail(id){
  if(!can('employees','print'))throw new Error('لا تملك صلاحية طباعة بيانات الكادر.');
  const r=await api('GET','/api/employees/'+id),e=r.employee;
  const plainTable=(heads,rows)=>el('table',{},el('thead',{},el('tr',{},heads.map(t=>el('th',{},displayLabel(t))))),el('tbody',{},rows.map(row=>el('tr',{},row.map(v=>el('td',{},v??'—'))))));
  const sheet=el('article',{class:'employee-print-sheet'},el('div',{class:'employee-print-logos'},el('img',{src:appearance.logos?.sidebar||'/static/img/ewan.png',alt:'الشركة'}),el('h2',{},'بيانات الموظف — '+e.name),el('img',{src:appearance.logos?.header||'/static/img/authority.png',alt:'الهيئة'})),
    plainTable(['البند','البيانات'],[['الاسم',e.name],['الهوية',e.id_hidden?'محجوبة حسب الصلاحية':e.national_id],['الوظيفة',e.job_title],['الفئة',L.grp[e.job_group]],['مراجعة الاستشاري',L.res[e.consultant_result||'unrecorded']],['اعتماد الجهة',L.auth[e.authority_status||'unrecorded']],['الجوال',e.phone],['الموقع',e.site],['الوردية',e.shift],['تاريخ المباشرة',e.start_date],['ملاحظات',e.notes]]),
    el('h3',{},'الاشتراطات'),plainTable(['الاشتراط','حالة المطابقة','السبب'],r.checks.map(c=>[displayLabel(c.label),badge(c.norm_ar,c.norm==='conforming'?'ok':c.norm==='nonconforming'?'bad':'warn'),c.reason])),
    el('h3',{},'الوثائق وتواريخ الانتهاء'),plainTable(['الوثيقة','الانتهاء','المدة المتبقية','الحالة'],r.tracked.map(t=>[t.title,t.expiry_date,remaining(t.days_left),expiryValidity(t.status,t.days_left)])),
    el('h3',{},'المرفقات'),plainTable(['الوصف','الملف'],r.documents.map(d=>[d.label||'ملف الموظف',d.url?el('a',{href:d.url},'فتح الملف'):d.kind==='local'?'نسخة محلية':'غير مسجل'])),
    el('p',{class:'employee-print-time'},'تاريخ ووقت الطباعة: '+localTime(new Date().toISOString())));
  return printIsolatedContent('employees',el('div',{class:'record-print-area','aria-hidden':'true'},sheet));
}
const tableInteractionState=new Map();
function wireTableFilters(host,cols,records,key){
  const t=host.querySelector('table'),body=t?.tBodies[0];if(!body)return;
  const stateKey=String(me?.id||'anonymous')+':'+key;
  let saved=[];try{saved=JSON.parse(localStorage.getItem('ewan-row-order:'+stateKey)||'[]');if(!Array.isArray(saved))saved=[];}catch{}
  const state=tableInteractionState.get(stateKey)||{filters:{},sort:null,manual:false,order:saved};tableInteractionState.set(stateKey,state);
  const ids=records.map((r,i)=>String(r.id??r.key??i)),nodes=[...body.rows];
  const entries=records.map((r,i)=>({r,id:ids[i],node:nodes[i],values:cols.map((c,j)=>nodes[i].cells[j].textContent.trim())}));
  const value=(entry,j)=>{const c=cols[j],h=c.h||'';if(c.key==='remaining'||h.includes('المدة المتبقية')){const tracked=(entry.r.tracked||[]).map(t=>expiryDays(t.expiry_date)).filter(n=>n!=null);const n=entry.r.days_left??expiryDays(entry.r.expiry_date??entry.r.id_expiry)??(tracked.length?Math.min(...tracked):null);return n==null?Infinity:n;}return entry.values[j];};
  const compare=(a,b)=>{if(typeof a==='number'&&typeof b==='number')return a-b;return String(a).localeCompare(String(b),'ar',{numeric:true});};
  const ordered=()=>{let out=entries.filter(e=>Object.entries(state.filters).every(([columnKey,f])=>{const j=cols.findIndex(c=>c.key===columnKey);if(j<0)return true;const v=e.values[j];return(!f.text||v.toLocaleLowerCase().includes(f.text.toLocaleLowerCase()))&&(!f.value||v===f.value);}));if(state.sort){const j=cols.findIndex(c=>c.key===state.sort.key);if(j>=0)out.sort((a,b)=>state.sort.direction*compare(value(a,j),value(b,j)));}else if(state.order.length){const ranks=new Map(state.order.map((id,i)=>[id,i]));out.sort((a,b)=>(ranks.get(a.id)??1e9)-(ranks.get(b.id)??1e9));}return out;};
  const draw=()=>{const out=ordered();body.replaceChildren(...out.map(e=>e.node));for(const [index,e] of out.entries()){const tools=e.node.querySelector('.manual-row-tools');if(tools){tools.hidden=!state.manual;tools.querySelectorAll('button')[0].disabled=index===0;tools.querySelectorAll('button')[1].disabled=index===out.length-1;}}host.querySelector('.manual-row-head').hidden=!state.manual;};
  [...t.tHead.rows[0].cells].forEach((th,j)=>{
    const col=cols[j],header=el('span',{class:'column-title'},col.h),menu=el('details',{class:'table-menu noprint'}),f=state.filters[col.key]||{text:'',value:''};state.filters[col.key]=f;
    const search=el('input',{type:'search',value:f.text,placeholder:'بحث داخل العمود','aria-label':'بحث '+col.h,oninput:e=>{f.text=e.target.value;draw();}}),pick=el('select',{'aria-label':'تصفية '+col.h,onchange:e=>{f.value=e.target.value;draw();}},el('option',{value:''},'الكل'),[...new Set(entries.map(e=>e.values[j]))].filter(Boolean).sort((a,b)=>compare(a,b)).map(v=>el('option',{value:v,selected:f.value===v},v)));
    menu.ontoggle=()=>{if(menu.open){const rect=th.getBoundingClientRect(),box=menu.querySelector('.table-menu-body');box.style.top=Math.min(rect.bottom+2,Math.max(12,innerHeight-280))+'px';box.style.left=Math.max(8,Math.min(rect.left,innerWidth-270))+'px';host.querySelectorAll('.table-menu[open]').forEach(other=>{if(other!==menu)other.open=false;});}};
    menu.append(el('summary',{'aria-label':'فرز وتصفية '+col.h},'▾'),el('div',{class:'table-menu-body'},el('button',{class:'btn sm',onclick:()=>{state.sort={key:col.key,direction:1};draw();menu.open=false;}},'ترتيب تصاعدي'),el('button',{class:'btn sm',onclick:()=>{state.sort={key:col.key,direction:-1};draw();menu.open=false;}},'ترتيب تنازلي'),search,pick,el('button',{class:'btn sm',onclick:()=>{f.text=f.value='';search.value=pick.value='';draw();}},'مسح تصفية العمود')));th.replaceChildren(header,menu);
  });
  t.tHead.rows[0].append(el('th',{class:'manual-row-head noprint',hidden:!state.manual},'ترتيب يدوي'));
  entries.forEach(entry=>entry.node.append(el('td',{class:'manual-row-tools noprint',hidden:!state.manual},[-1,1].map(direction=>el('button',{class:'btn sm',type:'button',onclick:e=>{e.stopPropagation();const out=ordered(),i=out.indexOf(entry),target=out[i+direction];if(!target)return;const all=[...body.rows].map(n=>entries.find(e=>e.node===n));[all[i],all[i+direction]]=[all[i+direction],all[i]];state.order=[...all.map(e=>e.id),...entries.filter(e=>!all.includes(e)).map(e=>e.id)];state.sort=null;try{localStorage.setItem('ewan-row-order:'+stateKey,JSON.stringify(state.order));}catch{}draw();}},direction<0?'↑':'↓')))));
  host.prepend(el('div',{class:'row table-interactions noprint'},el('button',{class:'btn sm',onclick:()=>{state.manual=!state.manual;if(state.manual)state.sort=null;draw();}},'ترتيب يدوي للصفوف'),el('button',{class:'btn sm',onclick:()=>{state.sort=null;state.order=[];for(const f of Object.values(state.filters))f.text=f.value='';host.querySelectorAll('.table-menu input,.table-menu select').forEach(x=>x.value='');try{localStorage.removeItem('ewan-row-order:'+stateKey);}catch{}draw();}},'استعادة ترتيب القسم ومسح الفلاتر'),el('small',{class:'muted'},'الترتيب اليدوي محفوظ على هذا المتصفح؛ الفرز والتصفية تخص السجلات المعروضة.')));
  draw();
}
