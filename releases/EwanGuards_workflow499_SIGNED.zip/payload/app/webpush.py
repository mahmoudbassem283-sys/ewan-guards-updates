"""Opt-in per-device Web Push; live section permissions; no external SDK.

RFC 8030/8291/8292. Private keys and subscriptions stay in the backed-up DB.
Push payloads contain counts only; detailed records require an authenticated API.
"""
import contextlib
import base64, hashlib, hmac, http.client, ipaddress, json, os, re, secrets, socket, ssl, struct, threading, time
from urllib.parse import urlsplit
from flask import g, jsonify, request, send_from_directory
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from . import db
from .customize import can, owner_section
from .dates import today_riyadh

NAME='نظام إدارة عقد الحراسات الأمنية'
SCHEMA='''CREATE TABLE IF NOT EXISTS push_config(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS push_devices(endpoint TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 device TEXT NOT NULL,p256dh TEXT NOT NULL,auth TEXT NOT NULL,origin TEXT NOT NULL,
 stamp TEXT NOT NULL DEFAULT '',last_sent REAL NOT NULL DEFAULT 0,retry_at REAL NOT NULL DEFAULT 0,
 failures INTEGER NOT NULL DEFAULT 0,last_checked REAL NOT NULL DEFAULT 0,last_status TEXT NOT NULL DEFAULT '',last_test REAL NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS push_user ON push_devices(user_id);
CREATE TABLE IF NOT EXISTS push_lease(id INTEGER PRIMARY KEY CHECK(id=1),owner TEXT NOT NULL,until REAL NOT NULL);'''
LOCK=threading.Lock();RUNNING=set()

def b64(b):return base64.urlsafe_b64encode(b).rstrip(b'=').decode()
def unb64(s):return base64.urlsafe_b64decode(s+'='*(-len(s)%4))
def compact(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def pub(k):return k.public_key().public_bytes(serialization.Encoding.X962,serialization.PublicFormat.UncompressedPoint)
def init(c):c.executescript(SCHEMA);c.commit()
def key(c):
    row=c.execute("SELECT value FROM push_config WHERE key='vapid'").fetchone()
    if not row:
        k=ec.generate_private_key(ec.SECP256R1())
        pem=k.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()).decode()
        c.execute("INSERT OR IGNORE INTO push_config VALUES('vapid',?)",(pem,));c.commit()
        row=c.execute("SELECT value FROM push_config WHERE key='vapid'").fetchone()
    return serialization.load_pem_private_key(row[0].encode(),None)

def endpoint_url(endpoint):
    if not isinstance(endpoint,str) or not 1<=len(endpoint)<=4096 or any(ord(c)<33 or ord(c)>126 for c in endpoint):raise ValueError('عنوان اشتراك غير صالح')
    u=urlsplit(endpoint);host=u.hostname or ''
    allowed=host in ('fcm.googleapis.com','updates.push.services.mozilla.com','push.services.mozilla.com','web.push.apple.com') or host.endswith('.push.services.mozilla.com') or host.endswith('.notify.windows.com') or host.endswith('.push.apple.com')
    if not allowed or u.scheme!='https' or u.port not in (None,443) or u.username or u.password or u.fragment or not u.path:raise ValueError('خدمة إشعارات غير مدعومة')
    return u

def encryption(raw,receiver,auth):
    ua=unb64(receiver);secret=unb64(auth)
    if len(ua)!=65 or ua[0]!=4 or len(secret)!=16:raise ValueError('مفاتيح الاشتراك غير صالحة')
    peer=ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(),ua)
    k=ec.generate_private_key(ec.SECP256R1());as_pub=pub(k);salt=os.urandom(16)
    extract=lambda salt,ikm:hmac.new(salt,ikm,hashlib.sha256).digest()
    expand=lambda prk,info,n:hmac.new(prk,info+b'\x01',hashlib.sha256).digest()[:n]
    ikm=expand(extract(secret,k.exchange(ec.ECDH(),peer)),b'WebPush: info\0'+ua+as_pub,32)
    prk=extract(salt,ikm)
    cek=expand(prk,b'Content-Encoding: aes128gcm\0',16);nonce=expand(prk,b'Content-Encoding: nonce\0',12)
    if len(raw)>3000:raise ValueError('ملخص الإشعار أكبر من المسموح')
    return salt+struct.pack('!I',4096)+bytes([65])+as_pub+AESGCM(cek).encrypt(nonce,raw+b'\x02',None)

def vapid(k,audience,subject,now):
    token=b64(compact({'typ':'JWT','alg':'ES256'}))+'.'+b64(compact({'aud':audience,'exp':int(now)+3600,'sub':subject}))
    r,s=decode_dss_signature(k.sign(token.encode(),ec.ECDSA(hashes.SHA256())))
    return 'vapid t='+token+'.'+b64(r.to_bytes(32,'big')+s.to_bytes(32,'big'))+', k='+b64(pub(k))

def deliver(k,row,payload,now=None):
    now=now or time.time();u=endpoint_url(row['endpoint'])
    addresses=list(dict.fromkeys(x[4][0] for x in socket.getaddrinfo(u.hostname,443,type=socket.SOCK_STREAM)))
    if not addresses or any(not ipaddress.ip_address(a).is_global for a in addresses):raise ValueError('عنوان خدمة غير عام')
    body=encryption(compact(payload),row['p256dh'],row['auth'])
    connection=http.client.HTTPSConnection(u.hostname,443,timeout=12,context=ssl.create_default_context())
    connection._create_connection=lambda _,timeout=12,source_address=None:socket.create_connection((addresses[0],443),timeout,source_address)
    try:
        connection.request('POST',u.path+('?' +u.query if u.query else ''),body=body,headers={
            'Authorization':vapid(k,'https://'+u.netloc,row['origin'],now),
            'Content-Encoding':'aes128gcm','Content-Type':'application/octet-stream',
            'TTL':'300','Urgency':'normal','Topic':'ewan-alerts','User-Agent':'EwanGuardsPush/1'})
        response=connection.getresponse();retry=response.getheader('Retry-After','');response.read(4096)
        return response.status,min(86400,int(retry)) if retry.isdigit() else 0
    finally:connection.close()

def alerts(c,user):
    from .reports import tracked_rows,incomplete_rows
    from .api import employee_check_attention
    from .attendance import summary
    # The caller binds a fresh user and DB in a request context for shared ACL helpers.
    out=[]
    for r in tracked_rows(c):
        if r['status'] in ('expired','today','soon') and can(owner_section(r['owner_type'],r['owner_id']),u=user):
            out.append(dict(id='doc:'+str(r['id']),status=r['status'],name=r['owner_label'],title=r['title'],date=r['expiry_date'] or '',days_left=r['days_left'],stage='urgent20' if r['days_left'] is not None and r['days_left']<=20 else 'early30',section=owner_section(r['owner_type'],r['owner_id'])))
    for r in incomplete_rows(c):
        section=owner_section(r['owner_type'],r['owner_id'])
        if can(section,u=user):out.append(dict(id='incomplete:'+str(r['id']),status='incomplete',name=r['owner_label'],title=r['title'],date='',section=section))
    for typ,table,section in [('employee','employees','employees'),('item','items',None)]:
        for r in c.execute("SELECT * FROM "+table+" WHERE consultant_result='nonconforming'"):
            sec=section or r['section']
            if can(sec,u=user):out.append(dict(id='nonconforming:'+typ+':'+str(r['id']),status='nonconforming',name=r['name'],title='نتيجة المطابقة',date='',section=sec))
    if can('employees',u=user):
        for r in employee_check_attention():out.append(dict(id='check:'+str(r['employee_id'])+':'+r['check_key'],status='nonconforming',name=r['name'],title=r['label'],date='',section='employees'))
    if can('attendance',u=user):
        for i,r in enumerate(summary({})['alerts']):out.append(dict(id='attendance:'+str(i),status='attendance',name='الحضور والانصراف',title=r['text'],date='',section='attendance'))
    return out

def payload(rows):
    count=lambda *states:sum(r['status'] in states for r in rows)
    parts=[]
    for n,t in [(count('expired','today'),'منتهية/اليوم'),(count('soon'),'تنتهي قريبًا'),(count('incomplete'),'غير مكتمل'),(count('nonconforming'),'غير مطابق'),(count('attendance'),'تنبيهات حضور')]:
        if n:parts.append(str(n)+' '+t)
    early=sum(r.get('status')=='soon' and r.get('stage')=='early30' for r in rows)
    urgent=sum(r.get('status')=='soon' and r.get('stage')=='urgent20' for r in rows)
    if early:parts.append(str(early)+' متبقي 21–30 يومًا')
    if urgent:parts.append(str(urgent)+' متبقي 20 يومًا أو أقل')
    return {'title':NAME,'body':' · '.join(parts)+'\nاضغط لعرض التفاصيل حسب صلاحياتك.','url':'/#/notifications','icon':'/static/img/ewan.png'}

def update_result(c,row,status,retry,stamp,now):
    if status in (404,410):
        c.execute('DELETE FROM push_devices WHERE endpoint=? AND user_id=? AND device=?',(row['endpoint'],row['user_id'],row['device']))
    elif 200<=status<300:
        c.execute("UPDATE push_devices SET stamp=?,last_sent=?,retry_at=0,failures=0,last_status='accepted' WHERE endpoint=? AND user_id=? AND device=?",(stamp,now,row['endpoint'],row['user_id'],row['device']))
    else:
        failures=min(row['failures']+1,10);delay=max(retry,21600 if status in (400,401,403) else min(3600,900*2**min(failures-1,2)))
        c.execute("UPDATE push_devices SET failures=?,retry_at=?,last_status=? WHERE endpoint=? AND user_id=? AND device=?",(failures,now+delay,'blocked' if status in (400,401,403) else 'retrying',row['endpoint'],row['user_id'],row['device']))
    c.commit()

@contextlib.contextmanager
def acl_context(app,c,user):
    with app.test_request_context('/api/push/alerts'):
        g.db=c;g.user=dict(user)
        try:yield
        finally:g.pop('db',None)  # The caller owns this connection across recipients.


def tick(app,now=None):
    from update_engine import active
    if active(app.config['DATA_DIR']):return
    now=now or time.time();owner=secrets.token_hex(16);c=db.connect(app.config['DB_PATH'])
    try:
        c.execute('INSERT INTO push_lease VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET owner=excluded.owner,until=excluded.until WHERE push_lease.until<?',(owner,now+600,now))
        c.commit()
        if c.execute('SELECT owner FROM push_lease WHERE id=1').fetchone()[0]!=owner:return
        k=None
        rows=[dict(r) for r in c.execute('SELECT * FROM push_devices WHERE retry_at<=? ORDER BY last_checked LIMIT 20',(now,))]
        for row in rows:
            c.execute('UPDATE push_devices SET last_checked=? WHERE endpoint=?',(now,row['endpoint']));c.execute('UPDATE push_lease SET until=? WHERE id=1 AND owner=?',(time.time()+600,owner));c.commit()
            if active(app.config['DATA_DIR']):break
            user=c.execute('SELECT * FROM users WHERE id=? AND active=1',(row['user_id'],)).fetchone()
            if not user:
                c.execute('DELETE FROM push_devices WHERE endpoint=?',(row['endpoint'],));c.commit();continue
            with acl_context(app,c,user):
                items=alerts(c,g.user)
                stamp=hashlib.sha256(compact([today_riyadh().isoformat(),items])).hexdigest()
                if not items:
                    c.execute("UPDATE push_devices SET stamp='' WHERE endpoint=?",(row['endpoint'],));c.commit();continue
                if row['stamp']==stamp or now-row['last_sent']<900:continue
                # Re-read binding and current permissions immediately before network send.
                current=c.execute('SELECT user_id,device FROM push_devices WHERE endpoint=?',(row['endpoint'],)).fetchone()
                if not current or current['user_id']!=row['user_id'] or current['device']!=row['device']:continue
                k=k or key(c)
                try:status,retry=deliver(k,row,payload(items),now)
                except Exception:status,retry=0,0  # Provider bodies/endpoints/keys are never logged.
                update_result(c,row,status,retry,stamp,now)
    finally:
        try:c.execute('DELETE FROM push_lease WHERE id=1 AND owner=?',(owner,));c.commit()
        finally:c.close()

def start_worker(app):
    path=app.config['DB_PATH']
    if app.config.get('PUSH_WORKER_ENABLED') is False:return
    with LOCK:
        if path in RUNNING:return
        RUNNING.add(path)
    def run():
        try:
            while True:
                time.sleep(60)
                if not os.path.isfile(path):return
                try:tick(app)
                except Exception:pass
        finally:
            with LOCK:RUNNING.discard(path)
    threading.Thread(target=run,name='EwanWebPush',daemon=True).start()

def register(app):
    c=db.connect(app.config['DB_PATH'])
    try:
        init(c);existing=c.execute('SELECT 1 FROM push_devices LIMIT 1').fetchone()
    finally:c.close()
    if existing:start_worker(app)

    @app.get('/ewan-push-sw.js')
    def sw():
        r=send_from_directory(app.static_folder+'/js','push-sw.js',mimetype='application/javascript')
        r.headers['Service-Worker-Allowed']='/';r.headers['Cache-Control']='no-cache';return r
    @app.get('/ewan-manifest.json')
    def manifest():
        return jsonify(id='/',name=NAME,short_name='نظام الحراسات',start_url='/',scope='/',display='standalone',lang='ar',dir='rtl',background_color='#f2f7fb',theme_color='#082f49')
    @app.route('/api/push/config',methods=['GET'])
    def config():
        if not g.user:return jsonify(error='يلزم تسجيل الدخول'),401
        return jsonify(public_key=b64(pub(key(g.db))),name=NAME)
    @app.get('/api/push/alerts')
    def details():
        if not g.user:return jsonify(error='يلزم تسجيل الدخول'),401
        rows=alerts(g.db,g.user)
        return jsonify(rows=rows,total=len(rows))
    @app.route('/api/push/device',methods=['POST','DELETE'])
    def device():
        if not g.user:return jsonify(error='يلزم تسجيل الدخول'),401
        b=request.get_json(silent=True) or {};token=b.get('device','')
        if not isinstance(token,str) or not re.fullmatch(r'[a-f0-9]{64}',token):return jsonify(error='معرّف الجهاز غير صالح'),400
        token=hashlib.sha256(token.encode()).hexdigest()
        if request.method=='DELETE':
            g.db.execute('DELETE FROM push_devices WHERE device=? AND user_id=?',(token,g.user['id']));g.db.commit();return jsonify(ok=True)
        sub=b.get('subscription',{})
        try:
            endpoint=sub['endpoint'];endpoint_url(endpoint);keys=sub['keys'];p=unb64(keys['p256dh']);a=unb64(keys['auth'])
            if len(p)!=65 or p[0]!=4 or len(a)!=16:raise ValueError()
            ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(),p)
        except (ValueError,KeyError,TypeError,AttributeError):return jsonify(error='اشتراك الإشعارات غير صالح'),400
        existing=g.db.execute('SELECT device FROM push_devices WHERE endpoint=?',(endpoint,)).fetchone()
        if existing and existing['device']!=token:return jsonify(error='الاشتراك مرتبط بجهاز آخر؛ أعد تفعيل إذن المتصفح'),409
        if not existing and g.db.execute('SELECT count(*) FROM push_devices WHERE user_id=?',(g.user['id'],)).fetchone()[0]>=10:return jsonify(error='وصل حسابك لحد عشرة أجهزة إشعارات'),400
        origin=app.config.get('SHARING_URL') or request.host_url.rstrip('/')
        if not origin.startswith('https://'):return jsonify(error='فعّل الإشعارات من رابط المشاركة HTTPS'),400
        g.db.execute('DELETE FROM push_devices WHERE device=? AND endpoint<>?',(token,endpoint))
        g.db.execute('''INSERT INTO push_devices(endpoint,user_id,device,p256dh,auth,origin) VALUES(?,?,?,?,?,?)
          ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id,device=excluded.device,p256dh=excluded.p256dh,auth=excluded.auth,origin=excluded.origin,stamp='',retry_at=0,failures=0,last_status='' ''',(endpoint,g.user['id'],token,keys['p256dh'],keys['auth'],origin))
        g.db.commit();start_worker(app);return jsonify(ok=True)
    @app.post('/api/push/test')
    def test():
        if not g.user:return jsonify(error='يلزم تسجيل الدخول'),401
        token=(request.get_json(silent=True) or {}).get('device','')
        if not isinstance(token,str) or not re.fullmatch(r'[a-f0-9]{64}',token):return jsonify(error='معرّف الجهاز غير صالح'),400
        row=g.db.execute('SELECT * FROM push_devices WHERE device=? AND user_id=?',(hashlib.sha256(token.encode()).hexdigest(),g.user['id'])).fetchone()
        if not row:return jsonify(error='فعّل الإشعارات على هذا الجهاز أولًا'),400
        row=dict(row);now=time.time()
        if now-row['last_test']<60:return jsonify(error='انتظر دقيقة قبل تكرار الاختبار'),429
        g.db.execute('UPDATE push_devices SET last_test=? WHERE endpoint=?',(now,row['endpoint']));g.db.commit()
        try:status,retry=deliver(key(g.db),row,{'title':NAME,'body':'إشعارات هذا الجهاز جاهزة. اضغط لعرض تنبيهات الأقسام المسموح لك بمشاهدتها.','url':'/#/notifications','icon':'/static/img/ewan.png'})
        except Exception:status,retry=0,0
        if not 200<=status<300:
            update_result(g.db,row,status,retry,row['stamp'],now)
            return jsonify(error='لم تقبل خدمة الإشعارات الاختبار؛ تحقق من الاتصال وإذن المتصفح ثم حاول لاحقًا'),502
        return jsonify(ok=True,message='قَبِلت خدمة الإشعارات الاختبار؛ تأكد من ظهوره على هذا الجهاز')
